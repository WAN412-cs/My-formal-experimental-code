package Team.CloudStorage.EAVONE;

public class EOSubstrateNetwork extends SubstrateNetwork{
	public int[][] slots;
	public int[][] linksNo;
	public double[] transRate;
	public double[] opticalReach;
	public String[] modulevel;
	public int slotsNum;
	public double slotGHz;
	public int modulationLevel;
	public int diffSlot;
	//public double[] length;
	public double[] cb_value;
	public double[] sum_adj;
}


