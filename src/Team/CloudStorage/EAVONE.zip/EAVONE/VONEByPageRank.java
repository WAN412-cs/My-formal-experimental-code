package Team.CloudStorage.EAVONE;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
//import commons-beanutils;

import javax.swing.JOptionPane;

//import org.apache.commons.beanutils.BeanUtils;

import edu.asu.emit.algorithm.graph.Graph;
import edu.asu.emit.algorithm.graph.Path;
import edu.asu.emit.algorithm.graph.VariableGraph;
import edu.asu.emit.algorithm.graph.abstraction.BaseVertex;
import edu.asu.emit.algorithm.graph.shortestpaths.DijkstraShortestPathAlg;
import edu.asu.emit.algorithm.graph.shortestpaths.YenTopKShortestPathsAlg;
import edu.asu.emit.qyan.test.YenTopKShortestPathsAlgTest;


public class VONEByPageRank extends VNE {
	
	public void VONEEmbed(String inSNFile,String inVNsFileDir,int reqsNum,int delay) throws IOException
	{
		//鍒涘缓SN鍜孷Ns
		super.VONEEmbed(inSNFile, inVNsFileDir, reqsNum, delay);
		//embedModelOrAlgo = Parameters.MapVONETranModel;
    	//V2SEmbed
		V2SEmbed(sub,reqs,delay);//,Parameters.MapVONETranModel
	}
	
	
	/*The algorithm of mapping the VNs.*/
	private void V2SEmbed(EOSubstrateNetwork sub,VONRequest reqs[],int delay) throws IOException
	{
		//embedModelOrAlgo = embedAlgorithm;//鏄犲皠妯″瀷鎴栬�呯畻娉曚繚瀛樺湪embedModelOrAlgo
		int end,n,time,start,sStart;
		time = Parameters.TIME_INTERVAL;
		end = 0;
		n = reqs.length;
		System.out.println("reqs.length:"+n);
		Date startDate = new Date();//璁板綍鏄犲皠寮�濮嬬殑鏃堕棿
	    while (end < n || reqs[n-1].time+delay>time) {   //The value of n is the number of all the VNs.
	        while (end < n && reqs[end].time < time) end++; 
	        for(sStart=0;sStart<n-1 && (reqs[sStart].time+delay)<time;sStart++) ;//璇存槑鎵惧埌浜嗗綋鍓嶆渶灏忕殑寮�濮嬭櫄鎷熺綉缁滆姹�
	        //for(sStart=0;reqs[sStart].time<time;sStart++) ;
	        start = sStart;
	        System.out.println("sStart:" + sStart + " end:" + end);
	        
	        //Release the resources.
	        ReleaseAllResourceAmongZeroToEnd(sub,reqs,end,time);
	        
	        //Set the expire of STATE_EXPIRE.
	        SetExpireVNState(reqs,end,time,delay);
	                
	        //Allocate the resources.
	        AllocateResources(sub,reqs,start, end);	     
	        
	        time += Parameters.TIME_INTERVAL;  //鏃堕棿绐椾笅绉讳竴涓崟浣�

	    }
	    Date endDate = new Date();//璁板綍鏄犲皠寮�濮嬬殑鏃堕棿
	    long interval = (endDate.getTime() - startDate.getTime())/1000;//璁板綍鏃堕棿宸紙绉掞級

	    //璁板綍淇℃伅锛屼緥濡傜郴缁熸敹鐩娿�佹帴鏀剁巼銆佹敹鐩婃垚鏈瘮銆佸甫瀹界鐗囷紙寰堥毦瀹氫箟锛屼緥濡傚彲浠ヨ缃负灏忎簬2涓繛缁殑绌轰綑Slots涓虹鐗囷級
	    if(Parameters.DebugModel) System.out.println("RecordResultsOfVNE.");
	    RecordResultsOfVNE(sub,reqs,interval,Parameters.CurrentVONEMethod);
	    if(Parameters.DebugModel) System.out.println("PrintfVNE.");

	    //if(Parameters.DebugModel) PrintNodeEmbedding(reqs);
	    //if(Parameters.DebugModel) PrintLinkEmbedding(reqs);
		//PrintVNE(sub, reqs);PrintResultOfVN(sub,reqs);
	}
	
	//
	private void AllocateResources(EOSubstrateNetwork sub,VONRequest reqs[],int start,int end) throws IOException
	{
		System.out.println("start:" + start + " end:" + end);
		for(int i=start;i<end;i++){
			if(v2s[i].map == Parameters.STATE_NEW || v2s[i].map == Parameters.STATE_MAP_NODE_FAIL || v2s[i].map == Parameters.STATE_MAP_FAIL || v2s[i].map == Parameters.STATE_MAP_Link_FAIL) {
				ArrayList<Object> list = new ArrayList<Object>();  //璁板綍鑺傜偣鏄犲皠缁撴灉
				int p[][] = new int[reqs[i].links][sub.nodes];
				int ret[][] = new int[reqs[i].links][4];
				//ret[][0]:杩斿洖铏氭嫙閾捐矾鏄犲皠鐨勭墿鐞嗚捣鐐癸紱ret[][1]:杩斿洖铏氭嫙閾捐矾鏄犲皠鐨勭墿鐞嗙粓鐐�
				//ret[][2]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][3]:杩斿洖鐨勯璋辨Ы鏁伴噺
				v2s[i].tryMapTime ++;	//璁板綍鏄犲皠娆℃暟			
				if(reqs[i].topo == Parameters.TOPO_GENERAL || reqs[i].topo == Parameters.TOPO_STAR) {					
					if(Parameters.CurrentVONEMethod == Parameters.MapVONEPageRank){
						DebugVNE(sub,reqs,i,Parameters.CurrentVONEMethod,"before embed req "+i);
						if(MapVONEByEnTranModel(sub, reqs, i)!=-1){
							if(Parameters.DebugModel) Print_sub_slots(sub);
							v2s[i].map = Parameters.STATE_MAP_SUCC;
							reqs[i].map = Parameters.STATE_MAP_SUCC;
							DebugVNE(sub,reqs,i,Parameters.CurrentVONEMethod,"after embed succ req "+i);
						} else {
							v2s[i].map = Parameters.STATE_MAP_NODE_FAIL;
							reqs[i].map = Parameters.STATE_MAP_NODE_FAIL;
						}
					} 
				}
			}
		}
	}
		
	/******************************************************************
	鍚嶇О锛歩nt MapVONEByTranModel(......)
	鍔熻兘锛氫互杩愯緭妯″瀷鏄犲皠铏氭嫙鍏夌綉缁�, 濡傛灉鎴愬姛鍒欏～鍏卻2v_n鍜寁2s 
	鍙傛暟锛�
		      s2v_n涓虹墿鐞嗚妭鐐规槧灏勮櫄缃戣妭鐐规暟鎹粨鏋�
		      s2v_l涓虹墿鐞嗛摼璺槧灏勮櫄缃戦摼璺暟鎹粨鏋�
		      v2s涓鸿櫄缃戞槧灏勭墿鐞嗙綉缁滅殑鏁版嵁缁撴瀯 
		      index涓虹index涓櫄缃戣姹�
	,int ret[],int p[][],ArrayList<Object> list
	杩斿洖鍊硷細0锛氭垚鍔熻繑鍥烇紱-1锛氬け璐ヨ繑鍥� 
	******************************************************************/
	private int MapVONEByTranModel(EOSubstrateNetwork sub,VONRequest reqs[],int index)
	{
		//鍒涘缓杩愯緭妯″瀷鍜屾渶灏忓彲鐢ㄧ殑棰戣氨妲界储寮�
		double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		int[][] indexModel = new int[reqs[index].nodes][sub.nodes];
		int[][] linkModel = new int[reqs[index].nodes][sub.nodes];
		InitTranModel(sub,reqs,index,transModel,indexModel,linkModel);
		
		//鍒濆鍖栧垎閰�,-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤鐨勮妭鐐规垨鑰呴摼璺彿
		int[] vNodeEmbed = new int[reqs[index].nodes];
		int[] sNodeEmbed = new int[sub.nodes];
		int[] vLinkEmbed = new int[reqs[index].links];
		InitAllocModel(sub,reqs,index,vNodeEmbed,sNodeEmbed,vLinkEmbed);
		
		//p[][]:璁板綍璺緞锛況et[][]:ret[][0]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][1]:杩斿洖鐨勯璋辨Ы鏁伴噺
		int p[][] = new int[reqs[index].links][sub.nodes];
		int ret[][] = new int[reqs[index].links][2];//ret[][0]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][1]:杩斿洖鐨勯璋辨Ы鏁伴噺
		int retOther[][] = new int[reqs[index].links][2];
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<sub.nodes;j++)
				p[i][j] = -1;
			ret[i][0] = ret[i][0] = -1;
			retOther[i][0] = retOther[i][0] = -1;
		}
		EOSubstrateNetwork subCopy = new EOSubstrateNetwork();
		
		//BeanUtils.copyProperties(subCopy,sub);
		//subCopy = sub;
		Clone(subCopy,sub);
		
		int num = 0;
		int[] minElement = new int[2];//minElement[0]铏氭嫙鑺傜偣锛沵inElement[1]鐗╃悊鑺傜偣;
		while(num < reqs[index].nodes){
			//瀵绘壘鏈�灏忓厓绱狅紝绱㈠紩鏀惧湪minElement[0]\minElement[1];minIndexReq锛宮inIndexSub
			FindMinElement(subCopy,reqs,index,transModel,vNodeEmbed,sNodeEmbed,minElement);
			if(minElement[0] == -1) return -1;//娌℃湁鎵惧埌鏈�灏忓厓绱�
			vNodeEmbed[minElement[0]] = minElement[1];//铏氭嫙鑺傜偣minElement[0]鏄犲皠鍒扮墿鐞嗚妭鐐筸inElement[1]
			sNodeEmbed[minElement[1]] = minElement[0];//鐗╃悊鑺傜偣minElement[1]鏄犲皠缁欒櫄鎷熻妭鐐筸inElement[0]
			//鏇存柊cpu
			UpdateSub(subCopy,minElement[1],reqs[index].cpu[minElement[0]]);
			
			//鍦ㄨ櫄鎷熺綉缁滀腑瀵绘壘鏄惁瀛樺湪鐨勬湭鏄犲皠鐨勮櫄鎷熼摼璺紝濡傛灉瀛樺湪锛屽垯鏄犲皠锛�
			int noEmbedVLink = -1;
			noEmbedVLink=FindNoEmbedVLink(reqs,index,minElement[0],vNodeEmbed,vLinkEmbed);
			while(noEmbedVLink > -1){//濡傛灉鎵惧埌浜嗘湭鏄犲皠鐨勮櫄鎷熼摼璺紝鍒欐槧灏勮閾捐矾
				//鏄犲皠璇ヨ櫄鎷熼摼璺�,鏄犲皠缁撴灉淇濆瓨鍦╬[][]涓紝琛ㄧず铏氭嫙閾捐矾鏄犲皠鐨勮矾寰�;ret[][0]:璧峰棰戣氨妲界储寮曪紱ret[][1]:棰戣氨妲芥暟閲忥紱
				if(!PreEmbedVLinkByKShortestPath(subCopy,reqs,index,noEmbedVLink,vNodeEmbed,p,ret)){//noEmbedVLink铏氭嫙閾捐矾锛宻nodeEmbed瀵瑰簲鐨勭墿鐞嗚妭鐐�
					return -1;//澶辫触杩斿洖
				}
				//閾捐矾宸茬粡鍒嗛厤
				vLinkEmbed[noEmbedVLink] = 1;
				//鏇存柊搴曞眰缃戠粶subCopy
				//UpdateSub(EOSubstrateNetwork sub,int sNode1,int sNode2,int ret[],int p[])
				int sNode1,sNode2;
				sNode1 = vNodeEmbed[reqs[index].link[noEmbedVLink].from];
				sNode2 = vNodeEmbed[reqs[index].link[noEmbedVLink].to];
				retOther[noEmbedVLink][0] = ret[noEmbedVLink][0];
				retOther[noEmbedVLink][1] = ret[noEmbedVLink][0]+ret[noEmbedVLink][1];
				UpdateSub(subCopy,sNode2,sNode1,retOther[noEmbedVLink],p[noEmbedVLink]);
				if(Parameters.DebugModel) {
					System.out.println(noEmbedVLink+"("+retOther[noEmbedVLink][0]+"-"+retOther[noEmbedVLink][1]+")");
					PrintPath(p[noEmbedVLink],sNode2,sNode1);
				}
				noEmbedVLink=FindNoEmbedVLink(reqs,index,minElement[0],vNodeEmbed,vLinkEmbed);
			}
			num ++;
		}
		
		//濡傛灉瀛樺湪閾捐矾娌℃湁鏄犲皠锛屽垯澶辫触杩斿洖
		for(int i=0;i<reqs[index].links;i++){
			if(vLinkEmbed[i] == -1) return -1;//澶辫触杩斿洖
		}
		//鏇存柊cpu
		UpdateSub(sub,subCopy);
		//璁板綍鑺傜偣鍜岄摼璺槧灏勭粨鏋�
		AddNodesMap(reqs,index,vNodeEmbed);//鏇存柊s2v_n鍜寁2s
		AddLinksMapBySPFA(sub,reqs,index,ret,p);//鏇存柊搴曞眰缃戠粶
	  	
		return 0;//鎴愬姛杩斿洖
	}	
	/******************************************************************
	鍚嶇О锛歩nt MapVONEByTranModel(......)
	鍔熻兘锛氫互杩愯緭妯″瀷鏄犲皠铏氭嫙鍏夌綉缁�, 濡傛灉鎴愬姛鍒欏～鍏卻2v_n鍜寁2s 
	鍙傛暟锛�
		      s2v_n涓虹墿鐞嗚妭鐐规槧灏勮櫄缃戣妭鐐规暟鎹粨鏋�
		      s2v_l涓虹墿鐞嗛摼璺槧灏勮櫄缃戦摼璺暟鎹粨鏋�
		      v2s涓鸿櫄缃戞槧灏勭墿鐞嗙綉缁滅殑鏁版嵁缁撴瀯 
		      index涓虹index涓櫄缃戣姹�
	,int ret[],int p[][],ArrayList<Object> list
	杩斿洖鍊硷細0锛氭垚鍔熻繑鍥烇紱-1锛氬け璐ヨ繑鍥� 
	******************************************************************/
	private int MapVONEByEnTranModel(EOSubstrateNetwork sub,VONRequest reqs[],int index)
	{
		//鍒涘缓杩愯緭妯″瀷鍜屾渶灏忓彲鐢ㄧ殑棰戣氨妲界储寮�
		double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		int[][] indexModel = new int[reqs[index].nodes][sub.nodes];
		int[][] linkModel = new int[reqs[index].nodes][sub.nodes];
		InitTranModel(sub,reqs,index,transModel,indexModel,linkModel);
		
		//鍒濆鍖栧垎閰�,-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤鐨勮妭鐐规垨鑰呴摼璺彿
		int[] vNodeEmbed = new int[reqs[index].nodes];
		int[] sNodeEmbed = new int[sub.nodes];
		int[] vLinkEmbed = new int[reqs[index].links];
		InitAllocModel(sub,reqs,index,vNodeEmbed,sNodeEmbed,vLinkEmbed);
		
		//p[][]:璁板綍璺緞锛況et[][]:ret[][0]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][1]:杩斿洖鐨勯璋辨Ы鏁伴噺
		int p[][] = new int[reqs[index].links][sub.nodes];
		int ret[][] = new int[reqs[index].links][2];//ret[][0]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][1]:杩斿洖鐨勯璋辨Ы鏁伴噺
		int retOther[][] = new int[reqs[index].links][2];
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<sub.nodes;j++)
				p[i][j] = -1;
			ret[i][0] = ret[i][0] = -1;
			retOther[i][0] = retOther[i][0] = -1;
		}
		EOSubstrateNetwork subCopy = new EOSubstrateNetwork();
		
		//BeanUtils.copyProperties(subCopy,sub);
		//subCopy = sub;
		Clone(subCopy,sub);
		
		int num = 0;
		int[] minElement = new int[2];//minElement[0]铏氭嫙鑺傜偣锛沵inElement[1]鐗╃悊鑺傜偣;
		while(num < reqs[index].nodes){
			//瀵绘壘鏈�灏忓厓绱狅紝绱㈠紩鏀惧湪minElement[0]\minElement[1];minIndexReq锛宮inIndexSub
			FindEnMinElement(subCopy,reqs,index,transModel,vNodeEmbed,sNodeEmbed,minElement);
			if(minElement[0] == -1) return -1;//娌℃湁鎵惧埌鏈�灏忓厓绱�
			vNodeEmbed[minElement[0]] = minElement[1];//铏氭嫙鑺傜偣minElement[0]鏄犲皠鍒扮墿鐞嗚妭鐐筸inElement[1]
			sNodeEmbed[minElement[1]] = minElement[0];//鐗╃悊鑺傜偣minElement[1]鏄犲皠缁欒櫄鎷熻妭鐐筸inElement[0]
			//鏇存柊cpu
			UpdateSub(subCopy,minElement[1],reqs[index].cpu[minElement[0]]);
			
			//鍦ㄨ櫄鎷熺綉缁滀腑瀵绘壘鏄惁瀛樺湪鐨勬湭鏄犲皠鐨勮櫄鎷熼摼璺紝濡傛灉瀛樺湪锛屽垯鏄犲皠锛�
			int noEmbedVLink = -1;
			noEmbedVLink=FindNoEmbedVLink(reqs,index,minElement[0],vNodeEmbed,vLinkEmbed);
			while(noEmbedVLink > -1){//濡傛灉鎵惧埌浜嗘湭鏄犲皠鐨勮櫄鎷熼摼璺紝鍒欐槧灏勮閾捐矾
				//鏄犲皠璇ヨ櫄鎷熼摼璺�,鏄犲皠缁撴灉淇濆瓨鍦╬[][]涓紝琛ㄧず铏氭嫙閾捐矾鏄犲皠鐨勮矾寰�;ret[][0]:璧峰棰戣氨妲界储寮曪紱ret[][1]:棰戣氨妲芥暟閲忥紱
				if(!PreEmbedVLinkByKShortestPath(subCopy,reqs,index,noEmbedVLink,vNodeEmbed,p,ret)){//noEmbedVLink铏氭嫙閾捐矾锛宻nodeEmbed瀵瑰簲鐨勭墿鐞嗚妭鐐�
					return -1;//澶辫触杩斿洖
				}
				//閾捐矾宸茬粡鍒嗛厤
				vLinkEmbed[noEmbedVLink] = 1;
				//鏇存柊搴曞眰缃戠粶subCopy
				//UpdateSub(EOSubstrateNetwork sub,int sNode1,int sNode2,int ret[],int p[])
				int sNode1,sNode2;
				sNode1 = vNodeEmbed[reqs[index].link[noEmbedVLink].from];
				sNode2 = vNodeEmbed[reqs[index].link[noEmbedVLink].to];
				retOther[noEmbedVLink][0] = ret[noEmbedVLink][0];
				retOther[noEmbedVLink][1] = ret[noEmbedVLink][0]+ret[noEmbedVLink][1]-1;
				UpdateSub(subCopy,sNode2,sNode1,retOther[noEmbedVLink],p[noEmbedVLink]);
				if(Parameters.DebugModel) {
					System.out.println(noEmbedVLink+"("+retOther[noEmbedVLink][0]+"-"+retOther[noEmbedVLink][1]+")");
					PrintPath(p[noEmbedVLink],sNode2,sNode1);
				}
				noEmbedVLink=FindNoEmbedVLink(reqs,index,minElement[0],vNodeEmbed,vLinkEmbed);
			}
			num ++;
		}
		
		//濡傛灉瀛樺湪閾捐矾娌℃湁鏄犲皠锛屽垯澶辫触杩斿洖
		for(int i=0;i<reqs[index].links;i++){
			if(vLinkEmbed[i] == -1) return -1;//澶辫触杩斿洖
		}
		//鏇存柊cpu
		UpdateSub(sub,subCopy);
		//璁板綍鑺傜偣鍜岄摼璺槧灏勭粨鏋�
		AddNodesMap(reqs,index,vNodeEmbed);//鏇存柊s2v_n鍜寁2s
		AddLinksMapBySPFA(sub,reqs,index,retOther,p);//鏇存柊搴曞眰缃戠粶
		
		//鏇存柊搴曞眰缃戠粶slots
		UpdateSubSlots(sub,subCopy);
	  	
		return 0;//鎴愬姛杩斿洖
	}	
	/******************************************************************
	鍚嶇О锛歷oid MapVONEByEnTranModel(......)
	鍔熻兘锛氫互杩愯緭妯″瀷涓哄熀纭�鐨勫寮哄瀷杩愯緭妯″瀷鏄犲皠铏氭嫙鍏夌綉缁�, 濡傛灉鎴愬姛鍒欏～鍏卻2v_n鍜寁2s 
	鍙傛暟锛�
		      s2v_n涓虹墿鐞嗚妭鐐规槧灏勮櫄缃戣妭鐐规暟鎹粨鏋�
		      s2v_l涓虹墿鐞嗛摼璺槧灏勮櫄缃戦摼璺暟鎹粨鏋�
		      v2s涓鸿櫄缃戞槧灏勭墿鐞嗙綉缁滅殑鏁版嵁缁撴瀯 
		      index涓虹index涓櫄缃戣姹�
	,int ret[],int p[][],ArrayList<Object> list
	杩斿洖鍊硷細0锛氭垚鍔熻繑鍥烇紱-1锛氬け璐ヨ繑鍥� 
	******************************************************************/
	private int MapVONEByRuTranModel(EOSubstrateNetwork sub,VONRequest reqs[],int index)
	{
		//start 鍒濆鍖�
		//鍒涘缓杩愯緭妯″瀷鍜屾渶灏忓彲鐢ㄧ殑棰戣氨妲界储寮�
		double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		int[][] indexModel = new int[reqs[index].nodes][sub.nodes];
		int[][] linkModel = new int[reqs[index].nodes][sub.nodes];
		InitTranModel(sub,reqs,index,transModel,indexModel,linkModel);
		
		//鍒濆鍖栧垎閰�,-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤鐨勮妭鐐规垨鑰呴摼璺彿
		int[] vNodeEmbed = new int[reqs[index].nodes];
		int[] sNodeEmbed = new int[sub.nodes];
		int[] vLinkEmbed = new int[reqs[index].links];
		InitAllocModel(sub,reqs,index,vNodeEmbed,sNodeEmbed,vLinkEmbed);
		
		//p[][]:璁板綍璺緞锛況et[][]:ret[][0]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][1]:杩斿洖鐨勯璋辨Ы鏁伴噺
		int p[][] = new int[reqs[index].links][sub.nodes];
		int ret[][] = new int[reqs[index].links][2];//ret[][0]:杩斿洖鐨勮捣濮嬮璋辨Ы锛況et[][1]:杩斿洖鐨勯璋辨Ы鏁伴噺
		int retOther[][] = new int[reqs[index].links][2];
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<sub.nodes;j++)
				p[i][j] = -1;
			ret[i][0] = ret[i][0] = -1;
			retOther[i][0] = retOther[i][0] = -1;
		}
		EOSubstrateNetwork subCopy = new EOSubstrateNetwork();
		Clone(subCopy,sub);
		//end 鍒濆鍖�
		
		//鎵惧埌鏈槧灏勭殑铏氭嫙閾捐矾vlink瀵瑰簲鐨勮櫄鎷熻妭鐐箆q锛岀害鏉燂細璇ヨ櫄鎷熼摼璺殑甯﹀闇�姹傛渶澶э紱涓�涓櫄鎷熻妭鐐瑰凡缁忚鏄犲皠
		int evlink = 0,vp1,vp2,sp1,sp2,vlink;//evlink鏄犲皠鐨勮櫄鎷熼摼璺暟閲忥紝vp1锛寁p2锛寁link鏄壘鍒扮殑鏈槧灏勭殑铏氭嫙閾捐矾vlink鐨勪袱涓鐐�
		int[] vTwoNodeAndLink = new int[3];//vp1=vTwoNodeAndLink[0];vp2=vTwoNodeAndLink[1];vlink=vTwoNodeAndLink[2];
		
		while(FindNoEVlink(reqs,index,vLinkEmbed,vNodeEmbed,vTwoNodeAndLink)){
			vp1=vTwoNodeAndLink[0];
			vp2=vTwoNodeAndLink[1];
			vlink=vTwoNodeAndLink[2];
			if(vNodeEmbed[vp1]==-1 && vNodeEmbed[vp2]==-1){
				sp1 = FindSNodeByVNode(sub,vp1,transModel,sNodeEmbed);//鎵惧埌vp1鏄犲皠鐨剆p1鑺傜偣
				if(sp1 == -1){//澶辫触杩斿洖
					return -1;
				}
				//sp2 = FindSNodeByVNodeIncludeLink(vp1,vp2,sp1,vlink,p);//鎵惧埌vp2鏄犲皠鐨剆p2鑺傜偣,涓斿搴旂殑閾捐矾鏄犲皠
			} else if(vNodeEmbed[vp1]==-1 && vNodeEmbed[vp2]!=-1){
				sp2 = vNodeEmbed[vp2];
				//sp1 = FindSNodeByVNode(vp2,vp1,sp2,vlink,p);
			} else if(vNodeEmbed[vp1]!=-1 && vNodeEmbed[vp2]==-1){
				sp1 = vNodeEmbed[vp1];
				//sp2 = FindSNodeByVNode(vp1,vp2,sp1,vlink,p);
			} else if(vNodeEmbed[vp1]!=-1 && vNodeEmbed[vp2]!=-1){
				sp1 = vNodeEmbed[vp1];
				sp2 = vNodeEmbed[vp2];
				//EmbedVLink(sp1,sp2,p);
			}
			//棰勫垎閰�
			//PreEmbedNodesAndLinks();
			evlink++;
		}
		if(evlink == reqs[index].links){
			//EmbedNodesAndLinks();
			return 1;
		} else {
			return -1;//鏄犲皠澶辫触
		}
	}
	/******************************************************************
	鍚嶇О锛歩nt FindSNodeByVNode(......)
	鍔熻兘锛氭壘鍒板搴旂殑铏氭嫙鑺傜偣鏄犲皠鐨勫簳灞傝妭鐐�
	绠楁硶锛氭牴鎹繍杈撴ā鍨媡ransModel[][]鍜岀墿鐞嗚妭鐐规槧灏剆NodeEmbed[]
	           棣栧厛妫�娴�
	鍙傛暟锛歞ouble[][] transModel
		      
	杩斿洖鍊硷細true锛氭垚鍔熻繑鍥烇紱false锛氬け璐ヨ繑鍥� 
	******************************************************************/
	private int FindSNodeByVNodeIncludeLink(EOSubstrateNetwork sub,int vNode,double[][] transModel,int[] sNodeEmbed)
	{
		double embedCost = Parameters.MAX_VALUE_DOUBLE;
		int i=-1;
		double nodeECost = -1, linkECost = -1;
		for(i=0;i<sub.nodes;i++){
			if(transModel[vNode][i] > -1  && sNodeEmbed[i] == -1 ){
				//妫�鏌ユ槧灏勪唬浠凤紝浠ユ渶鐭矾寰勭殑閾捐矾鏄犲皠浠ｄ环linkECost鍜岃妭鐐规槧灏勪唬浠穘odeECost
				nodeECost = transModel[vNode][i];
				//linkECost = LinkEmbedCost(subCopy);
				//if(!PreEmbedVLinkByKShortestPath(subCopy,reqs,index,noEmbedVLink,vNodeEmbed,p,ret)){//noEmbedVLink铏氭嫙閾捐矾锛宻nodeEmbed瀵瑰簲鐨勭墿鐞嗚妭鐐�
				//	return -1;//澶辫触杩斿洖
				//}
				embedCost = Parameters.NodeECoEfficient * nodeECost + Parameters.LinkECoEfficient * linkECost;
			}
		}
		if(i>=sub.nodes) return -1;
		else return i;
	}
	/******************************************************************
	鍚嶇О锛歜oolean LinkEmbedCost(......)
	鍔熻兘锛氭彁渚涗竴涓墿鐞嗚妭鐐箂p1鍜屽甫瀹絙w锛屽苟鎻愪緵sp2锛岃绠梥p2->sp1鐨勬槧灏勪唬浠�
	绠楁硶锛�
	鍙傛暟锛歞ouble[][] transModel锛氳繍杈撴ā鍨�
	杩斿洖鍊硷細1锛塼rue锛氭垚鍔熻繑鍥烇紱false锛氬け璐ヨ繑鍥� 
	      2锛夎矾寰勶紱
	      3锛夋槧灏勯璋辨Ы鎬婚噺锛�
	      4锛夋槧灏勭殑棰戣氨妲借捣濮嬪拰鎴绱㈠紩锛�
	******************************************************************/
	private boolean LinkEmbedCost(EOSubstrateNetwork sub,int vNode,double[][] transModel,int[] sNodeEmbed)
	{
		int[] flag = new int[sub.nodes];
		int[] prev = new int[sub.nodes];
		int[] dist = new int[sub.nodes];
		for(int i=0;i<sub.nodes;i++){
			flag[i] = -1;//璇存槑i鑺傜偣涓嶅湪s涓�
			prev[i] = -1;
			dist[i] = -1;
		}
		return true;
		//s[sp2] = 
		//
	}
	
	/******************************************************************
	鍚嶇О锛歩nt FindSNodeByVNode(......)
	鍔熻兘锛氭壘鍒板搴旂殑铏氭嫙鑺傜偣鏄犲皠鐨勫簳灞傝妭鐐�
	绠楁硶锛氭牴鎹繍杈撴ā鍨媡ransModel[][]鍜岀墿鐞嗚妭鐐规槧灏剆NodeEmbed[]
	           鍦ㄨ繍杈撴ā鍨嬩腑鎵惧埌鏈�灏忕殑鍊硷紝涓旂墿鐞嗚妭鐐规湭鏄犲皠
	鍙傛暟锛歞ouble[][] transModel锛氳繍杈撴ā鍨�
	杩斿洖鍊硷細>-1锛氭垚鍔熻繑鍥烇紱-1锛氬け璐ヨ繑鍥� 
	******************************************************************/
	private int FindSNodeByVNode(EOSubstrateNetwork sub,int vNode,double[][] transModel,int[] sNodeEmbed)
	{
		double embedCost = Parameters.MAX_VALUE_DOUBLE;
		int i=-1;
		for(i=0;i<sub.nodes;i++){
			if(transModel[vNode][i] > -1 && embedCost < transModel[vNode][i] && sNodeEmbed[i] == -1 ){
				embedCost = transModel[vNode][i];
			}
		}
		if(i>=sub.nodes) return -1;
		else return i;
	}
	
	/******************************************************************
	鍚嶇О锛歜oolean FindNoEVlink(......)
	鍔熻兘锛氭壘鍒版湭鏄犲皠鐨勮櫄鎷熼摼璺�,1)棣栧厛
	鍙傛暟锛�
		      
	杩斿洖鍊硷細true锛氭垚鍔熻繑鍥烇紱false锛氬け璐ヨ繑鍥� 
	******************************************************************/
	private boolean FindNoEVlink(VONRequest reqs[],int index,int[] vLinkEmbed,int[] vNodeEmbed,int[] vTwoNodeAndLink)
	{
		double maxBW = Parameters.MIN_VALUE_DOUBLE;
		int i=0;
		//棣栧厛锛屾壘鍒版病鏈夋槧灏勭殑铏氭嫙閾捐矾锛屽叾涓殑鑺傜偣鏈�灏戞湁涓�涓凡缁忔槧灏�
		for(i=0;i<reqs[index].links;i++){
			if(vLinkEmbed[i] == -1 && maxBW < reqs[index].link[i].bw && (vNodeEmbed[reqs[index].link[i].from] > -1 ||vNodeEmbed[reqs[index].link[i].to] > -1))
				maxBW = reqs[index].link[i].bw;
		}
		if(i<reqs[index].links){
			vTwoNodeAndLink[0] = reqs[index].link[i].from;
			vTwoNodeAndLink[1] = reqs[index].link[i].to;
			vTwoNodeAndLink[2] = i;
			
			return true;
		}
		maxBW = Parameters.MIN_VALUE_DOUBLE;
		//鍏舵锛屾壘鍒版病鏈夋槧灏勭殑铏氭嫙閾捐矾
		for(i=0;i<reqs[index].links;i++){
			if(vLinkEmbed[i] == -1 && maxBW < reqs[index].link[i].bw)
				maxBW = reqs[index].link[i].bw;
		}
		if(i>=reqs[index].links){
			return false;
		}
		vTwoNodeAndLink[0] = reqs[index].link[i].from;
		vTwoNodeAndLink[1] = reqs[index].link[i].to;
		vTwoNodeAndLink[2] = i;
		
		return true;
	}
	
	
	/******************************************************************
	鍚嶇О锛歷oid FindMinElement(......)
	鍔熻兘锛氬鎵炬渶灏忓厓绱�
	鍙傛暟锛�
		      sub涓虹墿鐞嗙綉缁�
		      reqs涓鸿櫄缃戝厜缃戠粶
		      index涓虹index涓櫄缃戣姹�
	        transModel涓鸿繍杈撴ā鍨嬶紱
	        vnodeEmbed涓鸿櫄鎷熻妭鐐规槧灏勬ā鍨�
	        snodeEmbed涓虹墿鐞嗚妭鐐规槧灏勬ā鍨�
	杩斿洖鍊硷細     minElent涓烘渶灏忓厓绱狅紝minElent[0]:鏈�灏忓厓绱犺櫄鎷熻妭鐐癸紱minElent[1]:鏈�灏忓厓绱犵墿鐞嗚妭鐐癸紱
	******************************************************************/
	private void FindMinElement(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel,int[] vnodeEmbed,int[] snodeEmbed,int[] minElent)
	{
		//瀵绘壘鏈�灏忓厓绱狅紝绱㈠紩鏀惧湪minIndexReq锛宮inIndexSub
		minElent[0] = minElent[1] = -1;
		double minElement = 10000;
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				if(minElement>transModel[i][j] && transModel[i][j]>-1 && vnodeEmbed[i]==-1 && snodeEmbed[j]==-1){//vnodeEmbed[i] == -1琛ㄧず铏氭嫙鑺傜偣i鏈鏄犲皠
					minElent[0] = i;//minIndexReq = i;
					minElent[1] = j;//minIndexSub = j;
					minElement = transModel[i][j];
				}
			}
		}
		//if(minElent[0] > -1) return -1;//娌℃湁鎵惧埌鏈�灏忓厓绱�
	}
	
	/******************************************************************
	鍚嶇О锛歷oid FindMinElement(......)
	鍔熻兘锛氬鎵炬渶灏忓厓绱�
	鍙傛暟锛�
		      sub涓虹墿鐞嗙綉缁�
		      reqs涓鸿櫄缃戝厜缃戠粶
		      index涓虹index涓櫄缃戣姹�
	        transModel涓鸿繍杈撴ā鍨嬶紱
	        vnodeEmbed涓鸿櫄鎷熻妭鐐规槧灏勬ā鍨�
	        snodeEmbed涓虹墿鐞嗚妭鐐规槧灏勬ā鍨�
	杩斿洖鍊硷細     minElent涓烘渶灏忓厓绱狅紝minElent[0]:鏈�灏忓厓绱犺櫄鎷熻妭鐐癸紱minElent[1]:鏈�灏忓厓绱犵墿鐞嗚妭鐐癸紱
	******************************************************************/
	private void FindEnMinElement(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel,int[] vnodeEmbed,int[] snodeEmbed,int[] minElent)
	{
		//瀵绘壘鏈�灏忓厓绱狅紝绱㈠紩鏀惧湪minIndexReq锛宮inIndexSub
		double minElement = 10000;
		//鎵惧埌涓庡凡缁忔槧灏勭殑鑺傜偣杩炴帴鐨勬湭鏄犲皠鐨勮妭鐐�
		minElent[0] = minElent[1] = -1;
		int othVNode,othSNode;
		minElement = 10000;
		int slotNoRe = Parameters.MAX_VALUE_INT;
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				//鍒ゆ柇鏄惁i鑺傜偣鏄惁涓庡凡缁忔槧灏勭殑铏氭嫙鑺傜偣杩炴帴
				for(int k=0;k<reqs[index].links;k++){
					if((i == reqs[index].link[k].from && vnodeEmbed[reqs[index].link[k].to] != -1) || (i == reqs[index].link[k].to && vnodeEmbed[reqs[index].link[k].from] != -1)){
						if(minElement>transModel[i][j] && transModel[i][j]>-1 && vnodeEmbed[i]==-1 && snodeEmbed[j]==-1){//vnodeEmbed[i] == -1琛ㄧず铏氭嫙鑺傜偣i鏈鏄犲皠
							if(i == reqs[index].link[k].from) {
								othVNode = reqs[index].link[k].to;
								othSNode = vnodeEmbed[othVNode];
							} else if(i == reqs[index].link[k].to) {
								othVNode = reqs[index].link[k].from;
								othSNode = vnodeEmbed[othVNode];
							}
							int slotNoRe1 = CheckIfEnoughSlotsOnLink(sub,k,reqs[index].link[k].bw);
							if(slotNoRe1 < slotNoRe){
								minElent[0] = i;//minIndexReq = i;
								minElent[1] = j;//minIndexSub = j;
								minElement = transModel[i][j];
								slotNoRe = slotNoRe1;
							}
						}
					}
				}
				//if(minElement>transModel[i][j] && transModel[i][j]>-1 && vnodeEmbed[i]==-1 && snodeEmbed[j]==-1){//vnodeEmbed[i] == -1琛ㄧず铏氭嫙鑺傜偣i鏈鏄犲皠
				//}
			}
		}
		if(minElent[0] != -1) return ;
		//瀵绘壘鏈�灏忓厓绱�
		minElent[0] = minElent[1] = -1;
		minElement = 10000;
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				if(minElement>transModel[i][j] && transModel[i][j]>-1 && vnodeEmbed[i]==-1 && snodeEmbed[j]==-1){//vnodeEmbed[i] == -1琛ㄧず铏氭嫙鑺傜偣i鏈鏄犲皠
					minElent[0] = i;//minIndexReq = i;
					minElent[1] = j;//minIndexSub = j;
					minElement = transModel[i][j];
				}
			}
		}
	}
	
		
	
	//******************************************************************
	//鍚嶇О锛歩nt InitAllocModel(......)
	//鍔熻兘锛氬垵濮嬪寲鍒嗛厤妯″瀷
	//鍙傛暟锛�
	//	      sub涓虹墿鐞嗙綉缁�
	//	      reqs涓鸿櫄缃戝厜缃戠粶
	//	      index涓虹index涓櫄缃戣姹�
	//杩斿洖鍊硷細     vnodeEmbed涓鸿櫄鎷熻妭鐐规槧灏勬ā鍨�//-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤
	//        snodeEmbed涓虹墿鐞嗚妭鐐规槧灏勬ā鍨�//-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤
	//        vlinkEmbed涓鸿櫄鎷熼摼璺槧灏勬ā鍨�//-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤
	//******************************************************************
	private void InitAllocModel(EOSubstrateNetwork sub,VONRequest reqs[],int index,int[] vnodeEmbed,int[] snodeEmbed,int[] vlinkEmbed)
	{
		for(int i=0; i<reqs[index].nodes; i++){
			vnodeEmbed[i] = -1;//-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤
		}
		for(int i=0; i<sub.nodes; i++){
			snodeEmbed[i] = -1;//-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤
		}
		for(int i=0; i<reqs[index].links; i++){
			vlinkEmbed[i] = -1;//-1浠ｈ〃鐫�鏈垎閰嶏紝>-1浠ｈ〃宸茬粡鍒嗛厤
		}
	}
	
	//******************************************************************
	//鍚嶇О锛歩nt InitTranModel(......)
	//鍔熻兘锛氬垵濮嬪寲杩愯緭妯″瀷
	//鍙傛暟锛�
	//	      sub涓虹墿鐞嗙綉缁�
	//	      sNode涓虹墿鐞嗚妭鐐�
	//	      reqs涓鸿櫄缃戝厜缃戠粶
	//	      index涓虹index涓櫄缃戣姹�
	//	      transModel涓鸿繑鍥炵殑浼犺緭妯″瀷
	//        indexModel涓鸿繑鍥炵殑浼犺緭妯″瀷涓渶灏忓彲鐢ㄧ殑棰戣氨绱㈠紩
	//杩斿洖鍊硷細
	//******************************************************************
	private void InitTranModel(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel,int[][] slotIndexModel,int[][] linkModel)
	{
		//璁＄畻pagerank鍊�
		double vNodePageRank[] = new double[reqs[index].nodes];
		double sNodePageRank[] = new double[sub.nodes];
		//	InitVNodePageRank(reqs,index);
		
		vNodePageRank=InitVNodePageRank(vNodePageRank,reqs,index);
		sNodePageRank= InitSNodePageRank(sNodePageRank, sub);
				
		//鍒涘缓杩愯緭妯″瀷鍜屾渶灏忕储寮曞拰閾捐矾鍙�
		int slotNum = -1;
		int link[] = new int[1];
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				if(reqs[index].cpu[i] <= s2v_n[j].rest_cpu + Parameters.MIN_VALUE_DOUBLE){//搴曞眰鑺傜偣鐨凜PU澶т簬铏氭嫙鑺傜偣
					slotNum = CheckIfSlotEnoughByNode(sub,j,reqs,index,i,link);
					if( slotNum > -1){//濡傛灉涓庡簳灞傝妭鐐筳鐩歌繛鎺ョ殑閾捐矾棰戣氨妲藉ぇ浜庤櫄鎷熻妭鐐筰璇锋眰鐨勬Ы
						transModel[i][j] = Math.abs(vNodePageRank[i]-sNodePageRank[j]);//transModel[i][j] = 1.0/s2v_n[j].rest_cpu;//div(1.0,s2v_n[j].rest_cpu,10);//1.0/(1.0*s2v_n[j].rest_cpu);
						slotIndexModel[i][j] = slotNum;
						linkModel[i][j] = link[0];
					} else {
						transModel[i][j] = -1;//-1浠ｈ〃涓嶈兘鏄犲皠
						slotIndexModel[i][j] = -1;
					}  
				} else {
					transModel[i][j] = -1;//-1浠ｈ〃涓嶈兘鏄犲皠
				}
			}
		}
	}
}
