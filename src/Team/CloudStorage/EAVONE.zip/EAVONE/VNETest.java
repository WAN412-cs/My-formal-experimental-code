package Team.CloudStorage.EAVONE;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JOptionPane;//.swing.JOptionPane;

public class VNETest {
	public static void main(String [] args)  
	{  	
		try{
			String SNFile,VNsFile;
			SNFile = "sub.txt";
			SNFile = "sub-24-43-EON.txt";//���ģ
			//SNFile = "sub-28-41-EON.txt";//���ģ
			//SNFile = "sub-10-14-EON.txt";
			//SNFile = "sub-6-8-EON.txt";//С��ģ
			//SNFile = "sub-6-8-EON-ShDis.txt";//С��ģ�̾���
			
			VNsFile = "req-10node-erl50";
			VNsFile = "req-3node\\req-3node-erl50-0";
			VNsFile = "req-10node\\req-10node-erl50-0";
			VNsFile = "reqs-erl\\reqs-erl40-10-125\\reqs-erl40-4-10-10-125-5000-1";
			VNsFile = "reqs-erl\\reqs-erl100-10-125\\reqs-erl100-10-10-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl200-10-125\\reqs-erl200-10-20-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl300-10-125\\reqs-erl300-10-30-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl400-10-125\\reqs-erl400-10-40-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl500-10-125\\reqs-erl500-10-50-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl500-50-125\\reqs-erl500-10-50-50-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl400-50-125\\reqs-erl400-10-40-50-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl300-50-125\\reqs-erl300-10-30-50-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl200-50-125\\reqs-erl200-10-20-50-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl100-50-125\\reqs-erl100-10-10-50-125-5000-0";
			//VNsFile = "reqs-erl\\reqs-erl40-10-125\\reqs-erl40-4-10-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl100-10-125\\reqs-erl100-10-10-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl300-10-125\\reqs-erl300-10-30-10-125-5000-0";
			//VNsFile = "reqs-erl\\reqs-erl400-10-125\\reqs-erl400-10-40-10-125-5000-0";
			VNsFile = "reqs-erl\\reqs-erl500-10-125\\reqs-erl500-10-50-10-125-5000-0";
			//VNsFile = "req-10node-erl50";
			//VNsFile = "req-3node-10\\req-3node-erl50-0";
			
			
			//VNsFile = "req-10node-erl50";
			VNsFile = "..\\reqs\\reqs-erl\\reqs-erl50-50-125-6\\0";
			//VNsFile = "reqs-erl\\reqs-erl100-50-125-6\\reqs-erl100-10-50-50-125-5000-6-0";
			//VNsFile = "reqs-t";
			//VNsFile = "req-3node\\req-3node-erl50-0";
			//VNsFile = "reqs-erl\\reqs-erl100-50-125-6\\reqs-erl100-10-50-50-125-5000-6-0";
			//VNsFile = "reqs-erl\\reqs-erl40-50-125\\reqs-erl40-4-10-50-125-5000-0";
			//VNsFile = "reqs-erl\\reqs-erl40-50-125-6\\0";
			//VNsFile = "req-3node\\req-3node-erl50-0";
			//VNsFile = "reqs-erl\\reqs-erl50-50-125-4\\0";
			VNsFile = "..\\reqs\\reqs-erl\\reqs-erl10-50-125-4\\0";
			///VNsFile = "..\\reqs\\reqs-erl\\reqs-erl10-50-125-4-staticAnalyse\\0";
			
			//VNsFile = "reqs-erl\\test";
			
			
			int reqsNum1 = 200; 
			int delay1 = 100;
			//MapVONEEnTranModel
			//MapVONELin_SortByNodeDegreeAndBW
			/*
			VONEFactory vf = new VONEFactory();
			VNE vone;
			//���Ż�MapVONE3PByWangYAndChenxh//MapVONE3ByWangY//MapVONE3PByWangY
			//MapVONE01ILPLin//MapVONE01ILPPRLinCXH//MapVONE3ByWangY//MapVONE01ILPPRLinCXHNode
			//����ʽMapVONELin_SortByNodeDegreeAndBW//MapVONELin_SortByBW//
			//MapVONEMIPTranAndPRankByCXH//MapVONEPageRank//MapVONEEnTranModel//MapVONETranModel
			Parameters.CurrentVONEMethod = Parameters.MapVONE01ILPLin;//MapVONE01ILPPRLinCXHNode;
			vone = vf.GetVONEMethod(Parameters.CurrentVONEMethod);
			vone.VONEEmbed(SNFile,VNsFile,reqsNum1,delay1);
			*/
			///*
			reqsNum1 = 5000;//1000; 
			try{
				//for(int ii=50;ii<=50;ii=ii+100)//���ģ
				for(int ii=10;ii<=10;ii=ii+10)//С��ģ
					for(int jj=0;jj<=19;jj++){
						VNsFile = "..\\reqs\\reqs-erl\\reqs-erl"+ii+"-50-125-4\\"+jj;//С��ģ
						VNsFile = "..\\reqs\\reqs-erl\\reqs-erl"+ii+"-50-125-6\\"+jj;//���ģ
						VNsFile = "..\\reqs\\reqs-erl\\reqs-15-20-24nodes-50cpu-50bw\\"+jj;//���ģ
						//VNsFile = "..\\reqs\\6";
						VONEFactory vf = new VONEFactory();
						VNE vone;//MapVONE01ILPLin//MapVONE01ILPPRLinCXH//./mkreq 12500 1 50 50 50 100 100 reqs/1

						//MapVONE01ILPLin//MapVONE01ILPPRLinCXH//MapVONE3ByWangY//MapVONE01ILPPRLinCXHNode
						//MapVONEPageRank//MapVONECXHNode//MapVONELin_SortByNodeDegreeAndBW
						Parameters.CurrentVONEMethod = Parameters.MapVONECXHNode;//MapVONE01ILPPRLinCXHNode;//MapVONE01ILPLin;//MapVONE01ILPLin;//MapVONELin_FB_SortByNodeDegreeAndBW;//MapVONE01ILPLin;//MapVONELin_FB_SortByNodeDegreeAndBW;//MapVONE3ByWangY;//MapVONE01ILPLin;//MapVONE3ByWangY;//MapVONELin_FB_SortByNodeDegreeAndBW;//MapVONELin_SortByBW;//MapVONEMIPTranAndPRankByCXH;//MapVONE3PByWangYAndChenxh;//MapVONE3PByWangYAndChenxh;//MapVONE3ByWangY;//MapVONELin_SortByNodeDegreeAndBW;//MapVONELin_SortByNodeDegreeAndBW;//MapVONEPageRank;//MapVONE3PByWangY;//MapVONEEnTranModel;//MapVONELin;//MapVONEPageRank;//.MapVONELin;//MapVONEEnTranModel;//MapVONETranModel;//MapVONE3PByWangY;//MapVONE3ByWangY;//MapVONETranModel;//MapVONE3PByWangY;//MapVONE3ByWangY;//.MapVONE3PByWangY;//.MapVONETranModel;
						vone = vf.GetVONEMethod(Parameters.CurrentVONEMethod);
						vone.VONEEmbed(SNFile,VNsFile,reqsNum1,delay1); 
					}
			} catch(Exception e){
				e.printStackTrace();
			}
			//*/
			
			
			
			//VONEFactory vf = new VONEFactory();
			//VNE vone;
			//
			//static int MapVONELin_SortByNodeDegree = 17;//lin_algo1
			//static int MapVONELin_SortByNodeDegreeAndBW = 18;//lin_algo2
			//static int MapVONELin_SortByBW = 19;//lin_algo3
			//MapVONEEnTranModel
			//MapVONEMIPTranAndPRankByCXH
			//MapVONE3ByWangY
			//MapVONE01ILPLin
			//MapVONETranILPByChenxh
			//MapVONE3PByWangYAndChenxh
			//MapVONELin_SortByNodeDegreeAndBW
			//MapVONEPageRank
			//MapVONETranILPByChenxh
			//MapVONE01ILPPRLinCXH
			//Parameters.CurrentVONEMethod = Parameters.MapVONEEnTranModel;//MapVONELin_SortByBW;//MapVONEMIPTranAndPRankByCXH;//MapVONE3PByWangYAndChenxh;//MapVONE3PByWangYAndChenxh;//MapVONE3ByWangY;//MapVONELin_SortByNodeDegreeAndBW;//MapVONELin_SortByNodeDegreeAndBW;//MapVONEPageRank;//MapVONE3PByWangY;//MapVONEEnTranModel;//MapVONELin;//MapVONEPageRank;//.MapVONELin;//MapVONEEnTranModel;//MapVONETranModel;//MapVONE3PByWangY;//MapVONE3ByWangY;//MapVONETranModel;//MapVONE3PByWangY;//MapVONE3ByWangY;//.MapVONE3PByWangY;//.MapVONETranModel;
			//vone = vf.GetVONEMethod(Parameters.CurrentVONEMethod);
			//vone.VONEEmbed(SNFile,VNsFile,reqsNum1,delay1);
		} catch(Exception e){
			e.printStackTrace();
		}
		/*
		//String SNFile,VNsFile;
		//SNFile = "sub.txt";
		//VNsFile = "C:\\Users\\chenxh\\workspace\\RSA-EAVNE\\requests-100-0-10-10";
		//VNsFile = "requests-100-0-10-10";
		//VNsFile = "reqs-20-100";//"reqs";//"co";
		//VNsFile = "req-erl-100";
		//VNsFile = "req-erl-50";
		//VNsFile = "reqs-1000-700";
		//VNsFile = "requests-100-0-10-10";
		//VNsFile = "req-3node-2link-erl50";
		//VNsFile = "req-10node-erl50";//"req-10node\\req-10node-erl50-0";//
		//VNsFile = "req-3node\\req-3node-erl50-0";
		//VNsFile = "req-3node-10\\req-3node-erl50-0";
		//VNsFile = "req-2node-10\\req-2node-erl50-0";
		int reqsNum = 2; 
		
		EOSubstrateNetwork sub = new EOSubstrateNetwork();
		VONRequest[] reqs = new VONRequest[reqsNum];
		System.out.println("The length of reqs:"+reqs.length);
		//VNEByEOpticalNet vne = new VNEByEOpticalNet(SNFile,VNsFile);//Create elastic optical network
		//VNEByEOpticalNet vne = new VNEByEOpticalNet(SNFile,VNsFile);//Create elastic optical network
		//VONRequest reqs = VONRequest(VNsFile);
		VONEByTranModel vne = new VONEByTranModel(SNFile,VNsFile);
		try {
			
			vne.CreateSN(sub);
			System.out.println("It has already succeeded in creating the elastic optical substrate network.");
			//vne.PrintSN(sub);
			
			vne.CreateVNs(reqs,reqsNum);
			//vne.PrintVNs(reqs,reqsNum);
			System.out.println("It has already succeeded in creating the VN Requests.");
			
			vne.Init(sub, reqs, reqsNum);
			System.out.println("Init successfully.");
			
			int delay = 100;
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapLinkByMIP);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapLinkByMIPEnh);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapLinkByMIPTimes);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapLinkBySPFA);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapLinkByFA);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapLinkBy01ILP);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapVONEBy01ILP);
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapVONE3PByWangY);//chenxh�����
			//vne.V2SEmbed(sub,reqs,delay,Parameters.MapVONE3ByWangY);
			vne.V2SEmbed(sub,reqs,delay,Parameters.MapVONETranModel);
			//vne.CreateKShortestPath(sub, reqs, 0);
			//System.out.println("PrintfVNE.");
			//vne.PrintVNE(sub, reqs);
			//vne.SaveNodeEmbedding(reqs);
			
			JOptionPane.showMessageDialog(null, "�ɹ������Դ���䣡", "�ɹ�", JOptionPane.ERROR_MESSAGE);

		} 
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getStackTrace());
			JOptionPane.showMessageDialog(null, ex.getStackTrace(), "ʧ��", JOptionPane.ERROR_MESSAGE);

		}	*/			
    }  
}
