package Team.CloudStorage.EAVONE;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
//import java.io.BufferedReader;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStreamReader;
import java.util.*;

public class Tools {
	
	/******************************************************************
	���ƣ�Sort(......)
	���ܣ�����
	������desOrInc��1������2������
	����ֵ��
	����ʱ�䣺2019.6.24
	�����ˣ�chen xiaohua
	******************************************************************/
	public void Sort(int desOrInc,int[] arr)
	{
		boolean sort = false;
		int t = -1;
		for(int i=0;i<arr.length-1;i++){
			sort = false;
			for(int j=0;j<arr.length-1-i;j++){
				if(desOrInc == 1){//����
					if(arr[i] < arr[i+1]) {
						t = arr[i];
						arr[i] = arr[i+1];
						arr[i+1] = t;
						sort = true;
					}
				} else if(desOrInc == 2){//����
					if(arr[i] > arr[i+1]) {
						t = arr[i];
						arr[i] = arr[i+1];
						arr[i+1] = t;
						sort = true;
					}
				}
			}
			if(!sort) break;
		}
	}
	
	/******************************************************************
	���ƣ�Sort(......)
	���ܣ�����
	������desOrInc��1������2������
	����ֵ��
	����ʱ�䣺2019.6.24
	�����ˣ�chen xiaohua
	******************************************************************/
	public void Sort(int desOrInc,int[] arr,int[] arrIndex)
	{
		boolean sort = false;
		int t = -1;
		for(int i=0;i<arr.length;i++){
			arrIndex[i] = i;
		}
		for(int i=0;i<arr.length-1;i++){
			sort = false;
			for(int j=0;j<arr.length-1-i;j++){
				if(desOrInc == 1){//����
					if(arr[i] < arr[i+1]) {
						t = arr[i];
						arr[i] = arr[i+1];
						arr[i+1] = t;

						t = arrIndex[i];
						arrIndex[i] = arrIndex[i+1];
						arrIndex[i+1] = t;
						
						sort = true;
					}
				} else if(desOrInc == 2){//����
					if(arr[i] > arr[i+1]) {
						t = arr[i];
						arr[i] = arr[i+1];
						arr[i+1] = t;
						
						t = arrIndex[i];
						arrIndex[i] = arrIndex[i+1];
						arrIndex[i+1] = t;
						
						sort = true;
					}
				}
			}
			if(!sort) break;
		}
	}
	
	public void CreateDiffRandom(int start,int end,ArrayList<Object> list){
		//ArrayList list = new ArrayList();                 
        int n = end-start;  
        Random rand = new Random();  
        boolean[] bool = new boolean[n];            
        int num =0;  
          
        for (int i = 0; i<n; i++){        
            do{  
                //�������������ͬ����ѭ��  
                num = rand.nextInt(n);                     
            }while(bool[num]);               
            bool[num] =true;                
            list.add(num);            
        }  
	}
	
	//�õ������GetRandom
	//����ֵ�ķ�ΧΪ��[min,max)
	public static int GetRandom(int min, int max)
	{
		Random random = new Random();
		int s = random.nextInt(max) % (max - min + 1) + min;
		return s;
		//return String.valueOf(s);
	}
	
	//���ط�ΧΪ[min,max)��n�������������
	public void CreateDiffRandomRetArr(int n,int min,int max,int[] randomArr)
	{
		//ArrayList list = new ArrayList();                 
        //int n = end-start;  
        //Random rand = new Random();  
        //boolean[] bool = new boolean[n];  
		if(n > (max-min)) {
			System.out.println("CreateDiffRandomRetArr is error.*******************");
			return ;
		}
        int num =0;  
        boolean find = false;
        int j = 0;
        
        for (int i = 0; i < n; ){        
        	//�������������ͬ����ѭ��
        	num = GetRandom(min,max);
        	find = false;
        	for(j = 0; j < i; j++){
        		if(num == randomArr[j]) {
        			find = true;        			
        			break;
        		}
        	}
        	if(!find || j==i){
        		randomArr[i] = num;
        		System.out.print(num+" ");
        		i++;
        	}  
        }  
        System.out.println("");
	}
	
	//���ƣ�SaveFile
	//���ܣ���������
	//������1��strName���ļ���
	//      2��content������
	//      3)append:�Ƿ���׷�ӵķ�ʽ��������,false:������ʽ��true��׷�ӷ�ʽ
	public void SaveFile(String fileName,String data,boolean append)
	{
		try{
			//String data = "sadfa ";
		    //File file =new File("glpsolRSA.dat");
		    File file =new File(fileName);
		    //if file doesnt exists, then create it
		    if(!file.exists()){
		       file.createNewFile();
		    }
            //true = append file
		    FileWriter fileWritter = new FileWriter(file.getName(),append);
		    BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
		    
		    bufferWritter.write(data);
		    bufferWritter.flush();
		    bufferWritter.close();
		    //fileWritter.flush();
		    fileWritter.close();
		    //System.out.println("Done");
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	 public void readFileByLines(String fileName,String data,int lineNum) {
		 BufferedReader reader = null;
		 try {
	            System.out.println("����Ϊ��λ��ȡ�ļ����ݣ�һ�ζ�һ���У�");
	            reader = new BufferedReader(new FileReader(fileName));
	            String tempString = null;
	            int line = 1;
	            // һ�ζ���һ�У�ֱ������nullΪ�ļ�����
	            while ((tempString = reader.readLine()) != null) {
	                // ��ʾ�к�
	                System.out.println("line " + line + ": " + tempString);
	                if(line == lineNum) break;
	                line++;
	            }
	            reader.close();
	            data = tempString; 
	      } catch (IOException e) {
	            e.printStackTrace();
	      } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e1) {
	                	
	                }
	            }
	      }      
	        
	 }
}
