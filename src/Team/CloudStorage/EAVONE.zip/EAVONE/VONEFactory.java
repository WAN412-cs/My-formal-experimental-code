package Team.CloudStorage.EAVONE;

public class VONEFactory {
	public VNE GetVONEMethod(int voneMethod) throws Exception
	{
		if(voneMethod == Parameters.MapVONETranModel || voneMethod == Parameters.MapVONEEnTranModel||voneMethod == Parameters.MapVONETranILPByChenxh){
			return new VONEByTranModel();
		} else if(voneMethod == Parameters.MapVONE3ByWangY || voneMethod == Parameters.MapVONEMIPTranAndPRankByCXH || voneMethod == Parameters.MapVONETranILPByChenxh){//k���·��
			return new VONEByKSPath();
		} else if(voneMethod == Parameters.MapVONE3PByWangYAndChenxh){
			return new VONEByEKSPath();
		} else if(voneMethod == Parameters.MapVONECXHNode || voneMethod == Parameters.MapVONE01ILPLin || voneMethod == Parameters.MapVONE01ILPPRLinCXH || voneMethod == Parameters.MapVONE01ILPLinCXH || voneMethod == Parameters.MapVONELin_SortByNodeDegree || Parameters.CurrentVONEMethod == Parameters.MapVONELin_SortByNodeDegreeAndBW || Parameters.CurrentVONEMethod == Parameters.MapVONELin_SortByBW || voneMethod == Parameters.MapVONELin_FB_SortByNodeDegree || Parameters.CurrentVONEMethod == Parameters.MapVONELin_FB_SortByNodeDegreeAndBW || Parameters.CurrentVONEMethod == Parameters.MapVONELin_FB_SortByBW){
			return new VONEByLin();//
		} else if(voneMethod == Parameters.MapVONEPageRank){
			return new VONEByPageRank();
		} else {
			throw new Exception("no such " + voneMethod+" found.");
		}
	}
}
