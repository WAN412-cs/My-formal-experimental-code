package Team.CloudStorage.EAVONE;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Parameter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import edu.asu.emit.algorithm.graph.Path;
import edu.asu.emit.algorithm.graph.abstraction.BaseVertex;
import edu.asu.emit.qyan.test.YenTopKShortestPathsAlgTest;

public class VNE {
	public String SNFile;
    public String VNsFileDir;
    public static EOSubstrateNetwork sub;// = new EOSubstrateNetwork();;
    public static EOSubstrateNetwork subStatic;
    public static VONRequest reqs[];
    public static S2VNode s2v_n[];
    public static S2VLink s2v_l[];
    public static Req2Sub v2s[];
    public int embedModelOrAlgo = -1;
    public double cpuSRate = 0;//�ܵ�cpu������ֵ
    public double resSRate = 0;//�ܵ�res������ֵ
    public double slotSRate = 0;//�ܵ�slot������ֵ
    //public int B;
    //public int M;
    
    //public void VNE(EOSubstrateNetwork sub,VONRequest reqs[],int reqsNum)
    //{
    //	Init(sub,reqs,reqsNum);
    //}
    
    
    public void VONEEmbed(String inSNFile,String inVNsFileDir,int reqsNum,int delay) throws IOException
	{
    	//����SN��VNs
    	SNFile = inSNFile;
    	VNsFileDir = inVNsFileDir;
    	
    	sub = new EOSubstrateNetwork();
    	CreateSN(sub);
    	
    	subStatic = new EOSubstrateNetwork();
    	CreateSN(subStatic);
    	
		reqs = new VONRequest[reqsNum];
		CreateVNs(reqs,reqsNum);
		
		System.out.println("It has already succeeded in creating the SN and VN Requests.");
		
		Init(sub,reqs,reqsNum);
		
    	return;
	}
    //Init the v2s,s2v_n,s2v_l
  	public void Init(EOSubstrateNetwork sub,VONRequest reqs[],int reqsNum)
  	{
  		v2s = new Req2Sub[reqsNum]; 
  		for(int i = 0; i < reqsNum; i++) {
  			v2s[i] = new Req2Sub();
  			v2s[i].map = Parameters.STATE_NEW;
  		}
  		
  		s2v_n = new S2VNode[sub.nodes];
  		for(int i = 0; i < sub.nodes; i++) {
  			s2v_n[i] = new S2VNode();
  			s2v_n[i].rest_cpu = sub.cpu[i];
  		}
  		
  		s2v_l = new S2VLink[sub.links];
  		for(int i = 0; i < sub.links; i++) {
  			s2v_l[i] = new S2VLink();
  			s2v_l[i].rest_bw = sub.link[i].bw;
  		}
  	}
  	
  	
  	
	
  	/*���ƣ�void FindNoEmbedVLink(......)
	 * ���ܣ�Ѱ��������ڵ����ӵ�δӳ���������·
	 * ������
	 * 	reqsΪ����������
	 * 	indexΪ��index����������
	 * 	vNodeΪ����ڵ㣻
	 * 	vnodeEmbedΪ����ڵ�ӳ��ģ��
	 * 	vlinkEmbedΪ������·ӳ��ģ��
	 * ����ֵ��     ��vLink���ӵ�δӳ���������·��-1��ʾδ�ҵ���
	 */
	public int FindNoEmbedVLink(VONRequest reqs[],int index,int vNode,int[] vnodeEmbed,int[] vlinkEmbed)
	{
		//�ҵ�������ڵ�vLink���ӵ���·
		for(int i=0;i<reqs[index].links;i++){
			if(reqs[index].link[i].from == vNode || reqs[index].link[i].to == vNode){
				if(vlinkEmbed[i] == -1) {
					if(reqs[index].link[i].from == vNode && vnodeEmbed[reqs[index].link[i].to] != -1)
						return i;//�ҵ���δӳ���������·
					if(reqs[index].link[i].to == vNode && vnodeEmbed[reqs[index].link[i].from] != -1)
						return i;//�ҵ���δӳ���������·
				}
			}
		}
		return -1;//û���ҵ�������·
	}
	/*
	 * ����Yen�㷨�ҵ�k���·��
	 */
	public int GetKShortestPath(EOSubstrateNetwork sub,int sNode1,int sNode2,DistanceParent[][] kSPath)
	{
		//start:����Yen�㷨�ҵ�k���·��
		//дͼ�ļ�
		String graphData = "graph.data";
		WriteFileOfGraph(sub,graphData); 
		List<Path> myPath;
		YenTopKShortestPathsAlgTest myTest = new YenTopKShortestPathsAlgTest(graphData);
		myPath = myTest.testYenShortestPathsAlg(Parameters.K_PATH,sNode1,sNode2);
		if(Parameters.DebugModel == true){
			System.out.println("cxh:"+myPath);
			System.out.println("size:"+myPath.size());
		}
		
		//DistanceParent[][] kSPath = new DistanceParent[Parameters.K_PATH][sub.nodes];//�洢k���·�������ݽṹ
		//DistanceParent[] sPath  = new DistanceParent[sub.nodes];
		int oNode1 = -1;
		int oNode2 = -1;
		for(int i = 0 ; i < myPath.size() ; i++) {
			if(Parameters.DebugModel == true){
				System.out.println(myPath.get(i).getVertexList());
				System.out.println(myPath.get(i).getWeight());
			}
			List<BaseVertex> myVertex = myPath.get(i).getVertexList();
			int node1 = myVertex.get(0).getId();
			oNode1 = node1;
			//sPath[node1] = new DistanceParent(node1,length);
			for(int j=0;j<myVertex.size();j++){
				  //System.out.println(myVertex.get(j));
				  int node2 = myVertex.get(j).getId();
				  double length = myPath.get(i).getWeight();//myVertex.get(j).getWeight();
				  if(Parameters.DebugModel == true){
					  System.out.println("cxh:"+node2+" length:"+length);
				  }
				  kSPath[i][node1] = new DistanceParent(node2,length);
				  node1 = node2;
			}
			oNode2 = node1;  
		}
		if(Parameters.DebugModel == true){
			//WeightedDirectedGraph myGraph1 = new WeightedDirectedGraph(sub.nodes);
			//myGraph1.CreateDireGraph(sub.nodes);//�����ڵ�
			//myGraph1.CreateEdge(sub);//������
			
			//for(int i=0;i<myPath.size();i++){
			//	System.out.println("path:"+i);
			//	myGraph1.PrintPath(oNode2,oNode1,kSPath[i]);
			//}
		}
		return myPath.size();
	}
	
	/*
	 * ����Yen�㷨�ҵ�k���·��
	 */
	public int GetKShortestPath1(WeightedDirectedGraph sub,int sNode1,int sNode2,DistanceParent[][] kSPath)
	{
		//start:����Yen�㷨�ҵ�k���·��
		//дͼ�ļ�
		String graphData = "graph.data";
		WriteFileOfGraph1(sub,graphData); 
		List<Path> myPath;
		YenTopKShortestPathsAlgTest myTest = new YenTopKShortestPathsAlgTest(graphData);
		myPath = myTest.testYenShortestPathsAlg(Parameters.K_PATH,sNode1,sNode2);
		if(Parameters.DebugModel == true){
			System.out.println("cxh:"+myPath);
			System.out.println("size:"+myPath.size());
		}
		
		//DistanceParent[][] kSPath = new DistanceParent[Parameters.K_PATH][sub.nodes];//�洢k���·�������ݽṹ
		//DistanceParent[] sPath  = new DistanceParent[sub.nodes];
		int oNode1 = -1;
		int oNode2 = -1;
		for(int i = 0 ; i < myPath.size() ; i++) {
			if(Parameters.DebugModel == true){
				System.out.println(myPath.get(i).getVertexList());
				System.out.println(myPath.get(i).getWeight());
			}
			List<BaseVertex> myVertex = myPath.get(i).getVertexList();
			int node1 = myVertex.get(0).getId();
			oNode1 = node1;
			//sPath[node1] = new DistanceParent(node1,length);
			for(int j=0;j<myVertex.size();j++){
				  //System.out.println(myVertex.get(j));
				  int node2 = myVertex.get(j).getId();
				  double length = myPath.get(i).getWeight();//myVertex.get(j).getWeight();
				  if(Parameters.DebugModel == true){
					  System.out.println("cxh:"+node2+" length:"+length);
				  }
				  kSPath[i][node1] = new DistanceParent(node2,length);
				  node1 = node2;
			}
			oNode2 = node1;  
		}
		return myPath.size();
	}
	/*����ÿ��·������Ҫ��slots����
	 * 
	 *����ֵ��<=0��ʾʧ�ܣ�
	 */
	private int GetSlotNumByOnePath(AuxiliaryGraph auxGraph,DistanceParent[] shortestPath,int pathNum,int sNode1,int sNode2,double bw,double pathLen[])
	{
		//�ҵ���·����slots������[BWd/(12.5*mp)],mp=1,2,3,4,BPSK:3000km,QPSK:1500km,8QAM:750km,16QAM:375km
		int sNode3 = sNode2;	
		int sNode4 = sNode2;
		int linkNo = -1;
		int mp = -1;
		if(shortestPath[sNode2] == null) return 0;
		int pathLength = 0;
		while(shortestPath[sNode2].parentVert != sNode1){
			sNode3 = sNode2;
			sNode2 = shortestPath[sNode2].parentVert;
			if(sNode3 == sNode4) continue;
			linkNo = GetLinkNum(auxGraph,sNode3,sNode2);
			pathLength += auxGraph.link[linkNo].length;
			//if(auxGraph.link[linkNo].length <= 375 && mp < 4) mp = 4;
			//else if(auxGraph.link[linkNo].length <= 750 && mp < 3) mp = 3;
			//else if(auxGraph.link[linkNo].length <= 1500 && mp < 2) mp = 2;
			//else if(auxGraph.link[linkNo].length <= 3000 && mp < 1) mp = 1;
		}	
		System.out.println("pathLength:"+pathLength);
		pathLen[0] = pathLength;
		return CalculateSlots(bw,pathLength);//GetSlotsByLength(pathLength,bw);
		//if(pathLength <= 375) mp = 4;
		//else if(pathLength <= 750) mp = 3;
		//else if(pathLength <= 1500) mp = 2;
		//else if(pathLength <= 3000) mp = 1;
		//else return 0;//����3000km�����޷�����
		//int slotNum = (int) (Math.floor(bw/(12.5*mp))+1);
		//return slotNum;
	}
	/*����:�õ�path��Ӧ��������·ӳ���·�����
	 * ����ֵ��-1:ʧ�ܣ�>=0���ɹ����ء�
	 
	//
	public int GetSlotsByLength(double pathLength,double bw)
	{
		int mp = -1;
		if(pathLength <= 375) mp = 4;
		else if(pathLength <= 750) mp = 3;
		else if(pathLength <= 1500) mp = 2;
		else if(pathLength <= 3000) mp = 1;
		else return 0;//����3000km�����޷�����
		int slotNum = (int) (Math.floor(bw/(12.5*mp))+1);
		return slotNum;
	}*/
	/*����:�õ�path��Ӧ��������·ӳ���·�����
	 * ����ֵ��-1:ʧ�ܣ�>=0���ɹ����ء�
	 */
	//
	public int GetPathNoInVirtualLinkAndPath(int path,int[][] pathNo,int[] pathEff,VONRequest reqs[],int index)
	{
		for(int i=0; i < reqs[index].links; i++)//ÿ��������·
		{
			for(int j=0; j < pathEff[i]; j++)//ÿ��·��
			{
				if(pathNo[i][j] == path) return j;
			}
		}
		return -1;
	}
		
	/*����:���ÿ��������ÿ��·����slot����ֵ
	 * 	path:ĳ��������·��Ӧ��kPath�ĵ�path��·����path={0,1,..,Parameters.K_PATH-1}
	 * ����ֵ��-1��ʧ�ܣ�û���ҵ����ʵ�slots��;
	 * >=0���ɹ�����slots��
	 */
	public int EffectSlotOnPath(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathSlots,int path,int slotNum,int vLinkNo,VONRequest reqs[],int index)
	{
		if(path < 0) return -1;
		//ĳ��·��shortestPath[vLinkNo][sNode2]��ĳ��slot����,������·vLinkNo
		int vNode1=-1,vNode2=-1,sNode1=-1,sNode2=-1,sNode3=-1,sNode4=-1;
		vNode1 = reqs[index].link[vLinkNo].from;
		vNode2 = reqs[index].link[vLinkNo].to;
		sNode1 = auxGraph.virtualNodes[vNode1];
		sNode2 = auxGraph.virtualNodes[vNode2];
		sNode3 = sNode2;
		
		int slotNumT = slotNum;
		boolean find = true;
		//��slotNumT���pathSlots[vLinkNo][path]��slot�Ƿ�����Ҫ��
		while(slotNumT < auxGraph.slotsNum){//Ƶ��slot����
			find = true;
			//System.out.println(vLinkNo+"-"+path+"-"+sNode3);
			while(kShortestPath[vLinkNo][path][sNode3] != null && kShortestPath[vLinkNo][path][sNode3].parentVert != sNode1 ){
				sNode4 = sNode3;
				sNode3 = kShortestPath[vLinkNo][path][sNode3].parentVert;
				if(sNode4 == sNode1 || sNode4== sNode2 || sNode3 == sNode1 || sNode3==sNode2)
				{
					continue;
				}
				int link = GetLinkNum(auxGraph,sNode4,sNode3);
				
				//����slotNumT��slotNumT+pathSlots[vLinkNo][path]��slots�Ƿ�����Ҫ��
				if(Parameters.DebugModel) System.out.println("auxGraph.slots[][]=");
				int slotSum = 0;
				for(int i = slotNumT;i < slotNumT + pathSlots[vLinkNo][path]&&i<Parameters.MaxSlots; i++)
				{
					slotSum ++;
					//System.out.println(slotNumT+"-"+link);
					if(slotNumT >= auxGraph.slotsNum ) return -1;
					if(Parameters.DebugModel) System.out.println(link+" "+i+":"+auxGraph.slots[link][i]+"\r\n");
					if(auxGraph.slots[link][i] == 0 ) 
					{
						find = false;
						slotNumT ++;
						break;
					}
				}
				if(slotSum < pathSlots[vLinkNo][path]) find = false;
				if(Parameters.DebugModel) System.out.println("find:"+find+" slotNumT:"+slotNumT + " slotSum:"+slotSum + " nPathSlots:"+pathSlots[vLinkNo][path]);
				if(slotSum < pathSlots[vLinkNo][path]) return -1;//find = false;
				
			}
			if(find == true) return slotNumT;
		}
		return -1;
	}   
	
	/*���ÿ��������ÿ��·����MDֵ
	 * CalPathMD(pathMD,pathLength,reqs,index);
	 */
	public boolean CalPathMD(int[][] pathMD,double[][] pathLength,int[] pathEff,VONRequest reqs[],int index)
	{
		boolean find = false;
		for(int i=0; i < reqs[index].links; i++)//ÿ��������·
		{
			for(int j=0; j < pathEff[i]; j++)//ÿ��·��
			{
				pathMD[i][j] = CalMD(reqs[index].link[i].bw,pathLength[i][j]);
				System.out.println("pathMD[][]="+i+" "+j+" " + pathMD[i][j]+" bw:"+reqs[index].link[i].bw+" plen:"+pathLength[i][j]);
				if(pathMD[i][j] > -1) find = true;
			}
		}
		return find;
	}	
	
	
	/*���ÿ��������ÿ��·����slots����
	 * 
	 */
	public void CalculatePathSlotsAndEffects(AuxiliaryGraph auxGraph,DistanceParent[][][] kShortestPath,int[][] pathSlots,int[][] pathLength,int[][] pathNo,int[] pathEff,VONRequest reqs[],int index,double pathLen[][])
	{
		int pathNum = 0;
		double pa[] = new double[1];
		for(int i=0; i < reqs[index].links; i++)//ÿ��������·
		{
			for(int j=0; j < pathEff[i]; j++)//ÿ��·��
			{
				int node1 = auxGraph.virtualNodes[reqs[index].link[i].from];
				int node2 = auxGraph.virtualNodes[reqs[index].link[i].to];
				
				pathSlots[i][j] = GetSlotNumByOnePath(auxGraph,kShortestPath[i][j],j,node1,node2,reqs[index].link[i].bw,pa);//����ÿ��·������Ҫ��slots����
				pathLen[i][j] = pa[0];
				pathLength[i][j] = GetPathJump(auxGraph,kShortestPath[i][j],j,node1,node2);//����ÿ��·���ϵ�����
				//System.out.println(x);
				if(pathLength[i][j] <= 2||pathSlots[i][j] == -1){
					pathNo[i][j] = -1;
					pathNum ++;
				} else {
					pathNo[i][j] = pathNum;
					System.out.println("pathNo["+i+","+j+"]:"+pathNum + " pathJump:"+pathLength[i][j]+" slots:"+pathSlots[i][j]);
					PrintKShortestPath(auxGraph,kShortestPath[i][j],j,node1,node2);
					pathNum ++;
				}
			}
		}
	}	
  	/******************************************************************
	*����:void PreEmbedVLinkByKShortestPath(......)
	*����:Ԥ��ӳ��������·
	*����:reqsΪ����������
	*	  indexΪ��index����������
	*    noEmbedVLinkΪ������·��
	*    vnodeEmbedΪ����ڵ�ӳ����
	*    p[noEmbedVLink][]:������·noEmbedVLinkӳ�������·��
	*	  ret[noEmbedVLink][0]:Ƶ�ײ���ʼ������ret[noEmbedVLink][1]:Ƶ�ײ�����
	*����ֵ: false:δ�ҵ���ʧ�ܷ��أ�
	*    true:��K��·�����ҵ����ʵ�����Ƶ�ײۣ�·��������p[noEmbedVLink],ret[noEmbedVLink][0] = findSlotIndex;ret[noEmbedVLink][1] = slotInPath[i];
	******************************************************************/
	public boolean PreEmbedVLinkByKShortestPath(EOSubstrateNetwork sub,VONRequest reqs[],int index,int noEmbedVLink,int[] vNodeEmbed,int p[][],int ret[][])
	{
		//CreateKShortestPath(sub,reqs,index);
		//�ҵ���Ӧ�������˵�
		int sNode1,sNode2;
		sNode1 = vNodeEmbed[reqs[index].link[noEmbedVLink].from];
		sNode2 = vNodeEmbed[reqs[index].link[noEmbedVLink].to];
		//
		DistanceParent[][] kSPath = new DistanceParent[Parameters.K_PATH][sub.nodes];//�洢k���·�������ݽṹ
		
		int pathRet = -1;
		pathRet = GetKShortestPath(sub,sNode1,sNode2,kSPath);
		
		
		//DistanceParent[][] path = myGraph.kShortestPath;//sNode2----->path[sNode2].parentVert
		double[] pathLength = new double[Parameters.K_PATH];
		int[] slotInPath = new int[Parameters.K_PATH];
		int findSlotIndex = -1;
		int i=0;
		//int pathRet = myPath.size();//·��������
		for(i=0; i<pathRet; i++){//ÿ��·��i
			//��¼·��ӳ��������������·noEmbedVLinkӳ�䵽·��p[noEmbedVLink]
			WeightedDirectedGraph myGraph = new WeightedDirectedGraph(sub.nodes);
			//myGraph.CreateDireGraph(sub.nodes);//�����ڵ�
			myGraph.CreateEdge(sub);//������
			System.out.println("GetPath:"+sNode1+"-"+sNode2);
			myGraph.GetPath(p[noEmbedVLink],sNode2,sNode1,kSPath[i]);//����p
			PrintPath(p[noEmbedVLink],sNode2,sNode1);
			pathLength[i] = GetPathLength(sub, kSPath[i], sNode1, sNode2);//�����·�����ȣ�Ϊ����ļ���Ƶ�ײ���׼��
			System.out.println("path["+i+"].length:"+pathLength[i]);
			slotInPath[i] = CalculateSlots(reqs[index].link[noEmbedVLink].bw,pathLength[i]);//����Ƶ�ײ�����
			if(slotInPath[i] <= 0) continue;
			//����Ƿ�����������Ҫ��
			System.out.println("path["+i+"].length:"+pathLength[i]+" slotsNum:"+slotInPath[i]);
			myGraph.PrintPath(sNode2,sNode1,kSPath[i]);

			findSlotIndex = CheckIfEnoughSlotsOnPath(sub,kSPath[i],0,slotInPath[i],sNode1,sNode2);//Ѱ������Ҫ���Ƶ�ײ�����
			if(findSlotIndex == -1){
				continue;//��ǰ·����Ƶ�ײ�����0��ʼ��û���ҵ���Ӧ������Ƶ�ײ�
			}
			ret[noEmbedVLink][0] = findSlotIndex;
			ret[noEmbedVLink][1] = slotInPath[i];
			break;//�ҵ���·��i��Ƶ�ײ�����findSlotIndex
		}
		if(i == pathRet) return false;//��K��·����û���ҵ����ʵ�����Ƶ�ײ�
		//UpdateSub(subCopy,sNode2,sNode1,ret[i],p[i]);
		else return true;//��K��·�����ҵ����ʵ�����Ƶ�ײۣ�·��������p[noEmbedVLink],ret[noEmbedVLink][0] = findSlotIndex;ret[noEmbedVLink][1] = slotInPath[i];
	}
	
	//�Ը���ͼԤӳ��������·
	public boolean PreEmbedVLinkByAuxiGraph(EOSubstrateNetwork sub,VONRequest reqs[],int index,int noEmbedVLink,int[] vNodeEmbed,int p[][],int ret[][])
	{
		//CreateKShortestPath(sub,reqs,index);
		//�ҵ���Ӧ�������˵�
		int sNode1,sNode2;
		sNode1 = vNodeEmbed[reqs[index].link[noEmbedVLink].from];
		sNode2 = vNodeEmbed[reqs[index].link[noEmbedVLink].to];
		//
		DistanceParent[][] kSPath = new DistanceParent[Parameters.K_PATH][sub.nodes];//�洢k���·�������ݽṹ
		
		int pathRet = -1;
		pathRet = GetKShortestPath(sub,sNode1,sNode2,kSPath);
		
		
		//DistanceParent[][] path = myGraph.kShortestPath;//sNode2----->path[sNode2].parentVert
		double[] pathLength = new double[Parameters.K_PATH];
		int[] slotInPath = new int[Parameters.K_PATH];
		int findSlotIndex = -1;
		int i=0;
		//int pathRet = myPath.size();//·��������
		for(i=0; i<pathRet; i++){//ÿ��·��i
			//��¼·��ӳ��������������·noEmbedVLinkӳ�䵽·��p[noEmbedVLink]
			WeightedDirectedGraph myGraph = new WeightedDirectedGraph(sub.nodes);
			//myGraph.CreateDireGraph(sub.nodes);//�����ڵ�
			myGraph.CreateEdge(sub);//������
			System.out.println("GetPath:"+sNode1+"-"+sNode2);
			myGraph.GetPath(p[noEmbedVLink],sNode2,sNode1,kSPath[i]);//����p
			PrintPath(p[noEmbedVLink],sNode2,sNode1);
			pathLength[i] = GetPathLength(sub, kSPath[i], sNode1, sNode2);//�����·�����ȣ�Ϊ����ļ���Ƶ�ײ���׼��
			System.out.println("path["+i+"].length:"+pathLength[i]);
			slotInPath[i] = CalculateSlots(reqs[index].link[noEmbedVLink].bw,pathLength[i]);//����Ƶ�ײ�����
			if(slotInPath[i] <= 0) continue;
			//����Ƿ�����������Ҫ��
			System.out.println("path["+i+"].length:"+pathLength[i]+" slotsNum:"+slotInPath[i]);
			myGraph.PrintPath(sNode2,sNode1,kSPath[i]);

			findSlotIndex = CheckIfEnoughSlotsOnPath(sub,kSPath[i],0,slotInPath[i],sNode1,sNode2);//Ѱ������Ҫ���Ƶ�ײ�����
			if(findSlotIndex == -1){
				continue;//��ǰ·����Ƶ�ײ�����0��ʼ��û���ҵ���Ӧ������Ƶ�ײ�
			}
			ret[noEmbedVLink][0] = findSlotIndex;
			ret[noEmbedVLink][1] = slotInPath[i];
			break;//�ҵ���·��i��Ƶ�ײ�����findSlotIndex
		}
		if(i == pathRet) return false;//��K��·����û���ҵ����ʵ�����Ƶ�ײ�
		//UpdateSub(subCopy,sNode2,sNode1,ret[i],p[i]);
		else return true;//��K��·�����ҵ����ʵ�����Ƶ�ײۣ�·��������p[noEmbedVLink],ret[noEmbedVLink][0] = findSlotIndex;ret[noEmbedVLink][1] = slotInPath[i];
	}
	
	
    //Save the results of the virtual node embedding.
    public void AddNodesMap(VONRequest reqs[],int index,ArrayList<Object> list)
  	{
  		for(int i=0;i<reqs[index].nodes;i++){
  			int snode = (int)list.get(i);
  			int reqCount = s2v_n[snode].req_count;

  			s2v_n[snode].rest_cpu -= reqs[index].cpu[i];
  			s2v_n[snode].req.add(reqCount,index);//reqid;
  			s2v_n[snode].vnode.add(reqCount,i); //nodeid;
  			s2v_n[snode].cpu.add(reqCount,reqs[index].cpu[i]);// = req[reqid].cpu[nodeid];
  			s2v_n[snode].req_count ++;
  			
  			v2s[index].snode.add(i,snode);
  		}
  	}	
  	
  	/*Save the results of the virtual node embedding.
  	 * 
  	 */
    public void AddNodesMap(VONRequest reqs[],int index,int nodeEmbed[])
  	{
  		for(int i=0;i<reqs[index].nodes;i++){
  			int snode = nodeEmbed[i];//(int)list.get(i);
  			System.out.println(index+":"+reqs[index].nodes+":"+i+":"+snode);
  			int reqCount = s2v_n[snode].req_count;

  			s2v_n[snode].rest_cpu -= reqs[index].cpu[i];
  			s2v_n[snode].req.add(reqCount,index);//reqid;
  			s2v_n[snode].vnode.add(reqCount,i); //nodeid;
  			s2v_n[snode].cpu.add(reqCount,reqs[index].cpu[i]);// = req[reqid].cpu[nodeid];
  			s2v_n[snode].req_count ++;
  			
  			v2s[index].snode.add(i,snode);
  		}
  	}
    
    /*Save the results of the virtual node embedding.
  	 * 
  	 */
    public void AddNodesMapSub(EOSubstrateNetwork sub,VONRequest reqs[],int index,int nodeEmbed[])
  	{
  		for(int i=0;i<reqs[index].nodes;i++){
  			int snode = nodeEmbed[i];//(int)list.get(i);

  			sub.cpu[snode] -= reqs[index].cpu[i];
  		}
  	}
  	
  	
  	//save the result of embedding virtual nodes to the text document.
    public void SaveNodeEmbedding(VONRequest reqs[],int index)
  	{
  		Tools myDowith = new Tools();
  		String data = "";		
  		//for(int index=0;index<reqs.length;index++){
  			for(int i=0;i<reqs[index].nodes;i++){
  				int snode = v2s[index].snode.get(i);
  				data += index + " " + i + " " + snode + "\r\n";				
  			}
  		//}
  	    myDowith.SaveFile("nodeEmbed.dat", data, false);		
  	}
  	
  	public void SaveNodeEmbedding(VONRequest reqs[])
  	{
  		//int index
  		Tools myDowith = new Tools();
  		String data = "";		
  		for(int index=0;index<reqs.length;index++){
  			for(int i=0;i<reqs[index].nodes;i++){
  				int snode = v2s[index].snode.get(i);
  				data += index + " " + i + " " + snode + "\r\n";				
  			}
  		}
  	    myDowith.SaveFile("nodeEmbed.dat", data, false);		
  	}
  	/*��¼��ѡ����*/
  	public void RecordFeasiResolve(Hashtable slotAllocHash,int cut,int pathIndex,int slotNo,int slotNum)
	{
		//��¼		
		String keyNode1;
		keyNode1 = String.valueOf(pathIndex) + "," +String.valueOf(slotNo) + "," + slotNum;		
		slotAllocHash.put(keyNode1,cut);//�Ᵽ����hash����
	}
	
	/*�õ�cut:�㷨�Ǹ��ݸ�slotNo������slot�Ƿ���У�����������1*/
	public int GetCut(EOSubstrateNetwork sub,int p[],int slotNo,int sNode1,int sNode2)
	{
		//ÿ���ߵ�����slot�Ƿ���У�������Ϊ1������Ϊ0��
		int cut = 0,findCut = 0;;
		int linkNum = -1;
		int tmpNode = sNode2;
		while(tmpNode != sNode1){
			cut = 0;
			linkNum = GetLinkNum(sub,p[tmpNode],tmpNode);//�õ�linkNum
			if(sub.slots[linkNum][slotNo] != 1) {
				//����
				System.out.println("GetCut(sub.slots[" + linkNum + "," + slotNo + "]) is error.****************");
				if(Parameters.ErrorRecord){
	  				String str = "GetCut():"+"GetCut(sub.slots[" + linkNum + "," + slotNo + "]) is error."+"\r\n";
					WriteFilePlus("error.txt",str);
		  		}
				break;
			}
			if(slotNo == 0 && sub.slots[linkNum][slotNo+1] == 1) cut++;//�ڶ���slot
			else if(slotNo == sub.slotsNum-1 && sub.slots[linkNum][slotNo-1] == 1) cut++;//���һ��slot
			else if(slotNo < sub.slotsNum -1){
				if(sub.slots[linkNum][slotNo-1] == 1) cut++;//slotNo��һ��slot
				if(sub.slots[linkNum][slotNo+1] == 1) cut++;//slotNo��һ��slot		
			}
			if(cut > 1){
				findCut = 2;
				break;
			}
			if(cut > findCut) findCut = cut;
			tmpNode = p[tmpNode];
		}
		return findCut;
	}
	
	/*
	 * ���ýڵ����߱�ʶ
	 */
	void SetHiberNodes(EOSubstrateNetwork subCopy,VONRequest reqs[],int index,int vLinkNo,int nodeNum,int[] nodeH,int[] nDegree)
	{
		//��ѯnodeH���߱�ʶ
		int nhSum = 0;
		for(int i=0;i<sub.nodes;i++){
			//if(nodeH[i] == 1 && reqs[index].cpu[vLinkNo] <= sub.cpu[i]) nhSum++;
			if(nodeH[i] == 1) nhSum++;
		}
		if(nodeNum <= nhSum) return;
		int degree = 0,maxDeNode=-1;
		while(nodeNum > nhSum){
			maxDeNode = -1;
			degree = 0;
			//�������Ѿ�ӳ��Ľڵ����ӵĶ����Ľڵ�
			for(int j=0;j<sub.links;j++){
				if(nodeH[sub.link[j].from] == 1 && nodeH[sub.link[j].to] == -1){
					if(degree < nDegree[sub.link[j].to]){
						//if(reqs[index].cpu[vLinkNo] <= sub.cpu[sub.link[j].to]){
							maxDeNode = sub.link[j].to;
							degree = nDegree[sub.link[j].to];
						//}
					}
				} else if(nodeH[sub.link[j].to] == 1 && nodeH[sub.link[j].from] == -1){
					if(degree < nDegree[sub.link[j].from]){
						//if(reqs[index].cpu[vLinkNo] <= sub.cpu[sub.link[j].from]){
							maxDeNode = sub.link[j].from;
							degree = nDegree[sub.link[j].from];
						//}
					}
				}
			}
			if(maxDeNode == -1){//˵�����нڵ㶼û���������߱�ʶ
				for(int j=0;j<sub.nodes;j++){
					if(degree < nDegree[j]){
						//if(reqs[index].cpu[vLinkNo] <= sub.cpu[j]){
						//if(reqs[index].cpu[vLinkNo] <= sub.cpu[j]){
							maxDeNode = j;
							degree = nDegree[j];
						//}
					}
				}
			}
			//�������߱�ʶ
			if(maxDeNode > -1) nodeH[maxDeNode] = 1;
			nhSum++;
		}
	}
	
	/*ͨ��(sNode1,sNode2)�õ���·��*/
	public int GetLinkNum(AuxiliaryGraph sub,int sNode1,int sNode2)
	{
		int linkNum = -1;
		for(int i=0;i<sub.links;i++){
			if((sub.link[i].from == sNode1 && sub.link[i].to == sNode2) || (sub.link[i].from == sNode2 && sub.link[i].to == sNode1)) {
				linkNum = i;
				break;
			}
		}
		return linkNum;
	}	
	
	/*��kShortestPath�õ�·��p*/
	public void GetPath(int p[],int sNode1,int sNode2,DistanceParent[]  shortestPath)
	{
		p[sNode1] = -1;
		p[sNode2] = shortestPath[sNode2].parentVert;
				
		while(shortestPath[sNode2].parentVert != sNode1){
			sNode2 = shortestPath[sNode2].parentVert;
			p[sNode2] = shortestPath[sNode2].parentVert;
		}		
	}
	
	/*����K���·���ı�*/
	public void CreateEdge(EOSubstrateNetwork sub,int sNode1,int sNode2,WeightedDirectedGraph myGraph)
	{
		//���ӱ�
		for(int i=0; i<sub.links; i++){
			if(sub.link[i].from == sNode1 && sub.link[i].to == sNode2)
				myGraph.addEdge(sub.link[i].from,sub.link[i].to,1);
			else if(sub.link[i].to == sNode2) 
				myGraph.addEdge(sub.link[i].from,sub.link[i].to,1);
			else if(sub.link[i].from == sNode1) 
				myGraph.addEdge(sub.link[i].from,sub.link[i].to,1);
			else {
				myGraph.addEdge(sub.link[i].from,sub.link[i].to,1);
				myGraph.addEdge(sub.link[i].to,sub.link[i].from,1);
			}
		}
	}
	
	/*Check if the links along the path have enough free slots.
	*>1:successfully;
	*-1:failed.*/
	public int CheckAllPathFreeSlots(EOSubstrateNetwork sub,int linkNum,int slotNo,int slotNum)
	{
		if(slotNum > sub.slotsNum) {
			System.out.println("CheckAllPathFreeSlots is error, slotNum.************************");
			if(Parameters.ErrorRecord){
  				String str = "CheckAllPathFreeSlots():"+"CheckAllPathFreeSlots is error, slotNum."+"\r\n";
				WriteFilePlus("error.txt",str);
	  		}
			return -1;
		}
		if(linkNum > sub.links - 1) {
			System.out.println("CheckAllPathFreeSlots is error, linkNum.************************");
			if(Parameters.ErrorRecord){
  				String str = "CheckAllPathFreeSlots():"+"CheckAllPathFreeSlots is error, slotNum."+"\r\n";
				WriteFilePlus("error.txt",str);
	  		}
			return -1;
		}
		for(int i=slotNo;i<slotNo+slotNum;i++){
			if(i > sub.slotsNum - 1) return -1;			
			if(sub.slots[linkNum][i] != 1) return -1;
		}
		return 1;
	}
  	/*
	 * ����:����p
	 * ����:retSlotSE[]:��ʼ����
	 *     retSlotEE[]:��������
	 *     retLinkE[]:��·ӳ����
	 *     kShortestPath[][][]:���·������
	 *     pathEff[]:ÿ������·��ӳ�����Ч·������
	 *     pathNo[][]:·���ı��
	 *     virtualNodes[]:����ڵ�ӳ�����չͼ�ڵ���
	 *     retNodeE[]:�ڵ�ӳ��
	 * ������:������
	* ����ʱ��:2017-09-28*/
	public void CreateShortestPathFromKPaths(VONRequest reqs[],int index,DistanceParent kShortestPath[][][],int virtualNodes[],int retLinkE[],int pathEff[],int p[][])
	{
		for(int i=0;i<reqs[index].links;i++){
			int sNode1 = virtualNodes[reqs[index].link[i].from];//������·�˵�from��Ӧ�ĸ���ͼ�ڵ���
			int sNode2 = virtualNodes[reqs[index].link[i].to];//������·�˵�to��Ӧ�ĸ���ͼ�ڵ���
			int sLinkNo = retLinkE[i];//��·ӳ���·�����
			int pathNo1 = 0;
			boolean find = false;
			int vLinkNo = 0;
			int pathByLink = 0;
			for(vLinkNo=0;vLinkNo<reqs[index].links;vLinkNo++){
				find = false;
				for(pathByLink=0;pathByLink<pathEff[vLinkNo];pathByLink++){
					if(pathNo1 == sLinkNo){//�ҵ���·��kShortestPath[k][j]
						//����·��kShortestPath[k][j]������p
						find = true;
						break;
					}
					pathNo1++;
				}
				if(find) break;
			}
			//��ʼ��p[][]
			int sNode3 = sNode2;
			while(kShortestPath[vLinkNo][pathByLink][sNode3].parentVert != sNode1){
				if(sNode3 != sNode2){//���������˵�
					p[i][sNode3] = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
				}
				sNode3 = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
			}
			//p[i][sNode3] = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
		}
	}
    /*����Sub���������
     * ����sub;2������S2VLink s2v_l[] = new S2VLink[reqs[index].links];
     * 3������v2s
  	*/
  	public void AddLinksMapBySPFA(EOSubstrateNetwork sub,VONRequest reqs[],int index,int ret[][],int p[][])
  	{
  		//1���ڵ�ӳ�䣬����sub.slots;
  		for(int i=0;i<reqs[index].links;i++){
  			int snode1,snode2,vnode1,vnode2;
  			vnode1 = reqs[index].link[i].from;
  			vnode2 = reqs[index].link[i].to;
  			snode1 = v2s[index].snode.get(vnode1);
  			snode2 = v2s[index].snode.get(vnode2);
  			UpdateSub(sub,snode2,snode1,ret[i],p[i]);	
  		}
  			
  		//2������S2VLink s2v_l[]
  		int snodeMid1,snodeMid,sNode1,req_count;
  		for(int i=0;i<reqs[index].links;i++){
  			snodeMid1 = reqs[index].link[i].to;
  			sNode1 = reqs[index].link[i].from;
  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  			
  			if(p[i][snodeMid1] == -1){
  				snodeMid1 = reqs[index].link[i].from;
  				sNode1 = reqs[index].link[i].to;
  	  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  	  			if(p[i][snodeMid1] == -1){
  	  				System.out.println("error!************* in AddLinksMapBySPFA1"+" reqs[" + index+"]");
  	  				if(Parameters.ErrorRecord){
  	  					String str = "reqs["+index+"] AddLinksMapBySPFA():"+"error1."+"\r\n";
  	  					WriteFilePlus("error.txt",str);
  	  				}
  	  			}
  			}
  			
  			sNode1 = v2s[index].snode.get(sNode1);
  			while(p[i][snodeMid1] != -1) {
  				snodeMid = p[i][snodeMid1];//
  				req_count = s2v_l[sub.linksNo[snodeMid][snodeMid1]].req_count;
  				System.out.println("linkNo:"+sub.linksNo[snodeMid][snodeMid1]+" "+req_count+" "+index);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].req.add(req_count,index);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].bw.add(req_count,reqs[index].link[i].bw);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].vlink.add(req_count,i);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].rest_bw -=  reqs[index].link[i].bw;
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].req_count ++;
  					
  				snodeMid1 = snodeMid;
  				if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����	
  			}	
  		}
  			
  		//3������v2s[]����·ӳ����Ϣ
  		int pathLength = 0;
  			
  		for(int i=0;i<reqs[index].links;i++){
  			snodeMid1 = reqs[index].link[i].to;
  			sNode1 = reqs[index].link[i].from;
  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  			
  			if(p[i][snodeMid1] == -1){
  				snodeMid1 = reqs[index].link[i].from;
  				sNode1 = reqs[index].link[i].to;
  	  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  	  			if(p[i][snodeMid1] == -1){
  	  				System.out.println("error!************* in AddLinksMapBySPFA2");
  	  				if(Parameters.ErrorRecord){
	  					String str = "reqs["+index+"] AddLinksMapBySPFA():"+"error2."+"\r\n";
	  					WriteFilePlus("error.txt",str);
	  				}
  	  			}
  			}
  			
  			sNode1 = v2s[index].snode.get(sNode1);
  			
  			if(Parameters.DebugModel) System.out.println("snodeMid1:"+snodeMid1);
  			//sNode1 = v2s[index].snode.get(sNode1);
  			
  			pathLength = 0;
  			LinkedList<Integer> link = new LinkedList<Integer>();
  			while(p[i][snodeMid1] != -1) {
  				snodeMid = p[i][snodeMid1];
  				link.add(pathLength,snodeMid1);				
  				pathLength++;	//·������
  					
  				snodeMid1 = snodeMid;
  				//if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
  			}
  			link.add(pathLength,snodeMid1);	
  				
  			SpathFlow pathFlow = new SpathFlow();
  			pathFlow.link = link;
  			pathFlow.len = pathLength;
  			if(Parameters.DebugModel) System.out.println("vlink:"+i+" pathLength:"+pathLength);
  			
  			if(p[i][reqs[index].link[i].to] != -1){
  				snodeMid1 = reqs[index].link[i].to;
  			} else {
  				snodeMid1 = reqs[index].link[i].from;
  			}
  			
  			snodeMid1 = reqs[index].link[i].to;
  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  			
  			if(p[i][snodeMid1] == -1){
  				snodeMid1 = reqs[index].link[i].from;
  	  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  	  			if(p[i][snodeMid1] == -1){
  	  				System.out.println("error!************* in AddLinksMapBySPFA3");
  	  				if(Parameters.ErrorRecord){
  	  					String str = "reqs["+index+"] AddLinksMapBySPFA():"+"error3."+"\r\n";
  	  					WriteFilePlus("error.txt",str);
  	  				}
  	  			}
  			}
  			
  			//snodeMid1 = v2s[index].snode.get(snodeMid1);
  			for(int ii=0;ii<pathLength;ii++){
  				snodeMid = p[i][snodeMid1];
  				//System.out.print(snodeMid1+"-");
  				snodeMid1 = snodeMid;
  			}
  			//System.out.print(snodeMid1);
  			//System.out.println("");
  				
  			pathFlow.bw = reqs[index].link[i].bw;
  			v2s[index].pathFlow.add(i,pathFlow);
  			v2s[index].flowLen.add(i,1);//1����·����·ӳ�䣻i����i����·��
  			v2s[index].startSlotNo.add(i,ret[i][0]);//�������ʼ����
  			System.out.println("v2s[].slotNum:"+(ret[i][1]-ret[i][0]+1));
  			v2s[index].slotNum.add(i,ret[i][1]-ret[i][0]+1);	//�����ɣ���Ϊret[i][1]�ǽ�ֹƵ�ײ����������������������Ƶ������v2s[i].slotNum.get(j)
  		}
  		//����ӳ��ɹ���־
  		v2s[index].map = Parameters.STATE_MAP_LINK;
  		reqs[index].map = Parameters.STATE_MAP_LINK;
  	}
  	
  	/*����Sub���������
     * ����sub;2������S2VLink s2v_l[] = new S2VLink[reqs[index].links];
     * 3������v2s
  	*/
  	public void AddLinksMapBySPFANoSlots(EOSubstrateNetwork sub,VONRequest reqs[],int index,int ret[][],int p[][])
  	{
  		/*
  		//1���ڵ�ӳ�䣬����sub.slots;
  		for(int i=0;i<reqs[index].links;i++){
  			int snode1,snode2,vnode1,vnode2;
  			vnode1 = reqs[index].link[i].from;
  			vnode2 = reqs[index].link[i].to;
  			snode1 = v2s[index].snode.get(vnode1);
  			snode2 = v2s[index].snode.get(vnode2);
  			UpdateSub(sub,snode2,snode1,ret[i],p[i]);	
  		}
  		*/
  			
  		//2������S2VLink s2v_l[]
  		int snodeMid1,snodeMid,sNode1,req_count;
  		for(int i=0;i<reqs[index].links;i++){
  			snodeMid1 = reqs[index].link[i].to;
  			sNode1 = reqs[index].link[i].from;
  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  			
  			if(p[i][snodeMid1] == -1){
  				snodeMid1 = reqs[index].link[i].from;
  				sNode1 = reqs[index].link[i].to;
  	  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  	  			if(p[i][snodeMid1] == -1){
  	  				System.out.println("error!************* in AddLinksMapBySPFA");
  	  				if(Parameters.ErrorRecord){
  	  					String str = "reqs["+index+"] AddLinksMapBySPFA():"+"error1."+"\r\n";
  	  					WriteFilePlus("error.txt",str);
  	  				}
  	  			}
  			}
  			
  			sNode1 = v2s[index].snode.get(sNode1);
  			while(p[i][snodeMid1] != -1) {
  				snodeMid = p[i][snodeMid1];//
  				req_count = s2v_l[sub.linksNo[snodeMid][snodeMid1]].req_count;
  				System.out.println("linkNo:"+sub.linksNo[snodeMid][snodeMid1]+" "+req_count+" "+index);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].req.add(req_count,index);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].bw.add(req_count,reqs[index].link[i].bw);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].vlink.add(req_count,i);
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].rest_bw -=  reqs[index].link[i].bw;
  				s2v_l[sub.linksNo[snodeMid][snodeMid1]].req_count ++;
  					
  				snodeMid1 = snodeMid;
  				if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����	
  			}	
  		}
  			
  		//3������v2s[]����·ӳ����Ϣ
  		int pathLength = 0;
  			
  		for(int i=0;i<reqs[index].links;i++){
  			snodeMid1 = reqs[index].link[i].to;
  			sNode1 = reqs[index].link[i].from;
  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  			
  			if(p[i][snodeMid1] == -1){
  				snodeMid1 = reqs[index].link[i].from;
  				sNode1 = reqs[index].link[i].to;
  	  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  	  			if(p[i][snodeMid1] == -1){
  	  				System.out.println("error!*************");
  	  				if(Parameters.ErrorRecord){
	  					String str = "reqs["+index+"] AddLinksMapBySPFA():"+"error2."+"\r\n";
	  					WriteFilePlus("error.txt",str);
	  				}
  	  			}
  			}
  			
  			sNode1 = v2s[index].snode.get(sNode1);
  			
  			if(Parameters.DebugModel) System.out.println("snodeMid1:"+snodeMid1);
  			//sNode1 = v2s[index].snode.get(sNode1);
  			
  			pathLength = 0;
  			LinkedList<Integer> link = new LinkedList<Integer>();
  			while(p[i][snodeMid1] != -1) {
  				snodeMid = p[i][snodeMid1];
  				link.add(pathLength,snodeMid1);				
  				pathLength++;	//·������
  					
  				snodeMid1 = snodeMid;
  				//if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
  			}
  			link.add(pathLength,snodeMid1);	
  				
  			SpathFlow pathFlow = new SpathFlow();
  			pathFlow.link = link;
  			pathFlow.len = pathLength;
  			if(Parameters.DebugModel) System.out.println("vlink:"+i+" pathLength:"+pathLength);
  			
  			if(p[i][reqs[index].link[i].to] != -1){
  				snodeMid1 = reqs[index].link[i].to;
  			} else {
  				snodeMid1 = reqs[index].link[i].from;
  			}
  			
  			snodeMid1 = reqs[index].link[i].to;
  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  			
  			if(p[i][snodeMid1] == -1){
  				snodeMid1 = reqs[index].link[i].from;
  	  			snodeMid1 = v2s[index].snode.get(snodeMid1);
  	  			if(p[i][snodeMid1] == -1){
  	  				System.out.println("error!*************");
  	  				if(Parameters.ErrorRecord){
  	  					String str = "reqs["+index+"] AddLinksMapBySPFA():"+"error3."+"\r\n";
  	  					WriteFilePlus("error.txt",str);
  	  				}
  	  			}
  			}
  			
  			//snodeMid1 = v2s[index].snode.get(snodeMid1);
  			for(int ii=0;ii<pathLength;ii++){
  				snodeMid = p[i][snodeMid1];
  				//System.out.print(snodeMid1+"-");
  				snodeMid1 = snodeMid;
  			}
  			//System.out.print(snodeMid1);
  			//System.out.println("");
  				
  			pathFlow.bw = reqs[index].link[i].bw;
  			v2s[index].pathFlow.add(i,pathFlow);
  			v2s[index].flowLen.add(i,1);//1����·����·ӳ�䣻i����i����·��
  			v2s[index].startSlotNo.add(i,ret[i][0]);//�������ʼ����
  			v2s[index].slotNum.add(i,ret[i][1]-ret[i][0]+1);	//�����ɣ���Ϊret[i][1]�ǽ�ֹƵ�ײ����������������������Ƶ������v2s[i].slotNum.get(j)
  		}
  		//����ӳ��ɹ���־
  		v2s[index].map = Parameters.STATE_MAP_LINK;
  		reqs[index].map = Parameters.STATE_MAP_LINK;
  	}
    /* ���ƣ�UpdateSub()
     * ���ܣ�����Sub���������
     * ������sub���ײ�����磻sNode1->sNode2��·���������˵㣻ret[0]-ret[1]����ʼ�ͽ�ֹ��Ƶ�ײ�������p[]��·��
     */
  	public void UpdateSub(EOSubstrateNetwork sub,int sNode1,int sNode2,int ret[],int p[])
  	{
  		
  		if(Parameters.DebugModel) System.out.println("UpdateSub "+sNode1+"-"+sNode2+":"+ret[0]+" "+ret[1]);
  				
  		int snodeMid1,snodeMid;
  		//snodeMid1 = sNode2;
  		snodeMid1 = sNode1;
  		while(p[snodeMid1] != -1) {		
  			if(Parameters.DebugModel) System.out.println(snodeMid1+"-"+p[snodeMid1]);
  			snodeMid = p[snodeMid1];
  			int kk = sub.linksNo[snodeMid][snodeMid1];
  			
  			if(Parameters.RecordLogModel){
  				int pa = ret[1];
				String str = "update sub.slots["+kk+"]["+ret[0]+"-"+pa+"]=0\r\n";
				WriteFilePlus("process.txt",str);
			}
  			if(ret[0] <= ret[1]){
  				for(int i=ret[0];i<=ret[1];i++){
  	  				if(i<0) continue;
  	  				if(i >= Parameters.MaxSlots) break;
  	  				//System.out.println("linksNo["+snodeMid+","+snodeMid1+"]="+kk+" i:"+i);
  	  				sub.slots[kk][i] = 0;
  	  			}
  			} else {
  				System.out.println("ret[0]>ret[1] because ret[0] mush little equal ret[1]"+"Error***********");
  				return ;
  				/*
  				for(int i=ret[1];i<ret[0];i++){
  	  				if(i<0) continue;
  	  				if(i >= Parameters.MaxSlots) break;
  	  				//System.out.println("linksNo["+snodeMid+","+snodeMid1+"]="+kk+" i:"+i);
  	  				sub.slots[kk][i] = 0;
  	  			}*/
  			}
  			snodeMid1 = snodeMid;
  			if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
  		}
  		snodeMid1 = sNode2;
  		while(p[snodeMid1] != -1) {		
  			if(Parameters.DebugModel) System.out.println(snodeMid1+"-"+p[snodeMid1]);
  			snodeMid = p[snodeMid1];
  			//for(int i=ret[0];i<ret[0]+ret[1];i++){
  			int kk = sub.linksNo[snodeMid][snodeMid1];
  			if(Parameters.RecordLogModel){
  				int pa = ret[1];
				String str = "update sub.slots["+kk+"]["+ret[0]+"-"+pa+"]=0\r\n";
				WriteFilePlus("process.txt",str);
			}
  			if(ret[0] <= ret[1]) {
  				for(int i=ret[0];i<=ret[1];i++){
  	  				if(i<0) continue;
  	  				if(i >= Parameters.MaxSlots) break;
  	  				
  	  				if(Parameters.DebugModel) System.out.println("linksNo["+snodeMid+","+snodeMid1+"]="+kk+" i:"+i);
  	  				sub.slots[kk][i] = 0;
  	  			}
  			} else {
  				System.out.println("ret[0]>ret[1] because ret[0] mush little equal ret[1]"+"Error***********");
  				return ;
  				/*
  				for(int i=ret[1];i<ret[0];i++){
  	  				if(i<0) continue;
  	  				if(i >= Parameters.MaxSlots) break;
  	  				
  	  				if(Parameters.DebugModel) System.out.println("linksNo["+snodeMid+","+snodeMid1+"]="+kk+" i:"+i);
  	  				sub.slots[kk][i] = 0;
  	  			}
  	  			*/
  			}
  			snodeMid1 = snodeMid;
  			if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
  		}
  		if(Parameters.DebugModel) System.out.println("UpdateSub is done.");

  	}
  	
  	/* ���ƣ�UpdateSub()
     * ���ܣ�����Sub���������
     * ������sub���ײ�����磻sNode1->sNode2��·���������˵㣻ret[0]-ret[1]����ʼ�ͽ�ֹ��Ƶ�ײ�������p[]��·��
     */
  	public boolean CheckSubSlots(EOSubstrateNetwork sub,int sNode1,int sNode2,int ret[],int p[])
  	{
  		
  		if(Parameters.DebugModel) System.out.println("CheckSubSlots "+sNode1+"-"+sNode2+":"+ret[0]+" "+ret[1]);
  				
  		int snodeMid1,snodeMid;
  		//snodeMid1 = sNode2;
  		snodeMid1 = sNode1;
  		while(p[snodeMid1] != -1) {		
  			if(Parameters.DebugModel) System.out.println(snodeMid1+"-"+p[snodeMid1]);
  			snodeMid = p[snodeMid1];
  			int kk = sub.linksNo[snodeMid][snodeMid1];
  			
  			if(Parameters.RecordLogModel){
  				int pa = ret[1];
				String str = "Check sub.slots["+kk+"]["+ret[0]+"-"+pa+"]=0\r\n";
				WriteFilePlus("process.txt",str);
			}
  			if(ret[0] <= ret[1]){
  				for(int i=ret[0];i<=ret[1];i++){
  	  				if(i<0) continue;
  	  				if(i >= Parameters.MaxSlots) break;
  	  				//System.out.println("linksNo["+snodeMid+","+snodeMid1+"]="+kk+" i:"+i);
  	  				if(sub.slots[kk][i] == 0){
  	  					return false;
  	  				}
  	  				sub.slots[kk][i] = 0;
  	  			}
  			} else {
  				System.out.println("ret[0]>ret[1] because ret[0] mush little equal ret[1]"+"Error***********");
  				return false;
  			}
  			snodeMid1 = snodeMid;
  			if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
  		}
  		snodeMid1 = sNode2;
  		while(p[snodeMid1] != -1) {		
  			if(Parameters.DebugModel) System.out.println(snodeMid1+"-"+p[snodeMid1]);
  			snodeMid = p[snodeMid1];
  			//for(int i=ret[0];i<ret[0]+ret[1];i++){
  			int kk = sub.linksNo[snodeMid][snodeMid1];
  			if(Parameters.RecordLogModel){
  				int pa = ret[1];
				String str = "Check sub.slots["+kk+"]["+ret[0]+"-"+pa+"]=0\r\n";
				WriteFilePlus("process.txt",str);
			}
  			if(ret[0] <= ret[1]) {
  				for(int i=ret[0];i<=ret[1];i++){
  	  				if(i<0) continue;
  	  				if(i >= Parameters.MaxSlots) break;
  	  				
  	  				if(Parameters.DebugModel) System.out.println("linksNo["+snodeMid+","+snodeMid1+"]="+kk+" i:"+i);
  	  				if(sub.slots[kk][i] == 0) return false;
  	  				sub.slots[kk][i] = 0;
  	  			}
  			} else {
  				System.out.println("ret[0]>ret[1] because ret[0] mush little equal ret[1]"+"Error***********");
  				return false;
  			}
  			snodeMid1 = snodeMid;
  			if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
  		}
  		if(Parameters.DebugModel) System.out.println("UpdateSub is done.");
  		return true;
  	}
    /* ���ƣ�CheckIfEnoughSlotsOnPath
  	 * ���ܣ����ݹ�·������Ƿ����㹻������Ƶ�ײۣ����������۵�Ҫ��
  	 * ������sub���ײ�����磻path��·����slotNo����ʼƵ�ײ�������slotNum�������Ƶ�ײ�����
  	 *      sNode1\sNode2��·���������˵㣻
  	 * ����ֵ��-1��ʧ�ܷ��أ�>-1���ɹ�����Ƶ�ײ�������
  	 * �����ˣ�������
  	 * ����ʱ�䣺2019.1.7
  	 */
  	public int CheckIfEnoughSlotsOnPath(EOSubstrateNetwork sub,DistanceParent[] path,int slotNo,int slotNum,int sNode1,int sNode2)
  	{
  		boolean checkIf = true;
  		//if(path[sNode2] == null) return 0;
  		//if(path[sNode1] == null) return 0;
  		for(int i=slotNo;i<sub.slotsNum;i++){
  			if(path[sNode2] == null) break;
  			int sNode3 = sNode2;
  			checkIf = true;
  			if(path[sNode3].parentVert != -1){
  				while(path[sNode3].parentVert != sNode1){
  	  	  			int linkIndex = GetLinkNum(sub,sNode3,path[sNode3].parentVert);
  	  	  			if(CheckIfEnoughSlotsOnLink(sub,linkIndex,i,slotNum) == -1) {//���Ƶ�ײ��Ƿ�����Ҫ��
  	  	  				checkIf = false;
  	  	  				break;//������Ҫ��
  	  	  			}
  	  	  			sNode3 = path[sNode3].parentVert;
  	  	  		}
  				if(!checkIf) continue;
  				//���sNode3->path[sNode3].parentVert
  				int linkIndex = GetLinkNum(sub,sNode3,path[sNode3].parentVert);
  				if(CheckIfEnoughSlotsOnLink(sub,linkIndex,i,slotNum) == -1) {//���Ƶ�ײ��Ƿ�����Ҫ��
  	  				checkIf = false;
  	  			}
  			}
  			if(checkIf) return i;
  		}
  		for(int i=slotNo;i<sub.slotsNum;i++){
  			if(path[sNode1] == null) break;
  			int sNode3 = sNode1;
  			checkIf = true;
  			if(path[sNode3].parentVert != -1){
  				while(path[sNode3].parentVert != sNode2){
  	  	  			int linkIndex = GetLinkNum(sub,sNode3,path[sNode3].parentVert);
  	  	  			if(CheckIfEnoughSlotsOnLink(sub,linkIndex,i,slotNum) == -1) {//���Ƶ�ײ��Ƿ�����Ҫ��
  	  	  				checkIf = false;
  	  	  				break;//������Ҫ��
  	  	  			}
  	  	  			sNode3 = path[sNode3].parentVert;
  	  	  		}
  				//���sNode3->path[sNode3].parentVert
  				int linkIndex = GetLinkNum(sub,sNode3,path[sNode3].parentVert);
  				if(CheckIfEnoughSlotsOnLink(sub,linkIndex,i,slotNum) == -1) {//���Ƶ�ײ��Ƿ�����Ҫ��
  	  				checkIf = false;
  	  			}
  			}
  			if(checkIf) return i;
  		}
  		
  		return -1;
  	}
  	/******************************************************************
  	*���ƣ�AuxiliaryGraph CreateAuxiliaryDiagram(......)
  	*���ܣ���ILPģ�ͣ�WangY��Ϊ��������������ͼ
  	*������	  subΪ���Թ�����
  	*	      indexΪ��index����������
  	*����ֵ��AuxiliaryGraph
  	*******************************************************************/
  	public AuxiliaryGraph CreateAuxiliaryDiagram(EOSubstrateNetwork sub,VONRequest reqs[],int index)
  	{
  		AuxiliaryGraph auxGraph = new AuxiliaryGraph();
  		auxGraph.cpu = sub.cpu;
  		auxGraph.diffSlot = sub.diffSlot;
  		auxGraph.faNodes = sub.faNodes;
  		auxGraph.faNodesNum = sub.faNodesNum;
  		
  		auxGraph.links = sub.links + reqs[index].links;
  		auxGraph.linksNo = sub.linksNo;
  		auxGraph.modulationLevel = sub.modulationLevel;
  		auxGraph.modulevel = sub.modulevel;
  		auxGraph.nodes = sub.nodes + reqs[index].nodes;
  		auxGraph.opticalReach = sub.opticalReach;
  		auxGraph.slotGHz = sub.slotGHz;
  		auxGraph.slots = sub.slots;
  		auxGraph.slotsNum = sub.slotsNum;
  		auxGraph.transRate = sub.transRate;
  		//auxGraph.virtServLinks = sub.virtServLinks;
  		//auxGraph.virtualNodes = sub.virtualNodes;
  		auxGraph.netNodes = sub.nodes - sub.faNodesNum;
  		
  		
  		auxGraph.virtualNodes= new int[reqs[index].nodes];
  		for(int i=sub.nodes,j=0;i < sub.nodes + reqs[index].nodes; i++,j++)
  		{
  			auxGraph.virtualNodes[j] = i;//����ڵ��ڸ���ͼ�еĽڵ��
  		}
  		//�����ߣ�����ڵ���fNode֮�����·����CPU�͵���λ��
  		int auxLinkNum = 0;//����������
  		//���㸨��������
  		for(int i=0; i < reqs[index].nodes; i++){
  			for(int k=0;k<sub.faNodesNum;k++){
  				if(reqs[index].cpu[i] <= auxGraph.cpu[auxGraph.faNodes[k]]){
  				//if(auxGraph.cpu[auxGraph.virtualNodes[i]] <= auxGraph.cpu[auxGraph.faNodes[k]]){
  					auxLinkNum++;
  				}
  			}
  		}
  		auxGraph.links = sub.links + reqs[index].links + auxLinkNum - 1;
  		auxGraph.link = new LinkStruct[sub.links + reqs[index].links + auxLinkNum - 1];//;
  		for(int i = 0; i < sub.links; i ++)
  		{
  			auxGraph.link[i] = sub.link[i];
  		}
  		for(int i = sub.links; i < sub.links + reqs[index].links + auxLinkNum - 1; i ++)
  		{
  			auxGraph.link[i] = new LinkStruct();
  		}
  		
  		auxGraph.virtServLinks = new LinkStruct[auxLinkNum];//����ռ�
  		for(int i = 0; i < auxLinkNum; i ++)
  		{
  			auxGraph.virtServLinks[i] = new LinkStruct();
  		}
  		
  		//auxGraph.virtServLinks = new LinkStruct[auxLinkNum];//����ռ�
  		int auxLinkID = sub.links + reqs[index].links - 1;//auxGraph.links;
  		int virtualServeLink = 0;
  		for(int i=0; i < reqs[index].nodes; i++){
  			for(int k=0;k<sub.faNodesNum;k++){
  				if(reqs[index].cpu[i] <= auxGraph.cpu[auxGraph.faNodes[k]]){
  				//if(auxGraph.cpu[auxGraph.virtualNodes[i]] <= auxGraph.cpu[auxGraph.faNodes[k]]){
  					//���CPU��������������·����
  					auxGraph.link[auxLinkID].from = auxGraph.virtualNodes[i];
  					auxGraph.link[auxLinkID].to = auxGraph.faNodes[k];
  					auxGraph.link[auxLinkID].bw = 10000;//�����ߵ�������������
  					auxGraph.link[auxLinkID].length = 0;
  					
  					auxGraph.virtServLinks[virtualServeLink].from = auxGraph.virtualNodes[i];
  					auxGraph.virtServLinks[virtualServeLink].to = auxGraph.faNodes[k];
  					auxGraph.virtServLinks[virtualServeLink].bw = 10000;
  					auxGraph.virtServLinks[virtualServeLink].length = 0;
  					virtualServeLink ++;
  					auxLinkID ++;
  				}
  			}
  		}
  		for(int i=0;i<sub.links;i++){
  			for(int j=0;j<Parameters.MaxSlots;j++){
  				auxGraph.slots[i][j] = sub.slots[i][j];
  			}
  		}
  		
  		
  		auxGraph.serverNodes = sub.faNodes;
  		
  		return auxGraph;
  	}
  	
  	/******************************************************************
  	*���ƣ�AuxiliaryGraph CreateAuxiliaryDiagram(......)
  	*���ܣ���ILPģ�ͣ�WangY��Ϊ��������������ͼ
  	*������	  subΪ���Թ�����
  	*	      indexΪ��index����������
  	*����ֵ��AuxiliaryGraph
  	*�����ˣ���������2019.1.14
  	*******************************************************************/
  	public AuxiliaryGraph CreateAuxiliaryDiagramBy(EOSubstrateNetwork sub,VONRequest reqs[],int index,int vNode1,int vNode2,int sNode1,int sNode2)
  	{
  		AuxiliaryGraph auxGraph = new AuxiliaryGraph();
  		auxGraph.cpu = sub.cpu;
  		auxGraph.diffSlot = sub.diffSlot;
  		auxGraph.faNodes = sub.faNodes;
  		auxGraph.faNodesNum = sub.faNodesNum;
  		
  		auxGraph.links = sub.links + reqs[index].links;
  		auxGraph.linksNo = sub.linksNo;
  		auxGraph.modulationLevel = sub.modulationLevel;
  		auxGraph.modulevel = sub.modulevel;
  		auxGraph.nodes = sub.nodes + reqs[index].nodes;
  		auxGraph.opticalReach = sub.opticalReach;
  		auxGraph.slotGHz = sub.slotGHz;
  		auxGraph.slots = sub.slots;
  		auxGraph.slotsNum = sub.slotsNum;
  		auxGraph.transRate = sub.transRate;
  		//auxGraph.virtServLinks = sub.virtServLinks;
  		//auxGraph.virtualNodes = sub.virtualNodes;
  		auxGraph.netNodes = sub.nodes - sub.faNodesNum;
  		
  		
  		auxGraph.virtualNodes= new int[reqs[index].nodes];
  		for(int i=sub.nodes,j=0;i < sub.nodes + reqs[index].nodes; i++,j++)
  		{
  			auxGraph.virtualNodes[j] = i;//����ڵ��ڸ���ͼ�еĽڵ��
  		}
  		//�����ߣ�����ڵ���fNode֮�����·����CPU�͵���λ��
  		int auxLinkNum = 0;//����������
  		//���㸨��������
  		auxLinkNum ++;
  		auxLinkNum ++;
  		/*for(int i=0; i < reqs[index].nodes; i++){
  			for(int k=0;k<sub.faNodesNum;k++){
  				if(reqs[index].cpu[i] <= auxGraph.cpu[auxGraph.faNodes[k]]){
  				//if(auxGraph.cpu[auxGraph.virtualNodes[i]] <= auxGraph.cpu[auxGraph.faNodes[k]]){
  					auxLinkNum++;
  				}
  			}
  		}*/
  		auxGraph.links = sub.links + auxLinkNum - 1;
  		auxGraph.link = new LinkStruct[sub.links + auxLinkNum - 1];//;
  		for(int i = 0; i < sub.links; i ++)
  		{
  			auxGraph.link[i] = sub.link[i];
  		}
  		for(int i = sub.links; i < sub.links + auxLinkNum - 1; i ++)
  		{
  			auxGraph.link[i] = new LinkStruct();
  		}
  		
  		auxGraph.virtServLinks = new LinkStruct[auxLinkNum];//����ռ�
  		for(int i = 0; i < auxLinkNum; i ++)
  		{
  			auxGraph.virtServLinks[i] = new LinkStruct();
  		}
  		
  		//auxGraph.virtServLinks = new LinkStruct[auxLinkNum];//����ռ�
  		int auxLinkID = sub.links - 1;//auxGraph.links;
  		int virtualServeLink = 0;
  		auxGraph.link[auxLinkID].from = vNode1;
		auxGraph.link[auxLinkID].to = sNode1;
		auxGraph.link[auxLinkID].bw = 0;//�����ߵ�������������
		auxGraph.link[auxLinkID].length = 1;
			
		auxGraph.virtServLinks[virtualServeLink].from = vNode1;
		auxGraph.virtServLinks[virtualServeLink].to = sNode1;
		auxGraph.virtServLinks[virtualServeLink].bw = 0;
		auxGraph.virtServLinks[virtualServeLink].length = 1;
		virtualServeLink ++;
		auxLinkID ++;
		
		auxGraph.link[auxLinkID].from = vNode2;
		auxGraph.link[auxLinkID].to = sNode2;
		auxGraph.link[auxLinkID].bw = 0;//�����ߵ�������������
		auxGraph.link[auxLinkID].length = 1;
			
		auxGraph.virtServLinks[virtualServeLink].from = vNode2;
		auxGraph.virtServLinks[virtualServeLink].to = sNode2;
		auxGraph.virtServLinks[virtualServeLink].bw = 0;
		auxGraph.virtServLinks[virtualServeLink].length = 1;
  		
  		auxGraph.serverNodes = sub.faNodes;
  		
  		return auxGraph;
  	}
  	/* ���ƣ�CheckIfEnoughSlotsOnLink
  	 * ���ܣ�������·�š�Ƶ�ײۺš�Ƶ�ײ������͸���ۣ��ж���·�Ƿ�����������Ҫ��
  	 * ������sub���ײ�����磻linkNum����·�ţ�slotNo��Ƶ�ײۺţ�slotNum��Ƶ�ײ�����
  	 * ����ֵ��-1��ʧ�ܷ��أ�1������Ҫ��
  	 * �����ˣ�������
  	 * ����ʱ�䣺2019.1.7
  	 */
  	public int CheckIfEnoughSlotsOnLink(EOSubstrateNetwork sub,int linkNum,int slotNo,int slotNum)
  	{
  		//�������
  		if(linkNum < 0 || slotNo < 0 || slotNum < 0) return -1;
  		if(slotNum > sub.slotsNum) {
  			if(Parameters.DebugModel) {
  				System.out.println("CheckAllPathFreeSlots is error, slotNum.************************");
  			}
  			if(Parameters.ErrorRecord){
  				String str = "CheckIfEnoughSlotsOnLink():"+"error1, slotNum."+"\r\n";
				WriteFilePlus("error.txt",str);
			}
  			return -1;
  		}
  		if(linkNum > sub.links - 1) {
  			if(Parameters.DebugModel) {
  				System.out.println("CheckIfEnoughSlotsOnLink is error, linkNum.************************");
  			}
  			if(Parameters.ErrorRecord){
  				String str = "CheckIfEnoughSlotsOnLink():"+"error2, slotNum."+"\r\n";
				WriteFilePlus("error.txt",str);
			}
  			return -1;
  		}
  		//���е�·���ϼ���Ƿ����㹻������Ƶ�ײ�
  		if(slotNo>0 && sub.slots[linkNum][slotNo-1]!=1) return -1;//������ڽӵ�Ƶ�ײ��Ƿ�����Ҫ��
  		for(int i=slotNo;i<slotNo+slotNum;i++){
  			if(i>sub.slotsNum-1) return -1;		
  			if(Parameters.DebugModel) System.out.println("sub.slots["+linkNum+"]["+i+"]");
  			if(sub.slots[linkNum][i] != 1 && i<sub.slotsNum) return -1;
  		}
  		int t = slotNo+slotNum;
  		if(Parameters.DebugModel) System.out.println("sub.slots["+linkNum+"]["+t+"]");
  		if(slotNo+slotNum<sub.slotsNum-1 && sub.slots[linkNum][slotNo+slotNum] != 1) return -1;//������ڽӵ�Ƶ�ײ��Ƿ�����Ҫ��
  		return 1;
  	}
  	
  	/* ���ƣ�CheckIfEnoughSlotsOnLink
  	 * ���ܣ�������·�š��������ж���·�Ƿ�����������Ҫ��
  	 * ������sub���ײ�����磻linkNum����·�ţ�bw������
  	 * ����ֵ��-1��ʧ�ܷ��أ�>-1������Ҫ���Ƶ�ײۣ�
  	 * �����ˣ�������
  	 * ����ʱ�䣺2019.6.19
  	 */
  	public int CheckIfEnoughSlotsOnLink(EOSubstrateNetwork sub,int linkNum,double bw)
  	{
  		//����bw����Ƶ�ײ�
  		int slotNum = -1;
  		slotNum = CalculateSlots(bw,sub.link[linkNum].length);
  		
  		//�������
  		//if(linkNum < 0 || slotNo < 0 || slotNum < 0) return -1;
  		if(slotNum > sub.slotsNum) {
  			if(Parameters.DebugModel) {
  				System.out.println("CheckAllPathFreeSlots is error, slotNum.************************");
  			}
  			if(Parameters.ErrorRecord){
  				String str = "CheckIfEnoughSlotsOnLink():CheckAllPathFreeSlots is error, slotNum. \r\n";
				WriteFilePlus("error.txt",str);
	  		}
  			return -1;
  		}
  		if(linkNum > sub.links - 1) {
  			if(Parameters.DebugModel) {
  				System.out.println("CheckAllPathFreeSlots is error, linkNum.************************");
  			}
  			if(Parameters.ErrorRecord){
  				String str = "CheckIfEnoughSlotsOnLink():CheckAllPathFreeSlots is error, slotNum. \r\n";
				WriteFilePlus("error.txt",str);
	  		}
  			return -1;
  		}
  		//���е�·���ϼ���Ƿ����㹻������Ƶ�ײ�
  		int slotNo = 0;
  		//if(slotNo>0 && sub.slots[linkNum][slotNo-1]!=1) return -1;//������ڽӵ�Ƶ�ײ��Ƿ�����Ҫ��
  		boolean find = true;
  		while(slotNo < sub.slotsNum){
  			find = true;
  			for(int i=slotNo;i<slotNo+slotNum;i++){
  	  			if(i>sub.slotsNum-1) return -1;		
  	  			if(Parameters.DebugModel) {
  	  				System.out.println("sub.slots["+linkNum+"]["+i+"]");
  	  			}
  	  			
  	  			if(sub.slots[linkNum][i] != 1 && i<sub.slotsNum) {
  	  				find = false;
  	  			}
  	  		}
  			if(find) return slotNo;
  			slotNo++;
  		}
  		return -1;
  	}
  	/* ���ƣ�CalculateSlots
  	 * ���ܣ����ݴ��������ƺͱ�����������������Ҫ��Ƶ�ײ�����
  	 * ������bw������Ĵ�����mp�����Ʋ�����guardBand����������
  	 * ����ֵ��-1��ʧ�ܷ��أ�>0��������Ƶ�ײ�������
  	 * �����ˣ�������
  	 * ����ʱ�䣺2019.6.22
  	 */
  	public int CalculateSlots(double bw,int mp,int guardBand)
  	{
		int slotNum = (int) (Math.ceil(bw/(12.5*mp)))+guardBand;
		return slotNum;
  	}
  	
  	/* ���ƣ�CalculateSlots
  	 * ���ܣ����ݴ��������ơ����������ͳ��ȣ���������Ҫ��Ƶ�ײ�����
  	 * ������bw������Ĵ�����mp�����Ʋ�����guardBand������������length:����
  	 * ����ֵ��-1��ʧ�ܷ��أ�>0��������Ƶ�ײ�������
  	 * �����ˣ�������
  	 * ����ʱ�䣺2019.7.11
  	 */
  	public int CalculateSlots(double bw,int mp,int guardBand,double length,double mdLength)
  	{
  		if(length > mdLength) return 0;
		int slotNum = (int) (Math.ceil(bw/(12.5*mp)))+guardBand;
		return slotNum;
  	}
  	
  	/* ���ƣ�CalMD
  	 * ���ܣ����ݹ�·�����ȣ��������ģʽ
  	 * ������bw������Ĵ�����pathLength��·������
  	 * ����ֵ��-1��ʧ�ܷ��أ�>0������������ģʽ��
  	 * �����ˣ�������
  	 * ����ʱ�䣺2020.1.31
  	 */
  	public int CalMD(double bw,double pathLength)
  	{
  		int mp = -1;
  		if(pathLength < 0) return -1;//ʧ�ܷ���
  		if(pathLength <= 375) mp = 4;
		else if(pathLength <= 750) mp = 3;
		else if(pathLength <= 1500) mp = 2;
		else if(pathLength <= 3000) mp = 1;
		else return -1;//����3000km�����޷�����
  		return mp;
  	}
    /* ���ƣ�CalculateSlots
  	 * ���ܣ����ݹ�·�����ȣ���������Ҫ��Ƶ�ײ�����
  	 * ������bw������Ĵ�����pathLength��·������
  	 * ����ֵ��-1��ʧ�ܷ��أ�>0��������Ƶ�ײ�������
  	 * �����ˣ�������
  	 * ����ʱ�䣺2019.1.6
  	 */
  	public int CalculateSlots(double bw,double pathLength)
  	{
  		int mp = -1;
  		if(pathLength < 0) return -1;//ʧ�ܷ���
  		if(pathLength <= 375) mp = 4;
		else if(pathLength <= 750) mp = 3;
		else if(pathLength <= 1500) mp = 2;
		else if(pathLength <= 3000) mp = 1;
		else return -1;//����3000km�����޷�����
		int slotNum = (int) (Math.ceil(bw/(12.5*mp))+Parameters.GuardBand);
		if(slotNum >= Parameters.MaxSlots) return -1;
		System.out.println("bw:"+bw +" mp:"+mp+" slotNum:"+slotNum+ " pathLength:"+pathLength);
		return slotNum;
		/*
		int mp = -1;
		if(pathLength <= 375) mp = 4;
		else if(pathLength <= 750) mp = 3;
		else if(pathLength <= 1500) mp = 2;
		else if(pathLength <= 3000) mp = 1;
		else return 0;//����3000km�����޷�����
		int slotNum = (int) (Math.floor(bw/(12.5*mp))+1);
		return slotNum;*/
  	}
  	
  	/*
  	 * ͨ��(sNode1,sNode2)�õ���·��
  	 */
  	public int GetLinkNum(VONRequest reqs[],int index,int sNode1,int sNode2)
  	{
  		int linkNum = -1;
  		for(int i=0;i<reqs[index].links;i++){
  			if((reqs[index].link[i].from == sNode1 && reqs[index].link[i].to == sNode2) || (reqs[index].link[i].from == sNode2 && reqs[index].link[i].to == sNode1)) {
  				linkNum = i;
  				break;
  			}
  		}
  		return linkNum;
  	}
  	
  	/*
  	 * ͨ��(sNode1,sNode2)�õ���·��
  	 */
  	public int GetLinkNum(EOSubstrateNetwork sub,int sNode1,int sNode2)
  	{
  		int linkNum = -1;
  		for(int i=0;i<sub.links;i++){
  			if((sub.link[i].from == sNode1 && sub.link[i].to == sNode2) || (sub.link[i].from == sNode2 && sub.link[i].to == sNode1)) {
  				linkNum = i;
  				break;
  			}
  		}
  		return linkNum;
  	}
  	
  	/*
  	 * ���ܣ�ͨ��(sNode1,sNode2)�õ���·�ţ������ظ���·�ĳ���
  	 * �����ˣ�chen xh
  	 * ����ʱ�䣺2019/7/12
  	 */
  	public double GetLength(EOSubstrateNetwork sub,int sNode1,int sNode2)
  	{
  		int linkNum = -1;
  		for(int i=0;i<sub.links;i++){
  			if((sub.link[i].from == sNode1 && sub.link[i].to == sNode2) || (sub.link[i].from == sNode2 && sub.link[i].to == sNode1)) {
  				linkNum = i;
  				break;
  			}
  		}
  		return sub.link[linkNum].length;
  	}
  	/*
  	 * ���ܣ�ͨ��(sNode1,sNode2)�õ���·�ţ������ظ���·�ĳ���
  	 * �����ˣ�chen xh
  	 * ����ʱ�䣺2019/7/12
  	 */
  	public void GetMDAndMDLength(int[] MD,int[] MDLength)
  	{
  		MD[0] = Parameters.MDBPSK;
		MD[1] = Parameters.MDQPSK;
		MD[2] = Parameters.MD8QAM;
		MD[3] = Parameters.MD16QAM;
		MD[4] = Parameters.MD64QAM;
		MD[5] = Parameters.MD256QAM;
		
		MDLength[0] = Parameters.MDBPSK_Length;
		MDLength[1] = Parameters.MDQPSK_Length;
		MDLength[2] = Parameters.MD8QAM_Length;
		MDLength[3] = Parameters.MD16QAM_Length;
		MDLength[4] = Parameters.MD64QAM_Length;
		MDLength[5] = Parameters.MD256QAM_Length;
  	}
  	
  	/*
  	 * ����ÿ��·������
  	 */
  	public double GetPathLength(EOSubstrateNetwork sub,DistanceParent[] shortestPath,int sNode1,int sNode2)
  	{
  		double pathLength = 0;
  		int linkIndex = -1;//link
  		if(shortestPath[sNode2] != null) {
  			if(shortestPath[sNode2].parentVert == sNode1){
  	  			linkIndex = GetLinkNum(sub,sNode2,shortestPath[sNode2].parentVert);
  	  			pathLength += sub.link[linkIndex].length;
  	  		} else while(shortestPath[sNode2].parentVert != sNode1){
  	  			linkIndex = GetLinkNum(sub,sNode2,shortestPath[sNode2].parentVert);
  	  			pathLength += sub.link[linkIndex].length;
  	  			sNode2 = shortestPath[sNode2].parentVert;
  	  		}
  		} else if(shortestPath[sNode1] != null) {
  			if(shortestPath[sNode1].parentVert == sNode2){
  	  			linkIndex = GetLinkNum(sub,sNode1,shortestPath[sNode1].parentVert);
  	  			pathLength += sub.link[linkIndex].length;
  	  		} else while(shortestPath[sNode1].parentVert != sNode2){
  	  			linkIndex = GetLinkNum(sub,sNode1,shortestPath[sNode1].parentVert);
  	  			pathLength += sub.link[linkIndex].length;
  	  			sNode1 = shortestPath[sNode1].parentVert;
  	  		}
  		} else {
  			return -1;
  		}
  		System.out.println("pathLength:"+pathLength);
  		return pathLength;
  	}
  	
  	/*
  	 * ����ÿ��·�����������С�ڵ���2����˵��·����Ч
  	 */
  	public int GetPathJump(AuxiliaryGraph sub,DistanceParent[] shortestPath,int pathNum,int sNode1,int sNode2)
  	{
  		int pathLength = 0;
  		if(shortestPath[sNode2] == null) return 0;
  		while(shortestPath[sNode2].parentVert != sNode1){
  			sNode2 = shortestPath[sNode2].parentVert;
  			pathLength ++;
  		}	
  		return pathLength+1;
  	}
  	
  	/*����:�õ�����ĳ����·node1->node2��·������
	**����ֵ��·����������*/
	public int GetPathSumPassLink(AuxiliaryGraph auxGraph,DistanceParent[][][] kShortestPath,int[][] pathNo,int node1,int node2,int[] pathEff,VONRequest reqs[],int index)
	{
		int pathSum = 0;
		for(int i = 0; i < reqs[index].links; i ++)
		{
			for(int j = 0; j < pathEff[i]; j ++)
			{
				if(pathNo[i][j] > -1)
				{
					int vNode1=-1,vNode2=-1,sNode1=-1,sNode2=-1;
					
					vNode1 = reqs[index].link[i].from;
					vNode2 = reqs[index].link[i].to;
					sNode1 = auxGraph.virtualNodes[vNode1];
					sNode2 = auxGraph.virtualNodes[vNode2];
					if((sNode1 == node1 && sNode2 == node2) || (sNode2 == node1 && sNode1 == node2)) {
						pathSum ++;
						continue;
					}
					while(kShortestPath[i][j][sNode2].parentVert != sNode1){
						int sNode3 = kShortestPath[i][j][sNode2].parentVert;
						if((sNode3 == node1 && sNode2 == node2) || (sNode2 == node1 && sNode3 == node2)) {
							pathSum ++;
							break;
						}
						sNode2 = kShortestPath[i][j][sNode2].parentVert;
					}
					if(sNode2 == node2 && kShortestPath[i][j][sNode2].parentVert == node1)
						pathSum ++;
				}
			}
		}
		return pathSum;
	}	
  	
  	/*����:�õ�����ĳ���ڵ�node��·�����
	**����ֵ��-1��ʧ�ܷ��أ�˵��û���ҵ�������·��
	**      >-1:�ɹ����أ�˵���ҵ�������·����*/
  	public int IncludeNodeInPath(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathNo,int node,VONRequest reqs[],int index)
	{
		for(int i = 0; i < reqs[index].links; i ++)
		{
			for(int j = 0; j < Parameters.K_PATH; j ++)
			{
				if(pathNo[i][j] > -1)
				{
					int vNode1=-1,vNode2=-1,sNode1=-1,sNode2=-1;
					
					vNode1 = reqs[index].link[i].from;
					vNode2 = reqs[index].link[i].to;
					sNode1 = auxGraph.virtualNodes[vNode1];
					sNode2 = auxGraph.virtualNodes[vNode2];
					if(sNode1 == node || sNode2 == node) return pathNo[i][j];
					while(kShortestPath[i][j][sNode2].parentVert != sNode1){
						sNode2 = kShortestPath[i][j][sNode2].parentVert;
						if(sNode2 == node) return pathNo[i][j];
					}
				}
			}
		}
		return -1;
	}
	/*����:�õ�����ڵ��Ӧ�ĸ���ͼ�ڵ�Ķ�
	**����ֵ������ڵ��Ӧ�ĸ���ͼ�ڵ�Ķ�*/
	public int GetDegreeOfNode(AuxiliaryGraph auxGraph,int node)
	{
		int degree = 0;
		for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
		{
			if(auxGraph.virtServLinks[j].from == node) degree ++;
		}
		return degree;
	}
	/*����:�õ�����ĳ����·node1->node2��·�����
	**����ֵ��-1��ʧ�ܷ��أ�˵��û���ҵ�������·��
	**      >-1:�ɹ�����·����Ч��ţ�˵���ҵ�������·����*/
	public int IncludeLinkInPath(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathNo,int vLinkNo,int pathNum,int k,VONRequest reqs[],int index)
	{
		int node1,node2;
		//node1 = auxGraph.link[vLinkNo].from;
		//node2 = auxGraph.link[vLinkNo].to;
		node1 = auxGraph.virtServLinks[k].from;
		node2 = auxGraph.virtServLinks[k].to;
		if(pathNo[vLinkNo][pathNum] > -1)//˵������������Ч·��
		{
			int vNode1=-1,vNode2=-1,sNode1=-1,sNode2=-1;
			
			vNode1 = reqs[index].link[vLinkNo].from;
			vNode2 = reqs[index].link[vLinkNo].to;
			sNode1 = auxGraph.virtualNodes[vNode1];
			sNode2 = auxGraph.virtualNodes[vNode2];
			int sNode3 = -1;
			if((sNode1 == node1 && sNode2 == node2) || (sNode1 == node2 && sNode2 == node1)) return pathNo[vLinkNo][pathNum];
			while(kShortestPath[vLinkNo][pathNum][sNode2].parentVert != sNode1){
				sNode3 = sNode2;
				sNode2 = kShortestPath[vLinkNo][pathNum][sNode2].parentVert;
				
				if((sNode3 == node1 && sNode2 == node2) || (sNode3 == node2 && sNode2 == node1)) return pathNo[vLinkNo][pathNum];
			}
			if((sNode1 == node1 && sNode2 == node2) || (sNode1 == node2 && sNode2 == node1)) return pathNo[vLinkNo][pathNum];
			
		}
		
		return -1;
	}
	//******************************************************************
	//���ƣ�int CheckIfSlotEnoughByNode(......)
	//���ܣ����ײ�ڵ����·��Ƶ���Ƿ���������ڵ����ӵ�Ƶ��Ҫ�� 
	//������
	//	      subΪ��������
	//	      sNodeΪ�����ڵ�
	//	      reqsΪ����������
	//	      indexΪ��index����������
	//����ֵ��contSlotsNum���ɹ�������������Ƶ�ײ�������-1��ʧ�ܷ��� 
	//      link[0]:���ص���·�ţ�
	//******************************************************************
	public int CheckIfSlotEnoughByNode(EOSubstrateNetwork sub,int sNode,VONRequest reqs[],int index,int vNode,int link[])
	{
		//��������ڵ��������·��������С����·�������ȳ���2��Ҫ������������·����
		//int degree = 0;
		double maxVBW=0;
		double minVBW=10000;
		for(int i=0;i<reqs[index].links;i++){
			if(vNode == reqs[index].link[i].from || vNode == reqs[index].link[i].to){
				//degree ++;
				if(maxVBW < reqs[index].link[i].bw) maxVBW = reqs[index].link[i].bw;
				if(minVBW > reqs[index].link[i].bw) minVBW = reqs[index].link[i].bw;
			}
		}
		//������Ҫ���ٵ�Ƶ�ײ�����
		int minSlots = 0;
		//minSlots = (int) (Math.floor(minVBW/(12.5*4))+1);
		minSlots = (int) (Math.ceil(maxVBW/(12.5*4))+Parameters.GuardBand);
		if(minSlots > Parameters.MaxSlots) return -1;
		//���������ڵ�sNode����·Ƶ�ײ���������С����·����
		int indexOfSlots = -1;
		for(int i=0;i<sub.links;i++){
			if(sub.link[i].from == sNode || sub.link[i].to == sNode){
				//�������������Ƶ�ײ�����>=minSlots if(sub.slots[i][])
				indexOfSlots = GetIndexOfSlotsByNum(sub,i,minSlots);
				if(indexOfSlots > -1) {
					link[0] = i;
					return indexOfSlots;
				}
			}
		}
		return -1;
	}	
		
	//******************************************************************
	//���ƣ�int GetIndexOfSlotsByNum(......)
	//���ܣ����ײ�ڵ����·�����Ĺ�Ƶ���Ƿ�����Ƶ������Ҫ�� 
	//������
	//	      subΪ��������
	//	      slotNumΪ�ײ�����Ƶ�ײ�����
	//����ֵ��contSlotsNum���ɹ�������С��Ƶ�ײ�������-1��ʧ�ܷ��� 
	//******************************************************************
	private int GetIndexOfSlotsByNum(EOSubstrateNetwork sub,int linkNum,int slotNum)
	{
		int contSlotsNum = -1;
		//boolean find = true;
		for(int i=0; i<sub.slotsNum-slotNum+1; i++){
			//find = true;
			for(int j=0; j<slotNum; j++){
				if(sub.slots[linkNum][j] == 0){
					//find = false;
					break;
				}
			}
			return i;
		}
		return contSlotsNum;	
	}
  	/*
	 * �������·��ӳ���Ƿ���Ч
	 */
  	public boolean CheckTwoPathsSlotsIfEff(VONRequest reqs[],int index,DistanceParent[][][]  kShortestPath,int p[][],int virtualNodes[],int retLinkE[],int retSlotSE[],int retSlotEE[],int vLinkNo1,int vLinkNo2)
	{
		//ȡ��һ��·����ÿһ����·l{ij}
		//����ڶ���·���Ƿ�����·l{ij}�غ�,��������غϣ�����slots�Ƿ��ͻ�������ͻ���򷵻�true�����򣬷���false
		int sNode1 = virtualNodes[reqs[index].link[vLinkNo1].from];//������·�˵�from��Ӧ�ĸ���ͼ�ڵ���
		int sNode2 = virtualNodes[reqs[index].link[vLinkNo1].to];//������·�˵�to��Ӧ�ĸ���ͼ�ڵ���
		int sNode3 = sNode2;
		int pathByLink = GetPathNoInLinkByPath(reqs,index,retLinkE[vLinkNo1]);//retLinkE[vLinkNo1];//GetPathByLink(vLinkNo1);//������·��Ӧ�ĵڼ���·��
		boolean find = false;
		//while(kShortestPath[vLinkNo1][pathByLink][sNode3].parentVert != sNode1){
		while(sNode3 != sNode1){
					//if(sNode3 != sNode2){//���������˵�
			//	p[vLinkNo1][sNode3] = kShortestPath[vLinkNo1][pathByLink][sNode3].parentVert;
			//}
			System.out.println(sNode3+"->");
			int sNode4 = -1;
			if(kShortestPath[vLinkNo1][pathByLink][sNode3] != null){
				sNode4 = kShortestPath[vLinkNo1][pathByLink][sNode3].parentVert;
			} else {
				return false;
			}
			if(sNode3 == sNode1 || sNode3 == sNode2 || sNode4 == sNode1 || sNode4 == sNode2){
				sNode3 = kShortestPath[vLinkNo1][pathByLink][sNode3].parentVert;
				continue;
			}
			if(CheckIfSameLinkInTwoPath(sNode3,sNode4,virtualNodes,reqs,index,kShortestPath,p,retLinkE,vLinkNo2) == true){
				find = true;
				break;
			}
			sNode3 = kShortestPath[vLinkNo1][pathByLink][sNode3].parentVert;
		}
		//System.out.println(sNode3+"->"+sNode1+"("+retSlotSE[i]+"-"+retSlotEE[i]+")");
		System.out.println("retSlotSE["+vLinkNo1+"]="+retSlotSE[vLinkNo1]);
		System.out.println("retSlotEE["+vLinkNo1+"]="+retSlotEE[vLinkNo1]);
		System.out.println("retSlotSE["+vLinkNo2+"]="+retSlotSE[vLinkNo2]);
		System.out.println("retSlotEE["+vLinkNo2+"]="+retSlotEE[vLinkNo2]);
		if(find == true){//˵���ҵ�����ͬ����·,����Ƶ�ײ��Ƿ���Ч
			if(retSlotSE[vLinkNo1]<=retSlotEE[vLinkNo2] && retSlotSE[vLinkNo1]>=retSlotSE[vLinkNo2]){
				System.out.println("1 false");
				return false;
			} else if(retSlotEE[vLinkNo1]<=retSlotEE[vLinkNo2] && retSlotEE[vLinkNo1]>=retSlotSE[vLinkNo2]){
				System.out.println("2 false");
				return false;
			}
		}
		return true;
	}
	/*
	 * ͨ��·����ţ��õ�ĳ����·ӳ���·�����
	 */
	public int GetPathNoInLinkByPath(VONRequest reqs[],int index,int path)
	{
		int pathSum = 0;
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<Parameters.K_PATH;j++){
				if(path == pathSum)
					return j;
				pathSum ++;
			}
		}
		return -1;
	}
	/*
	 * ���һ����·(sNode1,sNode2)�Ƿ���·����
	 * ������sNode1-sNode2:��ʾ��·�������˵㣻
	 */
	public boolean CheckIfSameLinkInTwoPath(int sNode1,int sNode2,int virtualNodes[],VONRequest reqs[],int index,DistanceParent[][][]  kShortestPath,int p[][],int retLinkE[],int vLinkNo)
	{
		int sNode4 = virtualNodes[reqs[index].link[vLinkNo].from];//������·�˵�from��Ӧ�ĸ���ͼ�ڵ���
		int sNode5 = virtualNodes[reqs[index].link[vLinkNo].to];//������·�˵�to��Ӧ�ĸ���ͼ�ڵ���
		int sNode3 = sNode5;
		int pathByLink = GetPathNoInLinkByPath(reqs,index,retLinkE[vLinkNo]);
		//while(kShortestPath[vLinkNo][pathByLink][sNode3].parentVert != sNode4){
		while(sNode3 != sNode4){
			//if(sNode3 != sNode2){//���������˵�
				//p[vLinkNo][sNode3] = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
			//}
			System.out.print("kShortestPath["+vLinkNo+"]["+pathByLink+"]["+sNode3+"].");
			if(kShortestPath[vLinkNo][pathByLink][sNode3]!=null) System.out.print(kShortestPath[vLinkNo][pathByLink][sNode3].parentVert+"\r\n");
			int sNode6 = -1;
			if(kShortestPath[vLinkNo][pathByLink][sNode3]!=null) sNode6 = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
			else break;
			if((sNode3 == sNode1 && sNode6 == sNode2)||(sNode3 == sNode2 && sNode6 == sNode1)){
				return true;
			}
			sNode3 = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
		}
		//int sNode6 = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
		//if((sNode3 == sNode1 && sNode6 == sNode2)||(sNode3 == sNode2 && sNode6 == sNode1)){
		//	return true;
		//}
		return false;
	}
	/*
	 * ���·��ӳ���Ƿ���Ч
	 * 
	 */
	public boolean CheckPathSlotsIfEff(VONRequest reqs[],int index,DistanceParent[][][]  kShortestPath,int p[][],int virtualNodes[],int retLinkE[],int retSlotSE[],int retSlotEE[])
	{
		//boolean CheckTwoPathsSlotsIfEff(VONRequest reqs[],int index,DistanceParent[][][]  kShortestPath,int p[][],int virtualNodes[],int retLinkE[],int retSlotSE[],int retSlotEE[],int vLinkNo1,int vLinkNo2)
		
		for(int i=0;i<reqs[index].links;i++){
			for(int j=i+1;j<reqs[index].links;j++){
				boolean check = CheckTwoPathsSlotsIfEff(reqs,index,kShortestPath,p,virtualNodes,retLinkE,retSlotSE,retSlotEE,i,j);
				if(check == false) return false;
			}
		}
		return true;
	}
	/*
	 * ���ܣ��ͷ�����[0,end]֮�����������ӳ�����Դ
	 */
	public void ReleaseAllResourceAmongZeroToEnd(EOSubstrateNetwork sub,VONRequest reqs[],int end,int time)
	{
		//Release the resources.
        for (int i = 0; i < end; i ++) {
        	if ((v2s[i].map == Parameters.STATE_MAP_LINK || v2s[i].map == Parameters.STATE_MAP_SUCC)  && v2s[i].maptime + reqs[i].duration <= time) {          
        		if(Parameters.RecordLogModel) {
        			WriteFilePlus("process.txt","req["+i+"] release before");
        			WriteFileOfGraph(sub,"process.txt",true);
        		}
        		
        		ReleaseResourceFlow(sub,reqs,i); //Release the allocated resources of the ith VN request.
                v2s[i].map = Parameters.STATE_DONE;
                if(Parameters.RecordLogModel) {
                	WriteFilePlus("process.txt","req["+i+"] release after");
                	WriteFileOfGraph(sub,"process.txt",true);
                }
                
                System.out.println("Release Resource:"+i+"------------------------------");
                
                if(i==1) {
                	System.out.println("Print sub when req=1");
                	PrintSN(sub);
                }
        	}
        }
	}
	//Release the allocated resource of the ith virtual network request.
	public void ReleaseResourceFlow(EOSubstrateNetwork sub,VONRequest reqs[],int index)
	{
		System.out.println("reqs["+index+"] release.");
		reqs[index].map = Parameters.STATE_DONE;
		//�ͷ�s2v_n
		for(int i=0;i<reqs[index].nodes;i++){
			int snode;
			snode = v2s[index].snode.get(i);			
			for(int j=0;j<s2v_n[snode].req_count;j++){
				if(s2v_n[snode].req.get(j) == index){
					s2v_n[snode].cpu.remove(j);
					s2v_n[snode].req.remove(j);
					s2v_n[snode].vnode.remove(j);			
					s2v_n[snode].rest_cpu += reqs[index].cpu[i];
					s2v_n[snode].req_count--;
					break;
				}
			}
			//����sub.cpu
			sub.cpu[snode] += reqs[index].cpu[i];
		}
		//�ͷ�s2v_l��sub.slots
		for(int i=0;i<reqs[index].links;i++){
			int startSlotNo,slotNum;//�����Ƶ�׿�ʼ�����������Ƶ������
			startSlotNo = (int)v2s[index].startSlotNo.get(i);
			slotNum = (int)v2s[index].slotNum.get(i);
			
			int snode1,snode2,vnode1,vnode2;
			vnode1 = reqs[index].link[i].from;
			vnode2 = reqs[index].link[i].to;
			//snode1 = v2s[index].snode.get(vnode1);
			snode1 = v2s[index].snode.get(vnode2);
			//snode2 = v2s[index].snode.get(vnode2);
			
			for(int ii=0;ii<v2s[index].pathFlow.get(i).len;ii++){
				snode1 = v2s[index].pathFlow.get(i).link.get(ii);
				snode2 = v2s[index].pathFlow.get(i).link.get(ii+1);
				int slink;
				slink = sub.linksNo[snode1][snode2];
				
				//�ͷ�sub.slots
				if(Parameters.RecordLogModel){
					String str = "Release slot["+slink+"]["+startSlotNo+"-"+(startSlotNo+slotNum-1)+"]"+"\r\n";
					WriteFilePlus("process.txt",str);
				}
				for(int k = startSlotNo; k < startSlotNo+slotNum && k < sub.slotsNum; k++){
					if(Parameters.DebugModel){
						System.out.println("ii:"+ii+" k:"+k +" slink:"+slink+" snode1:"+snode1+" snode2:"+snode2+" "+sub.linksNo[snode2][snode1]);
					}
					if(k<0) continue;
					sub.slots[slink][k] = 1;
					//if(index == 1) 
					//   System.out.println("sub.slots["+slink+"]["+k+"]");
				}
				System.out.println(index+"release.----------");
				for(int j=0;j<s2v_l[slink].req.size();j++){
					if((int)s2v_l[slink].req.get(j) == index) {
						//�ͷ�s2v_l
						s2v_l[slink].bw.remove(j);
						s2v_l[slink].vlink.remove(j);
						s2v_l[slink].req.remove(j);					
					}
				}
				s2v_l[slink].req_count--;
				s2v_l[slink].rest_bw += reqs[index].link[i].bw;
				
				snode1 = snode2;
			}
			
		}	
	}	
	//ͳ����Դ����
	public void CalResDisAfterVNE(EOSubstrateNetwork sub,VONRequest reqs[],int index,double ret[])
	{
		int i= index;
  		double cpuRate,resRate,slotRate,slots;
  		cpuRate = slotRate = resRate = slots = 0;//�ܵ�cpu��ʣ����ܵ�cpu
  		for(int j=0;j<sub.nodes;j++){
			cpuRate += s2v_n[j].rest_cpu/sub.cpu[j];
		}
  		cpuSRate = cpuRate/sub.nodes;
  		
  		for(int j=0;j<sub.links;j++){
			for(int k=0;k<Parameters.MaxSlots;k++){
				if(sub.slots[j][k] == 1) slots++; 
			}
		}
  		slotRate += slots*1.0/(sub.links*Parameters.MaxSlots);
		slotSRate += slotRate;
	}
	//��¼ӳ����
  	public void DebugVNE(EOSubstrateNetwork sub,VONRequest reqs[],int index,int algorithmName,String message)
  	{
  		int i= index;
  		double cpuRate,resRate,slotRate,slots;
  		cpuRate = slotRate = resRate = slots = 0;//�ܵ�cpu��ʣ����ܵ�cpu
  		if(Parameters.RecordLogModel){
			String str = message+"In DebugVNE,\r\n";
			//str = "embed req["+i+"]"+" successfully.\r\n";
			//for(int j=0;j<reqs[i].nodes;j++)
			//	str += j+" is embedded to "+v2s[i].snode.get(j)+".\r\n";
			//str += "cpu[]:";
			for(int j=0;j<sub.nodes;j++){
				str += j+"="+sub.cpu[j]+" ";
				cpuRate += s2v_n[j].rest_cpu/subStatic.cpu[j];
				//cpuSRate += cpuRate;
			}
			if(cpuSRate > 0) cpuSRate = (cpuSRate+cpuRate/sub.nodes)/2;//cpu��Դ�ֲ���ƽ��ֵΪcpuSRate
			else cpuSRate = cpuRate/sub.nodes;
			str += "\r\nrest cpu[]:";
			for(int j=0;j<sub.nodes;j++){
				str += j+"="+s2v_n[j].rest_cpu+" ";
				//restCPU += s2v_n[j].rest_cpu;
			}
			
			WriteFilePlus("process.txt",str);
			
			str = "sub.slots:\r\n";
			for(int j=0;j<sub.links;j++){
				str += sub.link[j].from + "-"+ sub.link[j].to + "sub.slots:\r\n";
				slots = 0;
				for(int k=0;k<Parameters.MaxSlots;k++){
					str += sub.slots[j][k] +" ";
					if(sub.slots[j][k] == 1) slots++; 
				}
				slotRate += slots*1.0/Parameters.MaxSlots;
				if(slotSRate > 0) slotSRate = (slotSRate + slotRate)/2;
				else slotSRate += slotRate;
				str +=".\r\n";
			}
			WriteFilePlus("process.txt",str);
			
			str = "\r\ncpuRate="+cpuRate+" slotRate="+slotRate+" resRate="+(cpuRate+slotRate)/2+" ";
			str += " cpuSRate="+cpuSRate+" slotSRate="+slotSRate+" resSRate="+(cpuSRate+slotSRate)/2+"\r\n";
			WriteFilePlus("process.txt",str);
			
			str = "\r\nreq["+i+"].cpu=\r\n";
			for(int j=0;j<reqs[i].nodes;j++){
				str += j+"="+reqs[i].cpu[j]+" ";
			}
			str += "\r\nreq["+i+"].link.bw=\r\n";
			for(int j=0;j<reqs[i].links;j++){
				str += j+"="+reqs[i].link[j].bw+" ";
			}
			WriteFilePlus("process.txt",str);
  		}
  	}
  	//��¼ӳ����
  	public void RecordResultsOfVNE(EOSubstrateNetwork sub,VONRequest reqs[],long costTime,int algorithmName)
  	{
  		//����ϵͳ���桢�����ʡ�����ɱ��ȡ�����ʱ��		
  		int n,rate;
  		n = reqs.length;//n���ܵ�������������
  		double cpuSum,bwSum,bwSubSum,flotsSubSum,slotSum;
  		cpuSum = bwSum = bwSubSum = flotsSubSum = slotSum = 0;
  		double duration = 0;
  		double refuSlotSum,receSlotSum;
  		refuSlotSum = receSlotSum = 0;
  		
  		int timeWindowsSum = reqs[n-1].time;
  		
  		int reqNodes = 0;
  		int reqLinkNum = 0;
  		rate = 0;		//rate��ӳ��ɹ���������������
  		for (int i = 0; i < n; i ++) {
  			if(reqs[i].map == Parameters.STATE_MAP_LINK || reqs[i].map == Parameters.STATE_DONE || reqs[i].map == Parameters.STATE_MAP_SUCC) {
  			     //if(v2s[i].map == Parameters.STATE_MAP_LINK || v2s[i].map == Parameters.STATE_DONE || v2s[i].map == Parameters.STATE_MAP_SUCC) {
  		        rate ++;
  		        reqNodes += reqs[i].nodes;
  		        for (int j = 0; j < reqs[i].nodes; j ++) {
  		          cpuSum += reqs[i].cpu[j];		          
  		        }
  		        reqLinkNum += reqs[i].links; 
  		        duration += reqs[i].duration;
  		        for (int j = 0; j < reqs[i].links; j ++) {		
  		        	receSlotSum += reqs[i].link[j].speed;
  		        	bwSum += reqs[i].link[j].bw;
  		        	slotSum += v2s[i].slotNum.get(j);//reqs[i].slotN;		        	
  		        	SpathFlow tmLL = v2s[i].pathFlow.get(j);//��i�����������j����·��ӳ��·��
  		            for(int k = 0; k < v2s[i].flowLen.get(j); k ++) {//��ǰ�ǵ�·����·ӳ��	
  		            	bwSubSum += tmLL.bw * tmLL.len;	
  		            	flotsSubSum += (v2s[i].slotNum.get(j) * tmLL.len);
  		            }
  		        }
  		        if(Parameters.StaticRecord == true){
  		        	String data = i + " " + String.valueOf(slotSum)+ " " + String.valueOf(flotsSubSum) + " " + String.valueOf(slotSum*1.0/flotsSubSum) + "\r\n";
  		        	Tools myDowith = new Tools();
  		        	myDowith.SaveFile("Cost.dat", data, true);
  		        }
  		        //DebugVNE(sub,reqs,i,Parameters.CurrentVONEMethod);
  		        
  		     } else {
  		    	 for (int j = 0; j < reqs[i].links; j ++) {		
  		    		 refuSlotSum += reqs[i].link[j].speed;
  		    	 }
  		    	 System.out.println("The "+i+" VN is failed. The state is " + v2s[i].map + ". The time of mapping is "+v2s[i].tryMapTime + ". The slots are " + (Math.ceil(reqs[i].link[0].bw/12.5)+Parameters.GuardBand));
  		     }
  		}
  	    double recieveRate = rate * 1.0 / n; //�������������
  	    double rvc = (cpuSum + bwSum)/(cpuSum + bwSubSum);//����ɱ���
  	    double revenue = (cpuSum + bwSum)/timeWindowsSum;	//ϵͳ����
  	    
  	    System.out.println("slotSum:"+slotSum+" flotsSubSum:"+flotsSubSum+" bwSubSum:"+bwSubSum);
  	    
  	    double slotRVC = slotSum * 1.0 / flotsSubSum;//��·slot����ɱ���
  	    
  	  double rvc1 = (cpuSum + bwSum)/(cpuSum + flotsSubSum*12.5);//����ɱ���
  	    
  	    //�ڵ���Դ������+��·��Դ������+���߽ڵ�����+����ڵ�����+������·����+
  	    //d13 = linkSubRateSum / timeWindowsSum;//ÿ��ʱ�䴰�ĵײ���·������
  	    //d14 = nodeSubRateSum / timeWindowsSum;//ÿ��ʱ�䴰�ĵײ����������
  	    //double
  	    
  	    double avSubLinkBW = bwSum / sub.links;  //һ���ײ���·��������ѧ����    
  	    double avSubNodeCPU = cpuSum / sub.nodes;  //һ���ײ�ڵ�CPU��Դ����ѧ����
  	    //.d3 = sub.nodes; //�ײ�ڵ�����
  	    //d4 = sub.links; //�ײ���·����
  	    double avVNByOneWindow = (1.0 * n) / timeWindowsSum; //һ��ʱ�䴰�ڵ��������������������
  	    
  	    double avReqLinkNum = 0;	           
  	    avReqLinkNum = (1.0 * reqLinkNum) / n; //һ�������������·����
  	    
  	    double avBWReq = 0; 
  	    avBWReq = bwSum / reqLinkNum; //һ��������·����   
  	    
  	    double avDuration = 0;
  	    avDuration = duration / n;  //һ���������������ʱ��

  	    double avReqNodes = 0;
  	    avReqNodes = reqNodes / n;  //һ����������Ľڵ�����
  	    
  	    double avCPUSum = 0;
  	    avCPUSum = cpuSum / reqNodes; //һ������ڵ�CPU��������Դ��
  	    
  	    System.out.println("reqNodes:"+reqNodes+" "+" n:"+n+" reqs[i].nodes:"+reqs[0].nodes);

  	    Tools myDowith = new Tools();
  	    String data = "";//";\r\n";
  	    
  	    //��ǰʱ��
  	    Date now = new Date(); 
  	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");//���Է�����޸����ڸ�ʽ
  	    String curDT = dateFormat.format( now ); 
  	    
  	    //�㷨+Ŀ¼+������������+ʱ�䴰��С+������+����ɱ���+ϵͳ����+���ѵ�ʱ��+��·slot����ɱ���+����������(refuSlotSum/(refuSlotSum+receSlotSum))
  	    //��Щ�ֶ�δͳ��(�ڵ���Դ������+��·��Դ������+���߽ڵ�����+����ڵ�����+������·����+)
  	    //һ���ײ���·��������ѧ���� +һ���ײ�ڵ�CPU��Դ����ѧ����+�ײ�ڵ�����+�ײ���·����+
  	    //һ��ʱ�䴰�ڵ��������������������+һ�������������·����+һ��������·����+һ���������������ʱ��+
  	    //һ����������Ľڵ�����+һ������ڵ�CPU��������Դ��
  	    
  	    data = curDT+ " " + String.valueOf(algorithmName) + " " + VNsFileDir + " " + String.valueOf(n) + " " + String.valueOf(timeWindowsSum) + " " +  String.valueOf(recieveRate) + " " +  String.valueOf(slotRVC) +  " " + String.valueOf(rvc) + " " +  String.valueOf(revenue) + " " +  String.valueOf(costTime) + " "  + String.valueOf(refuSlotSum/(refuSlotSum+receSlotSum)) + " ";
  	    data += String.valueOf(avSubLinkBW) + " " + String.valueOf(avSubNodeCPU) + " " + String.valueOf(sub.nodes) + " " + String.valueOf(sub.links) + " ";
  	    data += String.valueOf(avVNByOneWindow) + " " + String.valueOf(avReqLinkNum) + " " + String.valueOf(avBWReq) + " " + String.valueOf(avDuration) + " ";
  	    data += String.valueOf(avReqNodes) + " " + String.valueOf(avCPUSum) + " " + rvc1 + "\r\n";
  	    myDowith.SaveFile("results.dat", data, true);
  	    System.out.println("data:"+data);
  	    System.out.println("costTime:"+costTime);
  	}
  	
  	/*
	 * ���ƣ�WriteFilePlus(String fileName,String content);
	 */
	public void WriteFilePlus(String fileName,String content)
	{
 		Tools myDowith = new Tools();
 		Date now = new Date(); 
  	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");//���Է�����޸����ڸ�ʽ
  	    String curDT = dateFormat.format( now ); 
 		content = curDT + content + "\r\n";
  	    myDowith.SaveFile(fileName, content, true);
	}
  	
  	/*
	 * ���ƣ�WriteFileOfGraph(sub,graphData);
	 */
	public void WriteFileOfGraph(EOSubstrateNetwork sub,String fileName)
	{
 		Tools myDowith = new Tools();
  		String data = "";	
  		data += sub.nodes + "\r\n";
  		for(int i=0;i<sub.links;i++){
  			//data += sub.link[i].from + " " + sub.link[i].to + " " + sub.link[i].length + "\r\n";
  			//data += sub.link[i].to + " " + sub.link[i].from + " " + sub.link[i].length + "\r\n";
  			data += sub.link[i].from + " " + sub.link[i].to + " " + 1 + "\r\n";
  			data += sub.link[i].to + " " + sub.link[i].from + " " + 1 + "\r\n";
  		}
  	    myDowith.SaveFile(fileName, data, false);
	}
	/*
	 * ���ƣ�WriteFileOfGraph(sub,graphData);
	 */
	public void WriteFileOfGraph(EOSubstrateNetwork sub,String fileName,boolean append)
	{
 		Tools myDowith = new Tools();
  		String data = "";	
  		data += sub.nodes + "\r\n";
  		for(int i=0;i<sub.links;i++){
  			data += "link[" + i + "]:";
  			for(int j=0;j<Parameters.MaxSlots;j++){
  				data += sub.slots[i][j] + " "; 
  			}
  			data += "\r\n";
  			//data += sub.link[i].from + " " + sub.link[i].to + " " + sub.link[i].length + "\r\n";
  			//data += sub.link[i].to + " " + sub.link[i].from + " " + sub.link[i].length + "\r\n";
  		}
  		data += "\r\n";
  	    myDowith.SaveFile(fileName, data, append);
  	    data = "nodes.cpu:";
  	    for(int i=0;i<sub.nodes;i++){
  	    	data += sub.cpu[i]+ " ";
  	    }
  	    data += "\r\n";
	    myDowith.SaveFile(fileName, data, append);
	}
	/*
	 * ���ƣ�WriteFileOfGraph(sub,graphData);
	 */
	public void WriteFileOfGraph1(WeightedDirectedGraph sub,String fileName)
	{
 		Tools myDowith = new Tools();
  		String data = "";	
  		data += sub.nVerts + "\r\n";
  		for(int i=0;i<sub.nVerts;i++){
  			for(int j=0;j<sub.nVerts;j++){
  				if(i!=j && sub.adjMat[i][j]<Parameters.MAX_VALUE_INT && sub.adjMat[i][j]<Parameters.MAX_VALUE_DOUBLE)
  					data += i + " " + j+ " " + sub.adjMat[i][j] + "\r\n";
  			}
  		}
  	    myDowith.SaveFile(fileName, data, false);
	}
	
	/******************************************************************
	//���ƣ�int FindVONEOptimalSolution(......)
	//���ܣ���01ILPģ��ӳ�����������, ����ɹ��򷵻�true��ret[],p[] 
	//������
	//	      ret[]Ϊ���ص�ӳ������
	//        ret[0]=minSlotIndex(��Ƶ�ײ۵ĵ�λ)
	//        ret[1]=maxSlotIndex(��Ƶ�ײ۵ĸ�λ)
	//	      p[]Ϊӳ���·��
	////	  listΪӳ��������ڵ�
	//����ֵ��true���ɹ����أ�false��ʧ�ܷ��� 
	//�����ˣ�������
	//�������ڣ�2017-09-27
	//******************************************************************/
	public boolean FindVONEOptimalSolutionPlusWangY(AuxiliaryGraph auxGraph,int retNodeE[],int retLinkE[],int retSlotSE[],int retSlotEE[],int retSlotBE[],int retLinkMD[][])
	{
		BufferedReader reader = null;
		
		int keySNode1 = -1,keySNode2 = -1;
		
		try {
	            System.out.println("����Ϊ��λ��ȡ�ļ����ݣ�һ�ζ�һ���У�");
	            reader = new BufferedReader(new FileReader("glpsolRSA.o"));
	            String tempString = null;
	            
	            int line = 1;
	            //һ�ζ���һ�У�ֱ������nullΪ�ļ�����
	            while ((tempString = reader.readLine()) != null) {
	                //��ʾ�к� //
	            	//System.out.println("line " + line + ": " + tempString);
	                if (line == 5 && tempString.indexOf("OPTIMAL") == -1) {  //˵��δ�ҵ����Ž� 
	                	System.out.println("line " + line + ": " + tempString + "No Found the optimal resolvetion.");
	                	return false;
	                } 
	                if (line == 6) {  //�ҵ����·������minLength
	                	//ȥ��ǰ��ո�ȥ��ǰ�棺"Objective:  shPath = ";ȥ�����棺"(MINimum)"
	                	tempString = tempString.replace("Objective:  shPath = ", "");
	                	tempString = tempString.replace("(MINimum)", "");
	                	tempString = tempString.trim();
	                	//minLength = Integer.parseInt(tempString);
	                	//hashResolve = new Hashtable(minLength,(float)1.0);//����hash
	                }
	                if(line > 6 && tempString.indexOf(" y[") != -1){//˵���ҵ������Ž��x����
	                	//ȥ��ǰ��Ĳ��֣�3 x[0,2]       *              1             0             1 
	                	//�Կո�ָ���ȡ��һ������
	                	String tmpStr = "";
	                	//System.out.println("line " + line + ": " + tempString);
	                	
	                	//String tempString1 = reader.readLine();
	                	//System.out.println(tempString1);
	                	String tempString1 = tempString.trim();
	                			
	                	tmpStr = tempString1.substring(tempString1.indexOf("*")+1);
	                	tmpStr = tmpStr.trim();
	                	//System.out.println("line " + line + ": " + tmpStr);
	                	
	                	tmpStr = tmpStr.substring(0,tmpStr.indexOf(" "));
	                	//System.out.println("line " + line + ": " + tmpStr);
	                	if(Integer.parseInt(tmpStr) == 1){//˵���ҵ���һ����
	                		//�õ�һ���⸳ֵ��tmpStr������x[0,2]
	                		tempString = tempString.trim();
	                		tmpStr = tempString.substring(tempString.indexOf(" ")+1);
	                		
	                		//x[0,6,0,1,7,6],����s��keyVNode1ӳ��Ľڵ㣬t��keyVNode2ӳ��Ľڵ�
	                		//y[0,0]
	                		
	                		keySNode1 = Integer.parseInt(tmpStr.substring(tmpStr.indexOf("[")+1, tmpStr.indexOf(",")));
	                		//System.out.println("keyNode1:"+keySNode1);
	                		tmpStr = tmpStr.substring(tmpStr.indexOf(",")+1);
	                		keySNode2 = Integer.parseInt(tmpStr.substring(0, tmpStr.indexOf("]")));
	                		//System.out.println("keyNode2:"+keySNode2);
	                		//int retNodeE[],int retLinkE[],int retSlotSE[],int retSlotEE[],int retSlotBE[]
	                		//hashVLinkToPath.put(keySNode1,keySNode2);//�Ᵽ����hash����
	                		retLinkE[keySNode1] = keySNode2;
	                		System.out.println("keySNode1:"+keySNode1+" keySNode2:"+keySNode2);
	                		//retLinkMD[keySNode1][keySNode2] = 1;
	                	}
	                } else if(line > 6 && tempString.indexOf(" M[") != -1){//˵���ҵ������Ž��x����
	                	String tmpStr = "";
	                	//System.out.println("line " + line + ": " + tempString);
	                	//String tempString1 = reader.readLine();
	                	String tempString1 = tempString.trim();
	                	
	                	tmpStr = tempString1.substring(tempString1.indexOf("*")+1);
	                	tmpStr = tmpStr.trim();
	                	//System.out.println("line " + line + ": " + tmpStr);
	                	
	                	tmpStr = tmpStr.substring(0,tmpStr.indexOf(" "));
	                	//System.out.println("line " + line + ": " + tmpStr);
	                	if(Integer.parseInt(tmpStr) == 1){//˵���ҵ���һ����
	                		//�õ�һ���⸳ֵ��tmpStr������x[0,2]
	                		//var f{(i,j) in E,(m,n) in Ev,s in Vf,t in Vf,k in MSet}, binary;
	                		tempString = tempString.trim();
	                		tmpStr = tempString.substring(tempString.indexOf(" ")+1);//ȥ��ǰ����к�
	                		//System.out.println("line " + line + ": " + tmpStr);
	                		//tmpStr = tmpStr.substring(0,tmpStr.indexOf(" "));		//�õ�f[i,j,m,n,s,t,k]
	                		//System.out.println("line " + line + ": " + tmpStr);
	                		int keyNode1 = -1;
	                		//keyNode1 = Integer.parseInt(tmpStr.substring(tmpStr.indexOf("[")+1, tmpStr.indexOf(",")));//�õ�f[i,j,m,n,s,t,k]��i
	                		//System.out.println("keyNode1:"+keyNode1);
	                		//M[5,1]
	                		keySNode1 = Integer.parseInt(tmpStr.substring(tmpStr.indexOf("[")+1, tmpStr.indexOf(",")));
	                		//System.out.println("keyNode1:"+keySNode1);
	                		tmpStr = tmpStr.substring(tmpStr.indexOf(",")+1);
	                		keySNode2 = Integer.parseInt(tmpStr.substring(0, tmpStr.indexOf("]")));
	                		
	                		//hashVNodeToSNode.put(keySNode1,keySNode2);//�Ᵽ����hash����
	                		//int retNodeE[],int retLinkE[],int retSlotSE[],int retSlotEE[],int retSlotBE[]
	                		for(int i=0;i<auxGraph.virtualNodes.length;i++){
	                			if(auxGraph.virtualNodes[i] == keySNode1)
	                				retNodeE[i] = keySNode2;
	                		}
	                	}
	                } else if(line > 6 && tempString.indexOf(" E[") != -1){//˵���ҵ������Ž��x����
	                	String tmpStr = "";
	                	//System.out.println("line " + line + ": " + tempString);
	                	//String tempString1 = reader.readLine();
	                	tempString = tempString.trim();
                		tmpStr = tempString.substring(tempString.indexOf(" ")+1);//ȥ��ǰ����к�
	                	
                		//E[0]
                		keySNode1 = Integer.parseInt(tmpStr.substring(tmpStr.indexOf("[")+1, tmpStr.indexOf("]")));
                		//System.out.println("keyNode1:"+keySNode1);
                		//System.out.println("tempString:"+tempString+" tmpStr:"+tmpStr);
                		tmpStr = tempString.substring(tempString.indexOf("*")+1).trim();//ȥ��*ǰ�����Ϣ
                		//System.out.println("tmpStr:"+tmpStr);
                		if(tmpStr.indexOf(" ") != -1){
                			tmpStr = tmpStr.substring(0,tmpStr.indexOf(" ")).trim();
                		}
                		//System.out.println("tmpStr:"+tmpStr);
                		keySNode2 = Integer.parseInt(tmpStr);
                		
                		//hashESlot.put(keySNode1,keySNode2);//�Ᵽ����hash����
                		//int retNodeE[],int retLinkE[],int retSlotSE[],int retSlotEE[],int retSlotBE[]
                		retSlotEE[keySNode1] = keySNode2;
	                } else if(line > 6 && tempString.indexOf(" S[") != -1){//˵���ҵ������Ž��x����
	                	String tmpStr = "";
	                	//System.out.println("line " + line + ": " + tempString);
	                	//String tempString1 = reader.readLine();
	                	tempString = tempString.trim();
                		tmpStr = tempString.substring(tempString.indexOf(" ")+1);//ȥ��ǰ����к�
	                	
                		//E[0]
                		keySNode1 = Integer.parseInt(tmpStr.substring(tmpStr.indexOf("[")+1, tmpStr.indexOf("]")));
                		//System.out.println("keyNode1:"+keySNode1);
                		
                		tmpStr = tempString.substring(tempString.indexOf("*")+1).trim();//ȥ��*ǰ�����Ϣ
                		//System.out.println("tmpStr:"+tmpStr);
                		if(tmpStr.indexOf(" ") != -1){
                			tmpStr = tmpStr.substring(0,tmpStr.indexOf(" ")).trim();
                		}
                		keySNode2 = Integer.parseInt(tmpStr);
                		
                		//hashSSlot.put(keySNode1,keySNode2);//�Ᵽ����hash����
                		//int retNodeE[],int retLinkE[],int retSlotSE[],int retSlotEE[],int retSlotBE[]
                		retSlotSE[keySNode1] = keySNode2;
	                } else if(line > 6 && tempString.indexOf(" B[") != -1){//˵���ҵ������Ž��x����
	                	String tmpStr = "";
	                	//System.out.println("line " + line + ": " + tempString);
	                	//String tempString1 = reader.readLine();
	                	tempString = tempString.trim();
                		tmpStr = tempString.substring(tempString.indexOf(" ")+1).trim();//ȥ��ǰ����к�
	                	
                		//E[0]
                		keySNode1 = Integer.parseInt(tmpStr.substring(tmpStr.indexOf("[")+1, tmpStr.indexOf("]")));
                		//System.out.println("keyNode1:"+keySNode1);
                		
                		tmpStr = tempString.substring(tempString.indexOf("*")+1).trim();//ȥ��*ǰ�����Ϣ
                		//System.out.println("tmpStr:"+tmpStr);
                		if(tmpStr.indexOf(" ") != -1){
                			tmpStr = tmpStr.substring(0,tmpStr.indexOf(" ")).trim();
                		}
                		keySNode2 = Integer.parseInt(tmpStr);
                		
                		//hashBSlot.put(keySNode1,keySNode2);//�Ᵽ����hash����
                		//int retNodeE[],int retLinkE[],int retSlotSE[],int retSlotEE[],int retSlotBE[]
                		retSlotBE[keySNode1] = keySNode2;
	                } 
	                
	                line++;
	            } 
	            reader.close();
	     } catch (IOException e) {
	            e.printStackTrace();
	     } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e1) {
	                	
	                }
	            }
	     }  
        return true;
	}
	/*
	 * ���Ƶ�ײ��Ƿ��ͻ
	 */
	public boolean CheckLinksMapByMIPWangYPlus(EOSubstrateNetwork sub,VONRequest reqs[],int index,int retSlotSE[],int retSlotEE[],int retLinkE[],DistanceParent kShortestPath[][][],int pathEff[],int pathNo[][],int virtualNodes[],int retNodeE[])
	{
		//0����ӳ�������ݽṹ�У�����p��ret���ݽṹ;
		int p[][] = new int[reqs[index].links][sub.nodes];
		int ret[][] = new int[reqs[index].links][2];
		for(int i=0;i<reqs[index].links;i++){
			ret[i][0] = retSlotSE[i];
			ret[i][1] = retSlotEE[i];//+1;
		}
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<sub.nodes;j++){
				p[i][j] = -1;//��ʼ��
			}
		}
		//����p
		CreateShortestPathFromKPaths(reqs,index,kShortestPath,virtualNodes,retLinkE,pathEff,p);
		
		
		//1���ڵ�ӳ�䣬����sub.slots;
		boolean check = true;
		for(int i=0;i<reqs[index].links;i++){
			int snode1,snode2,vnode1,vnode2;
			vnode1 = reqs[index].link[i].to;
			vnode2 = reqs[index].link[i].from;
			snode1 = retNodeE[vnode1];//v2s[index].snode.get(vnode1);
			snode2 = retNodeE[vnode2];//v2s[index].snode.get(vnode2);
			check = CheckSubSlots(sub,snode1,snode2,ret[i],p[i]);
			if(check == false) return false;
		}
		return true;
	}
	/*����:��·ӳ��
  	 * ����:retSlotSE[]:��ʼ����
  	 * retSlotEE[]:��������
  	 * retLinkE[]:��·ӳ����
  	 * kShortestPath[][][]:���·������
  	 * pathEff[]:ÿ������·��ӳ�����Ч·������
  	 * pathNo[][]:·���ı��
  	 * virtualNodes[]:����ڵ�ӳ�����չͼ�ڵ���
  	 * retNodeE[]:�ڵ�ӳ��
  	 * ������:������
  	 * ����ʱ��:2017-09-28
  	 */
	public void AddLinksMapByMIPWangYPlus(EOSubstrateNetwork sub,VONRequest reqs[],int index,int retSlotSE[],int retSlotEE[],int retLinkE[],DistanceParent kShortestPath[][][],int pathEff[],int pathNo[][],int virtualNodes[],int retNodeE[])
	{
		//0����ӳ�������ݽṹ�У�����p��ret���ݽṹ;
		int p[][] = new int[reqs[index].links][sub.nodes];
		int ret[][] = new int[reqs[index].links][2];
		for(int i=0;i<reqs[index].links;i++){
			ret[i][0] = retSlotSE[i];
			ret[i][1] = retSlotEE[i];//+1;
		}
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<sub.nodes;j++){
				p[i][j] = -1;//��ʼ��
			}
		}
		//����p
		CreateShortestPathFromKPaths(reqs,index,kShortestPath,virtualNodes,retLinkE,pathEff,p);
		
		
		//1���ڵ�ӳ�䣬����sub.slots;
		for(int i=0;i<reqs[index].links;i++){
			int snode1,snode2,vnode1,vnode2;
			vnode1 = reqs[index].link[i].to;
			vnode2 = reqs[index].link[i].from;
			snode1 = v2s[index].snode.get(vnode1);
			snode2 = v2s[index].snode.get(vnode2);
			UpdateSub(sub,snode1,snode2,ret[i],p[i]);
		}
		
		//2������S2VLink s2v_l[]
		int snodeMid1,snodeMid,sNode1,req_count;
		for(int i=0;i<reqs[index].links;i++){
			snodeMid1 = reqs[index].link[i].to;
			sNode1 = reqs[index].link[i].from;
			snodeMid1 = v2s[index].snode.get(snodeMid1);
			sNode1 = v2s[index].snode.get(sNode1);
			while(p[i][snodeMid1] != -1) {
				snodeMid = p[i][snodeMid1];
				req_count = s2v_l[sub.linksNo[snodeMid][snodeMid1]].req_count;
				s2v_l[sub.linksNo[snodeMid][snodeMid1]].req.add(req_count,index);
				s2v_l[sub.linksNo[snodeMid][snodeMid1]].bw.add(req_count,reqs[index].link[i].bw);
				s2v_l[sub.linksNo[snodeMid][snodeMid1]].vlink.add(req_count,i);
				s2v_l[sub.linksNo[snodeMid][snodeMid1]].rest_bw -=  reqs[index].link[i].bw;
				s2v_l[sub.linksNo[snodeMid][snodeMid1]].req_count ++;
				
				snodeMid1 = snodeMid;
				if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
			}
		}
		
		//3������v2s[]����·ӳ����Ϣ
		int pathLength = 0;
		
		for(int i=0;i<reqs[index].links;i++){
			snodeMid1 = reqs[index].link[i].to;
			sNode1 = reqs[index].link[i].from;
			snodeMid1 = v2s[index].snode.get(snodeMid1);
			System.out.println("snodeMid1:"+snodeMid1);
			sNode1 = v2s[index].snode.get(sNode1);
			pathLength = 0;
			LinkedList<Integer> link = new LinkedList<Integer>();
			while(p[i][snodeMid1] != -1) {
				snodeMid = p[i][snodeMid1];
				link.add(pathLength,snodeMid1);				
				pathLength++;	//·������
				snodeMid1 = snodeMid;
				//if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
			}
			if(pathLength == 0){
				snodeMid1 = reqs[index].link[i].from;
				sNode1 = reqs[index].link[i].to;
				snodeMid1 = v2s[index].snode.get(snodeMid1);
				System.out.println("snodeMid1:"+snodeMid1);
				sNode1 = v2s[index].snode.get(sNode1);
				pathLength = 0;
				while(p[i][snodeMid1] != -1) {
					snodeMid = p[i][snodeMid1];
					link.add(pathLength,snodeMid1);				
					pathLength++;	//·������
					snodeMid1 = snodeMid;
					//if(snodeMid1 == sNode1) break;//�ӻ�㵽Դ���·���Ѿ�����
				}
			}
			link.add(pathLength,snodeMid1);	
			
			SpathFlow pathFlow = new SpathFlow();
			pathFlow.link = link;
			pathFlow.len = pathLength;
			System.out.println("vlink:"+i+" pathLength:"+pathLength);
			snodeMid1 = reqs[index].link[i].to;
			//snodeMid1 = reqs[index].link[i].from;
			snodeMid1 = v2s[index].snode.get(snodeMid1);
			for(int ii=0;ii<pathLength;ii++){
				snodeMid = p[i][snodeMid1];
				//System.out.print(snodeMid1+"-");
				snodeMid1 = snodeMid;
			}
			//System.out.print(snodeMid1);
			//System.out.println("");
			if(ret[i][1] == ret[i][0]||pathLength==0) {
				System.out.println("ret[i][1]=ret[i][0].Error!******************");
			}
			if(pathLength==0) {
				System.out.println("PathLength==0.Error!******************");
			}
			pathFlow.bw = reqs[index].link[i].bw;
			v2s[index].pathFlow.add(i,pathFlow);
			v2s[index].flowLen.add(i,1);//1����·����·ӳ�䣻i����i����·��
			v2s[index].startSlotNo.add(i,ret[i][0]);//�������ʼ����
			v2s[index].slotNum.add(i,ret[i][1]-ret[i][0]+1);	//�����Ƶ������
		}
		//����ӳ��ɹ���־
		v2s[index].map = Parameters.STATE_MAP_LINK;
		reqs[index].map = Parameters.STATE_MAP_LINK;
	}
		
	
  		
  	/*
	 * ���ù��ڵ���������״̬
	 */
	public void SetExpireVNState(VONRequest reqs[],int end,int time,int delay)
	{
		for (int i = 0; i < end; i ++) {
        	if (reqs[i].time +delay < time) {
                if(v2s[i].map == Parameters.STATE_DONE) {
                  //printf("v[%d]=Done\n",i);
                }  else if(v2s[i].map == Parameters.STATE_MAP_LINK) {
                  //printf("v[%d]=Link Done\n",i);STATE_MAP_SUCC
                }  else if(v2s[i].map == Parameters.STATE_MAP_SUCC) {
                    //printf("v[%d]=Link Done\n",i);
                } else {            
                  //printf("v[%d]=%d expire\n", i,v2s[i].map);
                  v2s[i].map = Parameters.STATE_EXPIRE;
                }
        	}
        }	
	}
	
  	/*
  	 * ��ӡ·��
  	 */
  	public void PrintKShortestPath(AuxiliaryGraph sub,DistanceParent[] shortestPath,int pathNum,int sNode1,int sNode2)
  	{
  		int pathLength = 0;
  		if(shortestPath[sNode2] == null) return;
  		while(shortestPath[sNode2].parentVert != sNode1){
  			if(Parameters.DebugModel) System.out.print(sNode2+"->");
  			sNode2 = shortestPath[sNode2].parentVert;
  			pathLength ++;
  		}
  		if(Parameters.DebugModel) System.out.println(sNode2+"->"+sNode1);
  		//return pathLength+1;
  	}
  	
  	public void PrintVNE(EOSubstrateNetwork sub,VONRequest reqs[]) 
	{
  		//if(v2s[i].map == Parameters.STATE_MAP_LINK || v2s[i].map == Parameters.STATE_DONE || v2s[i].map == Parameters.STATE_MAP_SUCC) {
		     
		for(int index=0;index<reqs.length;index++){
			if(reqs[index].map == Parameters.STATE_MAP_LINK || reqs[index].map == Parameters.STATE_DONE || reqs[index].map == Parameters.STATE_MAP_SUCC) {
				PrintNodeEmbedding(reqs,index);
				PrintLinkEmbedding(reqs,index);
				PrintResultOfVN(sub,reqs,index);
			}
		}
	}
  	//Print the result of embedding virtual nodes.
  	public void PrintNodeEmbedding(VONRequest reqs[],int index)
  	{
  		System.out.println("The "+index+"th virtual network node embedding.");
  		for(int i=0;i<reqs[index].nodes;i++){
  			//System.out.println("v2s["+i+"].snode:"+v2s[index].snode.get(i));
  			int snode = v2s[index].snode.get(i);
  			System.out.println(i+"---"+snode);
  			int reqCount = s2v_n[snode].req_count;
  			//System.out.println("s2v_n["+v2s[index].snode.get(i)+"].req_count:"+s2v_n[v2s[index].snode.get(i)].req_count);
  			for(int j=0;j<reqCount;j++){				
  				//System.out.println("snode:"+snode+" rest_cpu:"+s2v_n[snode].rest_cpu+" req:"+s2v_n[snode].req.get(j)+" vnode:"+s2v_n[snode].vnode.get(j)+" cpu:"+s2v_n[snode].cpu.get(j));
  			}
  		}
  	}
  	//Print the result of embedding virtual nodes.
  	public void PrintNodeEmbedding(VONRequest reqs[])
  	{
  		for(int index=0;index<reqs.length;index++){
  			if(reqs[index].map == Parameters.STATE_MAP_LINK || reqs[index].map == Parameters.STATE_DONE || reqs[index].map == Parameters.STATE_MAP_SUCC) {
  				System.out.println("reqs["+index+"].map:"+reqs[index].map);
  	  	  		System.out.println("The "+index+"th virtual network node embedding.");
  	  	  		for(int i=0;i<reqs[index].nodes;i++){
  	  	  			//System.out.println("v2s["+i+"].snode:"+v2s[index].snode.get(i));
  	  	  			int snode = v2s[index].snode.get(i);
  	  	  			System.out.println(i+"---"+snode);
  	  	  			int reqCount = s2v_n[snode].req_count;
  	  	  			//System.out.println("s2v_n["+v2s[index].snode.get(i)+"].req_count:"+s2v_n[v2s[index].snode.get(i)].req_count);
  	  	  			for(int j=0;j<reqCount;j++){				
  	  	  				//System.out.println("snode:"+snode+" rest_cpu:"+s2v_n[snode].rest_cpu+" req:"+s2v_n[snode].req.get(j)+" vnode:"+s2v_n[snode].vnode.get(j)+" cpu:"+s2v_n[snode].cpu.get(j));
  	  	  			}
  	  	  		}
  			}
  		}
  	}
	public void PrintLinkEmbedding(VONRequest reqs[],int index)
	{
		System.out.println("PrintLinkEmbedding-------------------");
		for(int i=0;i<reqs[index].links;i++){
			int snode1,snode2,vnode1,vnode2;
			vnode1 = reqs[index].link[i].from;
			vnode2 = reqs[index].link[i].to;
			snode1 = v2s[index].snode.get(vnode1);//reqs[index].link[i].from;
			snode2 = v2s[index].snode.get(vnode2);//reqs[index].link[i].to;	
			System.out.println("vlink:"+vnode1+"-"+vnode2);
			System.out.println("slink:"+snode1+"-"+snode2);
			for(int j=0;j<v2s[index].flowLen.get(i);j++){//��������flowLen
				int snodeMid1=-1;//,snodeMid2=-1;
				for(int k=0;k<v2s[index].pathFlow.get(i).len;k++){					
					snodeMid1 = (int)v2s[index].pathFlow.get(i).link.get(k);
					//snodeMid2 = (int)v2s[index].pathFlow.get(i).link.get(k+1);
					//int slink = sub.linksNo[snodeMid1][snodeMid2];
					System.out.print(snodeMid1+"->");
				}
				//System.out.println("");
				System.out.println(v2s[index].pathFlow.get(i).link.get(v2s[index].pathFlow.get(i).len));
			}
			System.out.println("startSlotNo:"+v2s[index].startSlotNo.get(i));
			System.out.println("slotNum:"+v2s[index].slotNum.get(i));
			System.out.println("");
		}
	}
	
	public void PrintLinkEmbedding(VONRequest reqs[])
	{
		for(int index=0;index<reqs.length;index++){
			if(reqs[index].map == Parameters.STATE_MAP_LINK || reqs[index].map == Parameters.STATE_DONE || reqs[index].map == Parameters.STATE_MAP_SUCC) {
				//if(reqs[index].map != Parameters.STATE_MAP_SUCC) continue;
				System.out.println("PrintLinkEmbedding-------------------");
				for(int i=0;i<reqs[index].links;i++){
					int snode1,snode2,vnode1,vnode2;
					vnode1 = reqs[index].link[i].from;
					vnode2 = reqs[index].link[i].to;
					snode1 = v2s[index].snode.get(vnode1);//reqs[index].link[i].from;
					snode2 = v2s[index].snode.get(vnode2);//reqs[index].link[i].to;	
					System.out.println("vlink:"+vnode1+"-"+vnode2);
					System.out.println("slink:"+snode1+"-"+snode2);
					for(int j=0;j<v2s[index].flowLen.get(i);j++){//��������flowLen
						int snodeMid1=-1;//,snodeMid2=-1;
						for(int k=0;k<v2s[index].pathFlow.get(i).len;k++){					
							snodeMid1 = (int)v2s[index].pathFlow.get(i).link.get(k);
							//snodeMid2 = (int)v2s[index].pathFlow.get(i).link.get(k+1);
							//int slink = sub.linksNo[snodeMid1][snodeMid2];
							System.out.print(snodeMid1+"->");
						}
						//System.out.println("");
						System.out.println(v2s[index].pathFlow.get(i).link.get(v2s[index].pathFlow.get(i).len));
					}
					System.out.println("startSlotNo:"+v2s[index].startSlotNo.get(i));
					System.out.println("slotNum:"+v2s[index].slotNum.get(i));
					System.out.println("");
				}
			}
		}
	}
	
	public void Print_sub_slots(EOSubstrateNetwork sub)
	{
		//��ӡsub.slots[][]
		for(int slink=0;slink<sub.links;slink++){
			//if(s2v_l[slink].req_count != 0){
				System.out.println("slink:"+slink+"("+sub.link[slink].from+","+sub.link[slink].to+")"+" sub.slots:"+s2v_l[slink].req_count);
				//��ӡsub.slots
				for(int k=0;k<sub.slotsNum;k++){
					System.out.print(sub.slots[slink][k]+" ");
				}
				System.out.println("");
			//}	
		}	
	}
	public void Print_s2v_l(EOSubstrateNetwork sub,VONRequest reqs[],int index)
	{
		//��ӡs2v_l
		for(int slink=0;slink<sub.links;slink++){
			if(s2v_l[slink].req_count != 0) System.out.println("slink:"+slink+"("+sub.link[slink].from+","+sub.link[slink].to+")"+" is embedded:");
			//System.out.println("The link of req["+index+"]."+i+" is embedded to the substrate links. Req_count:"+s2v_l[slink].req_count+" rest_bw:"+s2v_l[slink].rest_bw);
			for(int j=0;j<s2v_l[slink].req_count;j++){				
				if((int)s2v_l[slink].req.get(j) == index) {
					System.out.print(s2v_l[slink].vlink.get(j)+"("+s2v_l[slink].bw.get(j)+") ");
				}
				System.out.println("");
			}
		}	
	}
	public void Print_s2v_n(VONRequest reqs[],int index)
	{
		//��ӡs2v_n
		for(int i=0;i<reqs[index].nodes;i++){
			int snode;
			snode = v2s[index].snode.get(i);
			System.out.println("The node of req["+index+"]."+i+" is embedded to "+snode+". The information of s2v_n is followed:");
			for(int j=0;j<s2v_n[snode].req.size();j++){
				if(s2v_n[snode].req.get(j) == index){					
					System.out.println("cpu:"+s2v_n[snode].cpu.get(j) + " rest_cpu:"+s2v_n[snode].rest_cpu+" req_count"+s2v_n[snode].req_count);
				}
			}
		}	
	}
	
	public void Print_s2v_n(VONRequest reqs[])
	{
		for(int index=0;index<reqs.length;index++){
			//��ӡs2v_n
			for(int i=0;i<reqs[index].nodes;i++){
				int snode;
				snode = v2s[index].snode.get(i);
				System.out.println("The node of req["+index+"]."+i+" is embedded to "+snode+". The information of s2v_n is followed:");
				for(int j=0;j<s2v_n[snode].req.size();j++){
					if(s2v_n[snode].req.get(j) == index){					
						System.out.println("cpu:"+s2v_n[snode].cpu.get(j) + " rest_cpu:"+s2v_n[snode].rest_cpu+" req_count"+s2v_n[snode].req_count);
					}
				}
			}	
		}
	}
	public void PrintResultOfVN(EOSubstrateNetwork sub,VONRequest reqs[]) 
	{
		for(int index=0;index<reqs.length;index++){
			//��ӡs2v_n
			Print_s2v_n(reqs,index);		

			//��ӡs2v_l
			Print_s2v_l(sub,reqs,index);		
			
			//��ӡsub.slots[][]
			Print_sub_slots(sub);
		}	
	}
	public void PrintResultOfVN(EOSubstrateNetwork sub,VONRequest reqs[],int index) 
	{
		//��ӡs2v_n
		Print_s2v_n(reqs,index);		

		//��ӡs2v_l
		Print_s2v_l(sub,reqs,index);		
		
		//��ӡsub.slots[][]
		Print_sub_slots(sub);		
	}
	public void PrintVNs(VONRequest reqs[],int reqsNum) {    	
		for(int i = 0; i < reqsNum; i++) {
			System.out.println("reqs["+i+"]:"+reqs[i].map+" "+reqs[i].nodes+" "+
					reqs[i].links+" "+reqs[i].split+" "+
			        reqs[i].time+" "+reqs[i].duration+" "+
			        reqs[i].topo+" "+reqs[i].revenue);
				
			for (int j = 0; j < reqs[i].nodes; j++) {
				System.out.println("reqs["+i+"].cpu["+j+"]:"+reqs[i].cpu[j]);				
			}
			
			for (int j = 0; j < reqs[i].links; j++) {
				System.out.println("reqs["+i+"].link["+j+"]:"+reqs[i].link[j].from+" "+reqs[i].link[j].to+" "+reqs[i].link[j].bw+" "+reqs[i].link[j].speed);				
			}
		}
	}
	
	/*
	 * ��ӡĳ��·��
	 */
	public void PrintPath(VONRequest reqs[],int index,DistanceParent[][][]  kShortestPath,int p[][],int virtualNodes[],int pathEff[],int retLinkE[],int retSlotSE[],int retSlotEE[])
	{
		String data = "\r\n-----------"+index+"-----------\r\n";
		
		for(int i=0;i<reqs[index].links;i++){
			int sNode1 = virtualNodes[reqs[index].link[i].from];//������·�˵�from��Ӧ�ĸ���ͼ�ڵ���
			int sNode2 = virtualNodes[reqs[index].link[i].to];//������·�˵�to��Ӧ�ĸ���ͼ�ڵ���
			int sLinkNo = retLinkE[i];//��·ӳ���·�����
			int pathNo1 = 0;
			boolean find = false;
			int vLinkNo = 0;
			int pathByLink = 0;
			for(vLinkNo=0;vLinkNo<reqs[index].links;vLinkNo++){
				find = false;
				for(pathByLink=0;pathByLink<pathEff[vLinkNo];pathByLink++){
					if(pathNo1 == sLinkNo){//�ҵ���·��kShortestPath[k][j]
						//����·��kShortestPath[k][j]������p
						find = true;
						break;
					}
					pathNo1++;
				}
				if(find) break;
			}
			//��ʼ��p[][]
			int sNode3 = sNode2;
			
			data += "virtual link " + i +" is embedded:"+retLinkE[i]+"\r\n";
			System.out.println("virtual link " + i +" is embedded:"+retLinkE[i]+"\r\n");
			while(kShortestPath[vLinkNo][pathByLink][sNode3].parentVert != sNode1){
				if(sNode3 != sNode2){//���������˵�
					p[i][sNode3] = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
				}
				data += sNode3+"->";
				System.out.print(sNode3+"->");
				sNode3 = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
			}
			data += sNode3+"->"+sNode1+"("+retSlotSE[i]+"-"+retSlotEE[i]+")\r\n";;
			System.out.println(sNode3+"->"+sNode1+"("+retSlotSE[i]+"-"+retSlotEE[i]+")");
			//System.out.println(retSlotSE[i]+"-"+retSlotEE[i]);
			//p[i][sNode3] = kShortestPath[vLinkNo][pathByLink][sNode3].parentVert;
		}
		Tools myDowith = new Tools();
	    myDowith.SaveFile("EmbedOutput.dat", data, true);
	}
	
	public void PrintPath(VONRequest reqs[],int index,int vlink,int p[],int sNode1,int sNode2)
	{		
		System.out.print(reqs[index].link[vlink].from+"-"+reqs[index].link[vlink].to+":");
		while(p[sNode2] != -1) {
			System.out.print(sNode2+"-");
			sNode2 = p[sNode2];
		}
		System.out.print(sNode2);
		System.out.println("");
	}
	
	public void PrintPath(int p[],int sNode1,int sNode2)
	{		
		String str = "";
		System.out.println("PrintPath() start:"+sNode1+"-"+sNode2);
		if(Parameters.DebugModel) str += "PrintPath() start:"+sNode1+"-"+sNode2+"\r\n";
		//System.out.print(reqs[index].link[vlink].from+"-"+reqs[index].link[vlink].to+":");
		if(p[sNode2] != -1){
			while(p[sNode2] != -1) {
				System.out.print(sNode2+"-");
				if(Parameters.DebugModel) str+=sNode2+"-";
				sNode2 = p[sNode2];
			}
			System.out.print(sNode2);
			System.out.println("");
			if(Parameters.DebugModel) str+=sNode2+"\r\n";
		} else if(p[sNode1] != -1){
			while(p[sNode1] != -1) {
				System.out.print(sNode1+"-");
				if(Parameters.DebugModel) str+=sNode1+"-";
				sNode1 = p[sNode1];
			}
			System.out.print(sNode1);
			System.out.println("");
			if(Parameters.DebugModel) str+=sNode1+"\r\n";
		} else {
			System.out.println("PrintPath(): error. There is not a path."+sNode1+"-"+sNode2);
		}
		if(Parameters.DebugModel){
			WriteFilePlus("process.txt",str);
		}
	}
	
	public void PrintSN(EOSubstrateNetwork sub) {
		//Create sub.cpu[].
		for(int i=0;i<sub.nodes;i++){
			System.out.println("sub.cpu["+i+"]:"+sub.cpu[i]);			
		}
			
		//Create sub.link[].
		for(int i=0;i<sub.links;i++){
			System.out.println("sub.link["+i+"]:"+sub.link[i].from+" "+sub.link[i].to+" " +sub.link[i].bw+" "+sub.link[i].speed);
		}
		
		for(int i=0;i<sub.links;i++){
			for(int j=0;j<sub.slotsNum;j++)//Parameters.MaxSlots
				System.out.println("sub.slots["+i+"]["+j+"]:"+sub.slots[i][j]);
		}
				
		//Create sub.modulevel[]\transRate[]\opticalReach[]
		for(int i=0;i<sub.modulationLevel;i++){
			System.out.println("sub.modulevel["+i+"]:"+sub.modulevel[i]+" "+sub.transRate[i]+" "+sub.opticalReach[i]);	
		}		
	}
	/*
  	 * ����cpu
  	 */
  	public void UpdateSub(EOSubstrateNetwork toSub,EOSubstrateNetwork fromSub)
  	{
  		for(int i=0;i<fromSub.nodes;i++){
  			toSub.cpu[i] = fromSub.cpu[i];
  		}
  	}
  	/*
  	 * ����slots
  	 */
  	public void UpdateSubSlots(EOSubstrateNetwork toSub,EOSubstrateNetwork fromSub)
  	{
  		for(int i=0;i<fromSub.nodes;i++){
  			for(int j=0;j<Parameters.MaxSlots;j++){
  				toSub.slots[i][j] = fromSub.slots[i][j];
  			}
  		}
  	}
  	/*
  	 * ����cpu
  	 */
  	public void UpdateSub(EOSubstrateNetwork sub,int sNode,double cpu)
  	{
  		sub.cpu[sNode] -= cpu;
  	}
	/*
  	 * ����
  	 */
  	public void Clone(EOSubstrateNetwork toSub,EOSubstrateNetwork fromSub)
  	{
  		toSub.diffSlot = fromSub.diffSlot;
  		toSub.faNodesNum = fromSub.faNodesNum;
  		toSub.links = fromSub.links;
  		toSub.modulationLevel = fromSub.modulationLevel;
  		toSub.modulevel = fromSub.modulevel;
  		toSub.netNodes = fromSub.netNodes;
  		toSub.nodes = fromSub.nodes;
  		toSub.opticalReach = fromSub.opticalReach;
  		toSub.slotGHz = fromSub.slotGHz;
  		toSub.slotsNum =fromSub.slotsNum;
  		toSub.transRate = fromSub.transRate;
  		
  		
  		toSub.cpu = new double[fromSub.nodes];
  		toSub.faNodes = new int[fromSub.faNodesNum];
  		toSub.link = new LinkStruct[fromSub.links];
  		toSub.slots = new int[fromSub.links][fromSub.slotsNum];
  		toSub.linksNo = new int[fromSub.nodes][fromSub.nodes];
  		for(int i=0;i<fromSub.nodes;i++){
  			toSub.cpu[i] = fromSub.cpu[i];
  		}
  		for(int i=0;i<fromSub.faNodesNum;i++){
  			toSub.faNodes[i] = fromSub.faNodes[i];
  		}
  		for(int i=0;i<fromSub.links;i++){
  			toSub.link[i] = fromSub.link[i];
  		}
  		for(int i=0;i<fromSub.links;i++){
  			for(int j=0;j<fromSub.slotsNum;j++)
  			toSub.slots[i][j] = fromSub.slots[i][j];
  		}
  		for(int i=0;i<fromSub.nodes;i++){
			for(int j=0;j<fromSub.nodes;j++)
				toSub.linksNo[i][j] = fromSub.linksNo[i][j];
		}
  	}
	
	public void CreateSN(EOSubstrateNetwork sub) throws IOException {
    	String strBuff;
		BufferedReader data = new BufferedReader(new InputStreamReader(new FileInputStream(SNFile)));
		//read a line which means a number of virtual optical network requests. 
		//For an example, 10 is the number of virtual optical network requests. 
		strBuff = data.readLine();	//the number of virtual optical network requests
		String[] strcol = strBuff.split(" ");
		int nodesNum = Integer.valueOf(strcol[0]);//�ڵ�����
		int linksNum = Integer.valueOf(strcol[1]);//��·����
		int slotsNum = Integer.valueOf(strcol[2]);//The number of slots each link.
		//slotsNum = Parameters.MaxSlots;
		double slotGHz = Double.valueOf(strcol[3]);//The transmission rate each link.
		int modulationLevel = Integer.valueOf(strcol[4]);//The number of modulation level.
		int diffSlot = Integer.valueOf(strcol[5]);//The number of slot between two slots.
		int faNodesNum = Integer.valueOf(strcol[6]);
		
		Parameters.MaxSlots = slotsNum;//2019.4.30����
		
		//sub = new EOSubstrateNetwork();//Create the elastic optical substrate network.
		sub.cpu = new double[nodesNum];
		sub.nodes = nodesNum;
		sub.links = linksNum;
		sub.link = new LinkStruct[linksNum];
		sub.opticalReach = new double[modulationLevel];
		sub.slotsNum = slotsNum;
		sub.slotGHz = slotGHz;
		sub.modulationLevel = modulationLevel;
		sub.transRate = new double[modulationLevel];
		sub.slots = new int[linksNum][slotsNum];
		sub.modulevel = new String[sub.modulationLevel+1];
		sub.diffSlot = diffSlot;
		sub.faNodes = new int[faNodesNum];
		sub.faNodesNum = faNodesNum;
		
		//Init slots.
		for(int i=0;i<sub.links;i++){
			for(int j=0;j<sub.slotsNum;j++)
				sub.slots[i][j] = 1;//����Ϊ1��ռ��Ϊ0
		}
		//Create sub.cpu[].
		for(int i=0;i<sub.nodes;i++){
			strBuff = data.readLine(); //Read the line of a sub information.
			sub.cpu[i] = Double.valueOf(strBuff);///2.0; 
		}
		
		//Create sub.link[].
		for(int i=0;i<sub.links;i++){
			strBuff = data.readLine(); //Read the line of a sub information.
			strcol = strBuff.split(" ");
			sub.link[i] = new LinkStruct();
			sub.link[i].from = Integer.valueOf(strcol[0]);
			sub.link[i].to = Integer.valueOf(strcol[1]);
			sub.link[i].bw = Double.valueOf(strcol[2]);
			sub.link[i].length = Double.valueOf(strcol[3])/10000.0;///10.0;	//�������5		
		}
		
		//����from��to�õ���·��linkNo[sub.nodes][sub.nodes]
		sub.linksNo = new int[sub.nodes][sub.nodes];
		for(int i=0;i<sub.nodes;i++){
			for(int j=0;j<sub.nodes;j++)
				sub.linksNo[i][j] = -1;
		}
		for(int i=0;i<sub.links;i++){
			sub.linksNo[sub.link[i].from][sub.link[i].to] = sub.linksNo[sub.link[i].to][sub.link[i].from] = i;
		}
		
		//Create sub.modulevel[]\transRate[]\opticalReach[]
		for(int i=0;i<sub.modulationLevel;i++){
			strBuff = data.readLine(); //Read the line of a sub information.
			strcol = strBuff.split(" ");
			sub.modulevel[i] = String.valueOf(strcol[0]);
			sub.transRate[i] = Double.valueOf(strcol[1]);
			sub.opticalReach[i] = Double.valueOf(strcol[2]);	
		}
		
		//����sub.opticalReach
		boolean changed;
		double reachMid;
		String strMid;
		for(int i=0;i<sub.modulationLevel;i++){			
			changed = false;
			for(int j=i+1;j<sub.modulationLevel;j++) {				
				if(sub.opticalReach[i] < sub.opticalReach[j]) {
					changed = true;
					reachMid = sub.opticalReach[i];	//change the opticalReach[i] and opticalReach[j]
					sub.opticalReach[i] = sub.opticalReach[j];
					sub.opticalReach[j] = reachMid;
					
					reachMid = sub.transRate[i];
					sub.transRate[i] = sub.transRate[j];
					sub.transRate[j] = reachMid;
					
					strMid = sub.modulevel[i];
					sub.modulevel[i] = sub.modulevel[j];
					sub.modulevel[j] = strMid;					
				}
			}
			if(!changed) break;
		}
		
		//Create sub.faNodes[]:�����faNodes�ڵ��.
		for(int i=0;i<faNodesNum;i++){
			strBuff = data.readLine(); //Read the line of a sub information.
			sub.faNodes[i] = Integer.valueOf(strBuff); 
		}
		
		data.close();		
		return ;
    }
	
	
	//Create virtual network requests from the files from the directory of VNsFileDir.
	public void CreateVNs(VONRequest reqs[],int reqsNum) throws IOException {
    	String strBuff;
    	String[] strcol;
		BufferedReader data;// = new BufferedReader(new InputStreamReader(new FileInputStream(VNsFileDir)));

		String strName = "";
		for(int i = 0; i < reqsNum; i++) {
			strName = "" + VNsFileDir + "/req" + String.valueOf(i) + ".txt";
			data = new BufferedReader(new InputStreamReader(new FileInputStream(strName)));
			strBuff = data.readLine();
			strcol = strBuff.split(" ");
			reqs[i] = new VONRequest();
			reqs[i].map = Parameters.STATE_NEW;//1;
			reqs[i].nodes = Integer.valueOf(strcol[0]);
			reqs[i].links = Integer.valueOf(strcol[1]);
			reqs[i].split = Integer.valueOf(strcol[2]);
			reqs[i].time = Integer.valueOf(strcol[3]);
			reqs[i].duration = Integer.valueOf(strcol[4]);
			reqs[i].topo = Integer.valueOf(strcol[5]);
			reqs[i].revenue = 0;
			
			reqs[i].cpu = new double[reqs[i].nodes];			
			for (int j = 0; j < reqs[i].nodes; j++) {
				strBuff = data.readLine();
				strcol = strBuff.split(" ");//2020-9-15add chenxh
				reqs[i].revenue = 0;
				//reqs[i].cpu[j] = Double.valueOf(strBuff)/1.5;//;//1.5���ģ
				//reqs[i].cpu[j] = Double.valueOf(strcol[2]);///2.5;
				reqs[i].cpu[j] = Double.valueOf(strcol[2])*0.6;;////*1.5;;//*0.06;//*1.5;//*0.3;
				reqs[i].revenue += reqs[i].cpu[j];
			}
			
			reqs[i].link = new LinkStruct[reqs[i].links];
			for (int j = 0; j < reqs[i].links; j++) {
				strBuff = data.readLine();
				strcol = strBuff.split(" ");
				reqs[i].link[j] = new LinkStruct();
				reqs[i].link[j].from = Integer.valueOf(strcol[0]);
				reqs[i].link[j].to = Integer.valueOf(strcol[1]);
				reqs[i].link[j].bw = Double.valueOf(strcol[2])*0.002;//*0.02;//*0.2;//���ģ*30;//*0.2;//*0.2С��ģ;//*30;//30���ģ;//*5;//*30;//*30;// * 60;
				reqs[i].link[j].speed = Double.valueOf(strcol[3]);//*0.01;
				reqs[i].revenue += reqs[i].link[j].bw;			    
			}
			data.close();	
		}
		
	}
	
	//start pagerank
	public boolean judge (int nodes_num, float backup[], double result[])
	{
	    int i;
	    double ELSILON=0.0001;
	    for (i=0; i<nodes_num; i++)
	    {
	        if (Math.abs(result[i] - backup[i]) >= ELSILON)
	        {
	            //float f = fabs (result[i] - backup[i]) ;
	            return true; 
	        }
	    }   
	    return false;    
	}
	
	public double[] pagerank(int nodes_num, int links_num, double cpu[], LinkStruct[] link, double[] sum_adj, float sum_all, double cb_value[], double rank[])
	{
	    int i, j,k;
	    float DAMPING=(float) 0.01;//0.15;
	    float backup[]=new float[nodes_num];
	    float poss1[][]=new float[nodes_num][nodes_num];
	   // poss1 = (float**) malloc (nodes_num * sizeof (float*));
	 //   for (i=0; i<nodes_num; i++)
	   //     poss1[i] = (float*) malloc (nodes_num * sizeof (float));    
			            
	    for (i=0; i<nodes_num; i++)                                                
	    {
	        for (j=0; j<nodes_num; j++)
	        {
	            poss1[i][j] = 0;
	            poss1[i][j] = (float) (DAMPING*cb_value[j]/sum_all);  //DAMPING=0.15��p(uj)  ,,poss1[i][j]�����ڵ�j��cb_valueռ���нڵ�ļ���֮�� 

	            for (k = 0; k< links_num; k ++)
	            {
	                if ((link[k].from == i && link[k].to == j) || (link[k].from == j &&link[k].to == i)) 
	                {
	                    poss1[i][j] += (1-DAMPING)*cb_value[j]/sum_adj[i];//1-DAMPING=0.85��p(uf)   �������������ڵ�i��j֮���й�������poss1[i][j]�ټ��� j�ڵ��cb_valueֵռi�ڵ���Χ���нڵ�cb_value�ļ���֮�� 
	                    if(sum_adj[i] == 0)
	                       System.out.println("bupt:sum_adj "+i+" is 0\n");
	                      // printf();
	                }
	            }
	        }
	    }
	    //���Կ���poss[i][j] 
	    
	    
	   // backup = (float*) malloc (nodes_num * sizeof (float));
	    for (i=0; i<nodes_num; i++)
	        backup[i] = 0;
	    int iteration_time = 0;
	    for(i = 0;i<nodes_num;i++)
	    {    
	        rank[i] = rank[i]/sum_all;   //pagerank��ʼֵ���������нڵ�rankֵ������ʵ���ǵ�ǰcb_value��ֵռ���нڵ�cb_value��ֵ�ļ���֮�� 
	    }    
	    while (judge(nodes_num, backup, rank))   //�����������Сֵ0.0001����ѭ�� 
	    {
	        iteration_time++;  //��������++ 
	        for (i=0; i<nodes_num; i++)
	        {
	            backup[i] = (float) rank[i];   //����backup��rank 
	            rank[i] = 0;    //��ʼ���µ�rank 
	        }

	        for (i=0; i<nodes_num; i++)

	        {
	            for (j=0; j<nodes_num; j++)
	                rank[i] = rank[i] + backup[j] * poss1 [j][i];    //�µ�rank=rank+������rank* poss1[j][i] 
	        }
	    }
	    
	    
//	#ifdef DEBUG_RW
	    System.out.println("bupt: iteration need "+iteration_time+" times\n");  //��Ҫ���ٴε��� 
//	#endif
//    free (backup);
//	    for(i = 0;i<nodes_num;i++)
//	        free(poss1[i]);
//	    free(poss1);
	    return rank;
	}

	//decide whether continue iteration
	/*
	* ���ܣ�����ʣ��restSlots[]
	*/
	public void InitRestSlots(double restSlots[],EOSubstrateNetwork sub)
	{	
		int sum = 0;
		for(int i=0;i<sub.links;i++){
			sum = 0;
			for(int j=0;j<Parameters.MaxSlots;j++){
				if(sub.slots[i][j] == 1){
					sum ++;
				}
			}
			restSlots[i] += (double)sum;
		}
	}
	
	public double[] InitSNodePageRank(double sNodePageRank[],EOSubstrateNetwork sub)
	{
		int i,j,k;
		float sum_bw = 0;
		float sum_all=0;
		sub.cb_value=new double[ sub.nodes];
		sub.sum_adj=new double[ sub.nodes];
		//sub.rank=new double[ sub.nodes];
		double restSlots[] = new double[sub.links];//�ײ���·�Ŀ���slot
		InitRestSlots(restSlots,sub);//��ʼ������slot
		
		for(i = 0; i < sub.nodes; i ++) {
		    sum_bw = 0;
		      //���ѭ���Ǽ����ÿһ���ڵ���Χ��ʣ�����
		    for (k = 0; k < sub.links; k ++){
		         if (sub.link[k].from == i || sub.link[k].to == i) {
		        	 //if(sub.link[k].from == i && s2v_l[k].rest_bw > 0)
		             if(sub.link[k].from == i && restSlots[k] > 0){//cxh�޸�2019.07.27
		                   j = sub.link[k].to;
		                   //sum_bw += s2v_l[k].rest_bw;
		                   sum_bw += restSlots[k];//cxh�޸�2019.07.27
		             }else if(sub.link[k].to == i && restSlots[k] > 0){//cxh�޸�2019.07.27
		            //}else if(sub.link[k].to == i && s2v_l[k].rest_bw > 0){
		                        j = sub.link[k].from;
		                        //sum_bw += s2v_l[k].rest_bw;
		                        sum_bw += restSlots[k];
		             		}
		                }
		            }
		           
		            sub.cb_value[i] = s2v_n[i].rest_cpu*sum_bw;  //cb_value��ʾ��ǰ�ýڵ���Χʣ��������Լ�����cpu�ĳ˻� 
		            
		          //  sub.rank[i] = s2v_n[i].rest_cpu*sum_bw;  
		            sNodePageRank[i]= s2v_n[i].rest_cpu*sum_bw;
		            sum_all += sub.cb_value[i];     			 //sum_allΪ���нڵ��cb_value��ֵ 

		            if(s2v_n[i].rest_cpu < 0 || sum_bw < 0 ||sub.cb_value[i] < 0)
		            {
		                System.out.println("bupt: error! cb_value is non negative\n");
		                System.out.println("bupt:s2v_n["+i+"].rest_cpu is "+s2v_n[i].rest_cpu+",sum_bw is "+sum_bw+",sub.cb_value is "+sub.cb_value[i]+"\n");
		            }

		        }
		        for(i = 0;i < sub.nodes;i++)
		        {
		            sub.sum_adj[i]  = 0;
		            for(k = 0;k < sub.links; k++)
		            {

		                if (sub.link[k].from == i || sub.link[k].to == i) 
		                {
		                    if(sub.link[k].from == i)
		                    {
		                        j = sub.link[k].to;
		                        sub.sum_adj[i] += sub.cb_value[j];   //sub.sum_adj[i]Ϊ������ǰ�ڵ��rankֵΪ��Χ���нڵ�� cb_value���ܺ� 
		                    }
		                    else if(sub.link[k].to == i)
		                    {
		                        j = sub.link[k].from;
		                        sub.sum_adj[i] += sub.cb_value[j];
		                    }
		                }

		            }
		        }  
		        System.out.println("bupt: sum_all is "+sum_all+"\n");
		        sNodePageRank=  pagerank(sub.nodes, sub.links, sub.cpu, sub.link, sub.sum_adj,  sum_all, sub.cb_value, sNodePageRank);
		        return sNodePageRank;
		       
	}

	public double[] InitVNodePageRank(double[] vNodePageRank,VONRequest req[],int index){
		int j,k;
		int  i=index;
		//int n=req[index].nodes;
		float sum_all;
		
        sum_all = 0;
       
        	req[i].cb_value=new double[req[i].nodes];
        	req[i].sum_adj=new double[req[i].nodes];
        	req[i].rank	=new double[req[i].nodes];
            for(j=0;j < req[i].nodes;j++)
            {
                float sum_bw = 0;
                for(k = 0;k < req[i].links;k++)
                {
                    if(req[i].link[k].from == j)
                    {
                        sum_bw += req[i].link[k].bw;
                    }else if(req[i].link[k].to == j)
                    {
                        sum_bw += req[i].link[k].bw;

                    }
                }
                //System.out.println(req[i].cpu[j]+"      "+sum_bw);
               // double a=req[i].cpu[j] * sum_bw;
               // System.out.println(a);
                
                req[i].cb_value[j] = req[i].cpu[j] * sum_bw;
                req[i].rank[j] = req[i].cb_value[j];
                sum_all += req[i].cb_value[j];

            }
            for(j = 0;j < req[i].nodes;j++)
            {
                for(k = 0;k < req[i].links;k++)
                {
                    if(req[i].link[k].from == j)
                    {
                        req[i].sum_adj[j] += req[i].cb_value[req[i].link[k].to];
                    }else if(req[i].link[k].to == j)
                    {
                        req[i].sum_adj[j] += req[i].cb_value[req[i].link[k].from];

                    }

                }

            }
          
            //sNodePageRank= pagerank(req[i].nodes, req[i].links, req[i].cpu, req[i].link, req[i].sum_adj, sum_all, req[i].cb_value, sNodePageRank);
            vNodePageRank= pagerank(req[i].nodes, req[i].links, req[i].cpu, req[i].link, req[i].sum_adj, sum_all, req[i].cb_value, req[i].rank);//2019.7.24�޸�
		//return sNodePageRank;
		return vNodePageRank;//2019.7.24�޸�
	}
}
