package Team.CloudStorage.EAVONE;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

public class VONEByKSPath extends VNE {
	
	public void VONEEmbed(String inSNFile,String inVNsFileDir,int reqsNum,int delay) throws IOException
	{
		//����SN��VNs
		super.VONEEmbed(inSNFile, inVNsFileDir, reqsNum, delay);
		embedModelOrAlgo = Parameters.CurrentVONEMethod;//.MapVONE3ByWangY;//.MapVONETranModel;
		V2SEmbed(sub,reqs,delay);//,Parameters.MapVONETranModel
	}
	
	/*The algorithm of mapping the VNs.*/
	private void V2SEmbed(EOSubstrateNetwork sub,VONRequest reqs[],int delay) throws IOException
	{
		//embedModelOrAlgo = embedAlgorithm;//ӳ��ģ�ͻ����㷨������embedModelOrAlgo
		int end,n,time,start,sStart;
		time = Parameters.TIME_INTERVAL;
		end = 0;
		n = reqs.length;
		System.out.println("reqs.length:"+n);
		Date startDate = new Date();//��¼ӳ�俪ʼ��ʱ��
	    while (end < n || reqs[n-1].time+delay>time) {   //The value of n is the number of all the VNs.
	        while (end < n && reqs[end].time < time) end++; 
	        for(sStart=0;sStart<n-1 && (reqs[sStart].time+delay)<time;sStart++) ;//˵���ҵ��˵�ǰ��С�Ŀ�ʼ������������
	        //for(sStart=0;reqs[sStart].time<time;sStart++) ;
	        start = sStart;
	        System.out.println("sStart:" + sStart + " end:" + end);
	        
	        //Release the resources.
	        ReleaseAllResourceAmongZeroToEnd(sub,reqs,end,time);
	        
	        //Set the expire of STATE_EXPIRE.
	        SetExpireVNState(reqs,end,time,delay);
	                
	        //Allocate the resources.
	        AllocateResources(sub,reqs,start, end);	     
	        
	        time += Parameters.TIME_INTERVAL;  //ʱ�䴰����һ����λ

	    }
	    Date endDate = new Date();//��¼ӳ�俪ʼ��ʱ��
	    long interval = (endDate.getTime() - startDate.getTime())/1000;//��¼ʱ���룩

	    //��¼��Ϣ������ϵͳ���桢�����ʡ�����ɱ��ȡ�������Ƭ�����Ѷ��壬�����������ΪС��2�������Ŀ���SlotsΪ��Ƭ��
	    if(Parameters.DebugModel) {
	    	System.out.println("RecordResultsOfVNE.");
	    }
	    RecordResultsOfVNE(sub,reqs,interval,embedModelOrAlgo);
	    
	    if(Parameters.DebugModel) System.out.println("PrintfVNE.");

	    //if(Parameters.DebugModel) PrintNodeEmbedding(reqs);
	    //if(Parameters.DebugModel) PrintLinkEmbedding(reqs);
		//PrintVNE(sub, reqs);PrintResultOfVN(sub,reqs);
	}
	
	//
	private void AllocateResources(EOSubstrateNetwork sub,VONRequest reqs[],int start,int end) throws IOException
	{
		System.out.println("start:" + start + " end:" + end);
		for(int i=start;i<end;i++){
			if(v2s[i].map == Parameters.STATE_NEW || v2s[i].map == Parameters.STATE_MAP_NODE_FAIL || v2s[i].map == Parameters.STATE_MAP_FAIL || v2s[i].map == Parameters.STATE_MAP_Link_FAIL) {
				ArrayList<Object> list = new ArrayList<Object>();  //��¼�ڵ�ӳ����
				int p[][] = new int[reqs[i].links][sub.nodes];
				int ret[][] = new int[reqs[i].links][4];
				//ret[][0]:����������·ӳ���������㣻ret[][1]:����������·ӳ��������յ�
				//ret[][2]:���ص���ʼƵ�ײۣ�ret[][3]:���ص�Ƶ�ײ�����
				v2s[i].tryMapTime ++;	//��¼ӳ�����			
				if(reqs[i].topo == Parameters.TOPO_GENERAL || reqs[i].topo == Parameters.TOPO_STAR) {					
					DebugVNE(sub,reqs,i,Parameters.CurrentVONEMethod,"before embed req "+i);
					if(MapVONEByILPWangYPlus3Nodes(sub,reqs,i,ret[0],p,list)!=-1){
						if(Parameters.DebugModel) Print_sub_slots(sub);
						v2s[i].map = Parameters.STATE_MAP_SUCC;
						reqs[i].map = Parameters.STATE_MAP_SUCC;
						DebugVNE(sub,reqs,i,Parameters.CurrentVONEMethod,"after embed succ req "+i);
					} else {
						v2s[i].map = Parameters.STATE_MAP_NODE_FAIL;
						reqs[i].map = Parameters.STATE_MAP_NODE_FAIL;
					}
				}
			}
		}
	}
	
	/*
	 * ���ö�·��ӳ���ILPģ��ӳ��
	 */
	private int MapVONEByILPWangYPlus3Nodes(EOSubstrateNetwork sub,VONRequest reqs[],int index,int ret[],int p[][],ArrayList<Object> list)
	{
		//��������ͼ
		AuxiliaryGraph auxGraph = new AuxiliaryGraph();
		auxGraph = CreateAuxiliaryDiagram(sub,reqs,index);

		//����k��·����·�����ȴ���2��
		WeightedDirectedGraph myGraph = new WeightedDirectedGraph(auxGraph.nodes,sub.nodes);
		myGraph.CreateDireGraph(auxGraph);//�����ڵ�
		//CreateEdgeFromAux(auxGraph,myGraph);
		
		int pathK = Parameters.K_PATH;//5;//ҪѰ�ҵ�K���·��
		int pathRet = -1;//��¼���ص����·������
		//int pathKSum = 0;
		int[] pathEff = new int[reqs[index].links];

	    DistanceParent[][][]  kShortestPath = new DistanceParent[reqs[index].links][pathK][auxGraph.nodes];
		
		for(int i=0; i < reqs[index].links; i++)
		{
			int sNode1,sNode2;
			sNode1 = reqs[index].link[i].from + sub.nodes;
			sNode2 = reqs[index].link[i].to + sub.nodes;
			int limitPathLength = 2;
			System.out.println("link "+i+":"+sNode1+","+sNode2+"-----------");
			//pathRet = myGraph.findKShortestPath(pathK, sNode1, sNode2);//.findKShortestPath(pathK,sNode1,sNode2,limitPathLength);
			//pathRet = myGraph.findKShortestPath(pathK,sNode1,sNode2,limitPathLength);
			pathRet = myGraph.findKShortestPathByMIL(pathK,sNode1,sNode2,limitPathLength);
			pathEff[i] = pathRet;
			if(pathRet <= 0) return -1;//û��·��������ʧ��
			for(int j=0;j<myGraph.kShortestPath.length;j++){
				for(int k=0;k<myGraph.kShortestPath[j].length;k++){
					kShortestPath[i][j][k] = myGraph.kShortestPath[j][k];
				}
			}
			//kShortestPath[i] = myGraph.kShortestPath;//�ҵ���·����������
			System.out.println("----------------print ret path.");
			for(int k=0;k<pathRet;k++)
				myGraph.displayPaths(myGraph.kShortestPath[k]);
		}
		
		//���ÿ��·����ÿ�������slots�����Լ��Ƿ���Ч
		int[][] pathSlots = new int[reqs[index].links][Parameters.K_PATH];
		int[][] pathLength = new int[reqs[index].links][Parameters.K_PATH];
		int[][] pathNo = new int[reqs[index].links][Parameters.K_PATH];
		int[][] pathMD = new int[reqs[index].links][Parameters.K_PATH];
		double[][] pathLen = new double[reqs[index].links][Parameters.K_PATH];
		CalculatePathSlotsAndEffects(auxGraph,kShortestPath,pathSlots,pathLength,pathNo,pathEff,reqs,index,pathLen);
		boolean find = false;
		
		find = CalPathMD(pathMD,pathLen,pathEff,reqs,index);
		if(!find) return -1;//�õ�MD����ģʽ
		
		find = false;
		for(int i=0;i<reqs[index].links;i++){
			for(int j=0;j<Parameters.K_PATH;j++){
				if(pathNo[i][j]>-1) find = true;
			}
		}//if(pathSlots)
		if(!find) return -1;
			
		//��WangY��ILPģ����⣬���߸�����ǿ�Ļ���·����ӳ��ģ�����
		if(Parameters.CurrentVONEMethod == Parameters.MapVONEMIPTranAndPRankByCXH){
			FindVONETranPageRank(auxGraph,kShortestPath,pathSlots,pathLength,pathNo,pathEff,reqs,index);
		} else if(Parameters.CurrentVONEMethod == Parameters.MapVONETranILPByChenxh){
			FindVONETran(auxGraph,kShortestPath,pathSlots,pathLength,pathNo,pathEff,reqs,index);
		} else {
			FindVONEWangYPlusByOne01ILP(auxGraph,kShortestPath,pathSlots,pathLength,pathNo,pathEff,reqs,index);
		}
		
		//�����Ž�
		int retNodeE[],retLinkE[],retSlotSE[],retSlotEE[],retSlotBE[],retLinkMD[][];
		retNodeE = new int[reqs[index].nodes];
		retLinkE = new int[reqs[index].links];
		retLinkMD = new int[reqs[index].links][Parameters.K_PATH];
		retSlotSE = new int[reqs[index].links];
		retSlotEE = new int[reqs[index].links];
		retSlotBE = new int[reqs[index].links];
		
		if(FindVONEOptimalSolutionPlusWangY(auxGraph,retNodeE,retLinkE,retSlotSE,retSlotEE,retSlotBE,retLinkMD)){//�ҵ������Ž�
			//AddNodesMap(reqs,index,list);//�ڵ�ӳ��
			//for(int i=0;i<reqs[index].links;i++){
			//	System.out.println("link "+i+" is embedded the path:"+retLinkE[i]);
			//}
			if(Parameters.DebugModel == true){
				String str = "\r\nretLinkMD[][]=\r\n";
				for(int i=0;i<reqs[index].links;i++){
					for(int j=0;j<Parameters.K_PATH;j++){
						if(retLinkMD[i][j] == 1){
							str += i+" "+j+" "+pathMD[i][j]+" "+pathSlots[i][j]+"\r\n"; 
						}
					}
				}
				WriteFilePlus("process.txt",str);
			}
			//����Ƿ������е�Ƶ�ײ۳�ͻ����slot�Ѿ���0�������Ҫ�������䣬�������⡣
			
			//��⹲����·�Ķ��·���Ƿ����slot��ͻ�������ͻ������false�����򣬷���true
            //boolean CheckPathSlotsIfEff(VONRequest reqs[],int index,DistanceParent[][][]  kShortestPath,int p[][],int virtualNodes[],int retLinkE[],int retSlotSE[],int retSlotEE[])
            
			if(CheckPathSlotsIfEff(reqs,index,kShortestPath,p,auxGraph.virtualNodes,retLinkE,retSlotSE,retSlotEE) == false) {
            	//System.out.println("������ĳ����·�У�����Ƶ�ײ۳�ͻ");
            	String data = index + " ����Ƶ�ײ۳�ͻ\r\n";
            	Tools myDowith = new Tools();
        	    myDowith.SaveFile("EmbedOutput.dat", data, true);
            	return -1;
            }
            //System.out.println("������Ƶ�ײ۳�ͻ");
            PrintPath(reqs,index,kShortestPath,p,auxGraph.virtualNodes,pathEff,retLinkE,retSlotSE,retSlotEE);
            //AddNodesMap(reqs,index,retNodeE);//�ڵ�ӳ��
			//AddLinksMapByMIPWangYPlus(sub,reqs,index,retSlotSE,retSlotEE,retLinkE,kShortestPath,pathEff,pathNo,auxGraph.virtualNodes,retNodeE);
            boolean check = true;
            EOSubstrateNetwork subCopy = new EOSubstrateNetwork();
    		Clone(subCopy,sub);
            check = CheckLinksMapByMIPWangYPlus(subCopy,reqs,index,retSlotSE,retSlotEE,retLinkE,kShortestPath,pathEff,pathNo,auxGraph.virtualNodes,retNodeE);
			if(check == false) return -1;
            AddNodesMap(reqs,index,retNodeE);//�ڵ�ӳ��
			AddLinksMapByMIPWangYPlus(sub,reqs,index,retSlotSE,retSlotEE,retLinkE,kShortestPath,pathEff,pathNo,auxGraph.virtualNodes,retNodeE);
			//����cpu
			for(int i=0;i<reqs[index].nodes;i++){
				sub.cpu[retNodeE[i]] -= reqs[index].cpu[i];
			}
			//retNodeE[]
			//UpdateSub(sub,subCopy);
			return 0;//�ɹ��ҵ�VONE��
		}
		return -1;
	}
	
	/*����:������������ӳ��
	 * ����:auxGraph������ͼ
	 * kShortestPath:ÿ������·�����·��
	 * pathSlots:·���������slots����
	 * pathLength:·���ĳ���
	 * pathNo:·���ı��
	 * int[] pathEff:��Ч·������
	 */
	private void FindVONEWangYPlusByOne01ILP(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathSlots,int[][] pathLength,int[][] pathNo,int[] pathEff, VONRequest reqs[],int index)
	{
		int M = auxGraph.slotsNum;
		
		Tools myDowith = new Tools();
		
		String data;
		
		data = "set MSet:=";
		for(int i = 0; i < M; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, false);
		
		data = "set Path:=";
		int pathSum = 0;
		for(int j = 0; j < reqs[index].links; j ++) {
			pathSum += pathEff[j];
		}
		for(int i = 0; i < pathSum; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set P[0]:=0 1 6;
		//set P[1]:=4 5;
		//set P[2]:=2 3;
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set P[" + i + "]:=";
			for(int j = 0; j < pathEff[i]; j++){
				if(pathLength[i][j] > 2 && pathNo[i][j] != -1) data += " " + pathNo[i][j];
			}
			data += ";\r\n";
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Nv:=4 5 7;/*����ڵ�ļ���*/
		data = "set Nv:=";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set F:=0 1 2 3;/*�������ڵ㣨facility nodes���ļ���*/
		data = "set F:=";
		for(int i = 0; i < auxGraph.faNodesNum; i++){		//sub.nodes	
			data += " " + auxGraph.faNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Na:=0 1 2 3 4 5 6 7;/*����ͼ�Ľڵ㼯�ϣ�Na=F��Nv������ڵ�*/
		data = "set Na:=";
		for(int i = 0; i < auxGraph.nodes; i++){		//sub.nodes	
			data += " " + i;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set A[4]:=
		//4 0
		//4 2
		//;/*��ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set A[" + auxGraph.virtualNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					//if(reqs[index].cpu[i] <= s2v_n[auxGraph.virtServLinks[j].to].rest_cpu)
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					//if(reqs[index].cpu[i] <= s2v_n[auxGraph.virtServLinks[j].from].rest_cpu)
					data += auxGraph.virtServLinks[j].to + " " + auxGraph.virtServLinks[j].from + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		//set Afa[0]:=
		//4 0
		//;/*�������ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < auxGraph.faNodesNum; i ++)
		{
			data = "set Afa[" + auxGraph.faNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].to == auxGraph.faNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].from == auxGraph.faNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		//set Af[4]:=0 2;/*ÿ������ڵ��ӳ��Ľڵ㼯��*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set Af[" + auxGraph.virtualNodes[i] + "]:=";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					data += " " + auxGraph.virtServLinks[j].to;
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					data += " " + auxGraph.virtServLinks[j].from;
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		data = "set Elink:=\r\n";
		for(int i = 0; i < auxGraph.links; i++){		//sub.nodes	
			boolean find = false;
			for(int k=0;k<reqs[index].nodes;k++){
				if(auxGraph.link[i].from == auxGraph.virtualNodes[k] || auxGraph.link[i].to == auxGraph.virtualNodes[k]){
					find = true;
					break;
				}
			}
			if(find) continue;
			if(auxGraph.link[i].from == auxGraph.link[i].to) continue;
			data += " " + auxGraph.link[i].from + " " + auxGraph.link[i].to + "\r\n";   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set FS[0,0]:=0 1 2 3 4 5 6 7 8 9;/*·��p�Ͽ��ܵ���ʼƵ�ײ���������*/
		//int pathSum = CalculatePathsSum(pathNo,reqs,index);
		
		for(int i = 0; i < reqs[index].links; i ++){
			for(int j = 0; j < pathEff[i]; j++){
			//for(int j = 0; j < pathSum; j ++)
				
				if(pathNo[i][j] == -1) {
					continue;
				}
				int preEffectPath = -1;
				
				//data = "set FS[" + i + "," + j + "]:=";
				data = "set FS[" + i + "," + pathNo[i][j] + "]:=";
				for(int k = j; k < M; k++)
				{
					int path = GetPathNoInVirtualLinkAndPath(j,pathNo,pathEff,reqs,index);
					int effectPath = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,path,k,i,reqs,index);
					if(Parameters.DebugModel) System.out.println("effectPath:"+effectPath);
					if(effectPath >= 0 && preEffectPath != effectPath){
						data += " " + effectPath;
						preEffectPath = effectPath;
					}
				}
				data += ";\r\n";
				myDowith.SaveFile("glpsolRSA.dat", data, true);
			}
		}
		
		//set Ef:=
		//4 0
		//4 2
		//5 1
		//5 3
		//7 2
		//7 3
		//;/*��������ڵ�ĸ����ߵļ���*/
		data = "set Ef:=\r\n";
		for(int i = 0; i < auxGraph.virtServLinks.length; i++){
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + "\r\n"; 
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set D:=0 1 2;/*������·����*/
		//set DNo[0]:=1 2;/*������·����*/
		//set DNo[1]:=0 2;/*������·����*/
		//set DNo[2]:=0 1;/*������·����*/
		data = "set D:=";
		for(int i = 0; i < reqs[index].links; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set DNo[" + i + "]:=";
			for(int j = 0; j < reqs[index].links; j++){
				if(i != j) data += " " + j;
			}
			data += ";\r\n"; 
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set Du[4]:=0 2;
		//set Du[5]:=0 1;
		//set Du[7]:=1 2;
		/*Du{u in Nv};��������ڵ�u��������·����
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			data = "set Du[" + auxNode + "]:=";
			for(int j = 0; j < pathSum; j++){
				int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,pathNo,auxNode,reqs,index);
				//int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,j,auxNode,reqs,index);
				if(findPathNo > -1 && findPathNo == j) data += " " + j; 
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		*/
		//param NSd
		//0 0 1
		//0 1 2
		//0 2 3
		//2 0 3
		//2 1 3
		//;/*����������·��p�������Ƶ�ײ�����*/
		data = "param NSd:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1 && pathSlots[i][j] > -1) {
					data += i + " " + pathNo[i][j] + " " + pathSlots[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param H:=
		//		0 4
		//		1 4
		//		2 4
		//		3 4
		//		4 4
		//		5 4
		//		6 4
		//		;/*·��p������*/
		data = "param H:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param PNum:=
		//		4 0 2
		//		0 4 2
		//		;/*������·(u,v)��·������*/
		data = "param PNum:=\r\n";
		for (int i = 0; i < auxGraph.virtServLinks.length; i++) {
			int node1 = auxGraph.virtServLinks[i].from;
			int node2 = auxGraph.virtServLinks[i].to;
			int pathSum1 = GetPathSumPassLink(auxGraph,kShortestPath,pathNo,node1,node2,pathEff,reqs,index);	
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + " " + pathSum1 + "\r\n";
			//data += auxGraph.virtServLinks[i].to + " " + auxGraph.virtServLinks[i].from + " " + pathSum1 + "\r\n";
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Sita:=
		//		0 4 0 1
		//		0 4 2 0
		//		1 7 2 0
		//		1 7 3 0
		/*param Sita{p in P,(u,v) in Ef}, binary;�����Ʊ�����*/
		data = "param Sita:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.virtServLinks.length; k++){
						int incl = IncludeLinkInPath(auxGraph,kShortestPath,pathNo,i,j,k,reqs,index);
						if(incl > -1){//˵������
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 1\r\n"; 
						} else {
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 0\r\n"; 
						}
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		/*param fs{d in D,p in P,i in MSet};·��p�ϵĵ�i����ʼƵ�ײ�����*/
		//param fs:=
		//0 0 0 0
		//0 0 1 1
		//;
		/*
		data = "param fs:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.slotsNum; k++){
						int effeSlot = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,j,k,i,reqs,index);
						//if(effeSlot > -1) 
						//	data += i + " " + pathNo[i][j] + " " + k + " " + 1 + "\r\n"; 
						if(effeSlot > -1) data += i + " " + pathNo[i][j] + " " + k + " " + effeSlot + "\r\n"; //" "+pathSlots[i][j]+
						//data += i + " " + pathNo[i][j] + " " + k + " " + sub.slots[i] + "\r\n"; 
						
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		*/
		data = "param fs:=\r\n";	
		for(int i = 0; i < reqs[index].links; i ++){
			for(int j = 0; j < pathEff[i]; j++){
				if(pathNo[i][j] == -1) {
					continue;
				}
				int preEffectPath = -1;
				//data = "set FS[" + i + "," + pathNo[i][j] + "]:=";
				for(int k = j; k < M; k++)
				{
					int path = GetPathNoInVirtualLinkAndPath(j,pathNo,pathEff,reqs,index);
					int effectPath = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,path,k,i,reqs,index);
					if(Parameters.DebugModel) System.out.println("effectPath:"+effectPath);
					if(effectPath >= 0 && preEffectPath != effectPath){
						data += i + " " + pathNo[i][j] + " " + effectPath + " " + effectPath + "\r\n";
						preEffectPath = effectPath;
					}
				}
			}		
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		//param Degree:=
		//4 2
		//5 2
		//7 2
		//;
		//param MSlots:=9;/*����Ƶ�ײ�����*/
		data = "param Degree:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			int degree = GetDegreeOfNode(auxGraph,auxNode);
			data += auxNode + " " + degree + "\r\n";
		}
		data += ";\r\n";
		
		int MSlots = M-1;
		data += "param MSlots:=" + MSlots + ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "end;\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		System.out.println("Done");
		
		try {
			String s;
			Process process = null;//
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			if(embedModelOrAlgo == Parameters.MapVONE3ByWangY){
				process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			} else if(embedModelOrAlgo == Parameters.MapVONE3PByWangYAndChenxh){
				process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3PNodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			} 
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsol01ILPVONE3PNodesWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while((s=bufferedReader.readLine()) != null)
				System.out.println(s);
			process.waitFor();
			System.out.println("It has done the exec.");				
		} 
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getStackTrace());
		}
		
		
	} 
	
	/*����:������������ӳ��
	 * ����:auxGraph������ͼ
	 * kShortestPath:ÿ������·�����·��
	 * pathSlots:·���������slots����
	 * pathLength:·���ĳ���
	 * pathNo:·���ı��
	 * int[] pathEff:��Ч·������MapVONEEnTranILPByChenxh
	 */
	private void FindVONETranPageRank(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathSlots,int[][] pathLength,int[][] pathNo,int[] pathEff, VONRequest reqs[],int index)
	{
		int M = auxGraph.slotsNum;
		
		Tools myDowith = new Tools();
		
		String data;
		
		data = "set MSet:=";
		for(int i = 0; i < M; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, false);
		
		data = "set Path:=";
		int pathSum = 0;
		for(int j = 0; j < reqs[index].links; j ++) {
			pathSum += pathEff[j];
		}
		for(int i = 0; i < pathSum; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		data = GetParaOfPageRank(sub,reqs,index,transModel);//����transAndpagerank����
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "param CPU:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i] + " " + reqs[index].cpu[i] + "\r\n";;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set P[0]:=0 1 6;
		//set P[1]:=4 5;
		//set P[2]:=2 3;
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set P[" + i + "]:=";
			for(int j = 0; j < pathEff[i]; j++){
				if(pathLength[i][j] > 2) data += " " + pathNo[i][j];
			}
			data += ";\r\n";
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Nv:=4 5 7;/*����ڵ�ļ���*/
		data = "set Nv:=";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set F:=0 1 2 3;/*�������ڵ㣨facility nodes���ļ���*/
		data = "set F:=";
		for(int i = 0; i < auxGraph.faNodesNum; i++){		//sub.nodes	
			data += " " + auxGraph.faNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Na:=0 1 2 3 4 5 6 7;/*����ͼ�Ľڵ㼯�ϣ�Na=F��Nv������ڵ�*/
		data = "set Na:=";
		for(int i = 0; i < auxGraph.nodes; i++){		//sub.nodes	
			data += " " + i;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set A[4]:=
		//4 0
		//4 2
		//;/*��ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set A[" + auxGraph.virtualNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					data += auxGraph.virtServLinks[j].to + " " + auxGraph.virtServLinks[j].from + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		//set Afa[0]:=
		//4 0
		//;/*�������ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < auxGraph.faNodesNum; i ++)
		{
			data = "set Afa[" + auxGraph.faNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].to == auxGraph.faNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].from == auxGraph.faNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		//set Af[4]:=0 2;/*ÿ������ڵ��ӳ��Ľڵ㼯��*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set Af[" + auxGraph.virtualNodes[i] + "]:=";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					data += " " + auxGraph.virtServLinks[j].to;
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					data += " " + auxGraph.virtServLinks[j].from;
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		for(int i=0;i<reqs[index].nodes;i++){
			data = "set Af1[" + auxGraph.virtualNodes[i] + "]:=";
			for(int j=0;j<sub.nodes;j++){
				//int ii= i+ sub.nodes;
				if(transModel[i][j] > -1)
					data += j + " ";
				//else data += ii + " " + j + " " + Parameters.MAX_VALUE_INT + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		
		data = "set Elink:=\r\n";
		for(int i = 0; i < auxGraph.links; i++){		//sub.nodes	
			boolean find = false;
			for(int k=0;k<reqs[index].nodes;k++){
				if(auxGraph.link[i].from == auxGraph.virtualNodes[k] || auxGraph.link[i].to == auxGraph.virtualNodes[k]){
					find = true;
					break;
				}
			}
			if(find) continue;
			if(auxGraph.link[i].from == auxGraph.link[i].to) continue;
			data += " " + auxGraph.link[i].from + " " + auxGraph.link[i].to + "\r\n";   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set FS[0,0]:=0 1 2 3 4 5 6 7 8 9;/*·��p�Ͽ��ܵ���ʼƵ�ײ���������*/
		//int pathSum = CalculatePathsSum(pathNo,reqs,index);
		
		for(int i = 0; i < reqs[index].links; i ++)
		{
			for(int j = 0; j < pathSum; j ++)
			{
				int preEffectPath = -1;
				data = "set FS[" + i + "," + j + "]:=";
				for(int k = j; k < M; k++)
				{
					int path = GetPathNoInVirtualLinkAndPath(j,pathNo,pathEff,reqs,index);
					int effectPath = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,path,k,i,reqs,index);
					if(effectPath >= 0 && preEffectPath != effectPath){
						data += " " + effectPath;
						preEffectPath = effectPath;
					}
				}
				data += ";\r\n";
				myDowith.SaveFile("glpsolRSA.dat", data, true);
			}
		}
		
		//set Ef:=
		//4 0
		//4 2
		//5 1
		//5 3
		//7 2
		//7 3
		//;/*��������ڵ�ĸ����ߵļ���*/
		data = "set Ef:=\r\n";
		for(int i = 0; i < auxGraph.virtServLinks.length; i++){
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + "\r\n"; 
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set D:=0 1 2;/*������·����*/
		//set DNo[0]:=1 2;/*������·����*/
		//set DNo[1]:=0 2;/*������·����*/
		//set DNo[2]:=0 1;/*������·����*/
		data = "set D:=";
		for(int i = 0; i < reqs[index].links; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set DNo[" + i + "]:=";
			for(int j = 0; j < reqs[index].links; j++){
				if(i != j) data += " " + j;
			}
			data += ";\r\n"; 
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set Du[4]:=0 2;
		//set Du[5]:=0 1;
		//set Du[7]:=1 2;
		/*Du{u in Nv};��������ڵ�u��������·����
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			data = "set Du[" + auxNode + "]:=";
			for(int j = 0; j < pathSum; j++){
				int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,pathNo,auxNode,reqs,index);
				//int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,j,auxNode,reqs,index);
				if(findPathNo > -1 && findPathNo == j) data += " " + j; 
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		*/
		//param NSd
		//0 0 1
		//0 1 2
		//0 2 3
		//2 0 3
		//2 1 3
		//;/*����������·��p�������Ƶ�ײ�����*/
		data = "param NSd:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += i + " " + pathNo[i][j] + " " + pathSlots[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param H:=
		//		0 4
		//		1 4
		//		2 4
		//		3 4
		//		4 4
		//		5 4
		//		6 4
		//		;/*·��p������*/
		data = "param H:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param PNum:=
		//		4 0 2
		//		0 4 2
		//		;/*������·(u,v)��·������*/
		data = "param PNum:=\r\n";
		for (int i = 0; i < auxGraph.virtServLinks.length; i++) {
			int node1 = auxGraph.virtServLinks[i].from;
			int node2 = auxGraph.virtServLinks[i].to;
			int pathSum1 = GetPathSumPassLink(auxGraph,kShortestPath,pathNo,node1,node2,pathEff,reqs,index);	
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + " " + pathSum1 + "\r\n";
			//data += auxGraph.virtServLinks[i].to + " " + auxGraph.virtServLinks[i].from + " " + pathSum1 + "\r\n";
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Sita:=
		//		0 4 0 1
		//		0 4 2 0
		//		1 7 2 0
		//		1 7 3 0
		/*param Sita{p in P,(u,v) in Ef}, binary;�����Ʊ�����*/
		data = "param Sita:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.virtServLinks.length; k++){
						int incl = IncludeLinkInPath(auxGraph,kShortestPath,pathNo,i,j,k,reqs,index);
						if(incl > -1){//˵������
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 1\r\n"; 
						} else {
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 0\r\n"; 
						}
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		/*param fs{d in D,p in P,i in MSet};·��p�ϵĵ�i����ʼƵ�ײ�����*/
		//param fs:=
		//0 0 0 0
		//0 0 1 1
		//;
		data = "param fs:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.slotsNum; k++){
						int effeSlot = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,j,k,i,reqs,index);
						if(effeSlot > -1) data += i + " " + pathNo[i][j] + " " + k + " " + effeSlot + "\r\n"; 
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Degree:=
		//4 2
		//5 2
		//7 2
		//;
		//param MSlots:=9;/*����Ƶ�ײ�����*/
		data = "param Degree:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			int degree = GetDegreeOfNode(auxGraph,auxNode);
			data += auxNode + " " + degree + "\r\n";
		}
		data += ";\r\n";
		
		int MSlots = M-1;
		data += "param MSlots:=" + MSlots + ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "end;\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		System.out.println("Done");
		
		try {
			String s;
			Process process = null;//
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			if(embedModelOrAlgo == Parameters.MapVONEMIPTranAndPRankByCXH){
				process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPNoDataByTranAndPageRankCXH.mod -d glpsolRSA.dat -o glpsolRSA.o");
				//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3PNodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
				
			}
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsol01ILPVONE3PNodesWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while((s=bufferedReader.readLine()) != null)
				System.out.println(s);
			process.waitFor();
			System.out.println("It has done the exec.");				
		} 
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getStackTrace());
		}
	}
	
	private void FindVONETran(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathSlots,int[][] pathLength,int[][] pathNo,int[] pathEff, VONRequest reqs[],int index)
	{
		int M = auxGraph.slotsNum;
		
		Tools myDowith = new Tools();
		
		String data;
		
		data = "set MSet:=";
		for(int i = 0; i < M; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, false);
		
		data = "set Path:=";
		int pathSum = 0;
		for(int j = 0; j < reqs[index].links; j ++) {
			pathSum += pathEff[j];
		}
		for(int i = 0; i < pathSum; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		data = GetParaOfTransportation(sub,reqs,index,transModel);//����transAndpagerank����
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "param CPU:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i] + " " + reqs[index].cpu[i] + "\r\n";;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set P[0]:=0 1 6;
		//set P[1]:=4 5;
		//set P[2]:=2 3;
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set P[" + i + "]:=";
			for(int j = 0; j < pathEff[i]; j++){
				if(pathLength[i][j] > 2) data += " " + pathNo[i][j];
			}
			data += ";\r\n";
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Nv:=4 5 7;/*����ڵ�ļ���*/
		data = "set Nv:=";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set F:=0 1 2 3;/*�������ڵ㣨facility nodes���ļ���*/
		data = "set F:=";
		for(int i = 0; i < auxGraph.faNodesNum; i++){		//sub.nodes	
			data += " " + auxGraph.faNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Na:=0 1 2 3 4 5 6 7;/*����ͼ�Ľڵ㼯�ϣ�Na=F��Nv������ڵ�*/
		data = "set Na:=";
		for(int i = 0; i < auxGraph.nodes; i++){		//sub.nodes	
			data += " " + i;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set A[4]:=
		//4 0
		//4 2
		//;/*��ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set A[" + auxGraph.virtualNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					data += auxGraph.virtServLinks[j].to + " " + auxGraph.virtServLinks[j].from + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		//set Afa[0]:=
		//4 0
		//;/*�������ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < auxGraph.faNodesNum; i ++)
		{
			data = "set Afa[" + auxGraph.faNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].to == auxGraph.faNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].from == auxGraph.faNodes[i])
					data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		//set Af[4]:=0 2;/*ÿ������ڵ��ӳ��Ľڵ㼯��*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set Af[" + auxGraph.virtualNodes[i] + "]:=";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					data += " " + auxGraph.virtServLinks[j].to;
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					data += " " + auxGraph.virtServLinks[j].from;
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		for(int i=0;i<reqs[index].nodes;i++){
			data = "set Af1[" + auxGraph.virtualNodes[i] + "]:=";
			for(int j=0;j<sub.nodes;j++){
				//int ii= i+ sub.nodes;
				if(transModel[i][j] > -1)
					data += j + " ";
				//else data += ii + " " + j + " " + Parameters.MAX_VALUE_INT + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		
		data = "set Elink:=\r\n";
		for(int i = 0; i < auxGraph.links; i++){		//sub.nodes	
			boolean find = false;
			for(int k=0;k<reqs[index].nodes;k++){
				if(auxGraph.link[i].from == auxGraph.virtualNodes[k] || auxGraph.link[i].to == auxGraph.virtualNodes[k]){
					find = true;
					break;
				}
			}
			if(find) continue;
			if(auxGraph.link[i].from == auxGraph.link[i].to) continue;
			data += " " + auxGraph.link[i].from + " " + auxGraph.link[i].to + "\r\n";   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set FS[0,0]:=0 1 2 3 4 5 6 7 8 9;/*·��p�Ͽ��ܵ���ʼƵ�ײ���������*/
		//int pathSum = CalculatePathsSum(pathNo,reqs,index);
		
		for(int i = 0; i < reqs[index].links; i ++)
		{
			for(int j = 0; j < pathSum; j ++)
			{
				int preEffectPath = -1;
				data = "set FS[" + i + "," + j + "]:=";
				for(int k = j; k < M; k++)
				{
					int path = GetPathNoInVirtualLinkAndPath(j,pathNo,pathEff,reqs,index);
					int effectPath = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,path,k,i,reqs,index);
					if(effectPath >= 0 && preEffectPath != effectPath){
						data += " " + effectPath;
						preEffectPath = effectPath;
					}
				}
				data += ";\r\n";
				myDowith.SaveFile("glpsolRSA.dat", data, true);
			}
		}
		
		//set Ef:=
		//4 0
		//4 2
		//5 1
		//5 3
		//7 2
		//7 3
		//;/*��������ڵ�ĸ����ߵļ���*/
		data = "set Ef:=\r\n";
		for(int i = 0; i < auxGraph.virtServLinks.length; i++){
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + "\r\n"; 
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set D:=0 1 2;/*������·����*/
		//set DNo[0]:=1 2;/*������·����*/
		//set DNo[1]:=0 2;/*������·����*/
		//set DNo[2]:=0 1;/*������·����*/
		data = "set D:=";
		for(int i = 0; i < reqs[index].links; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set DNo[" + i + "]:=";
			for(int j = 0; j < reqs[index].links; j++){
				if(i != j) data += " " + j;
			}
			data += ";\r\n"; 
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set Du[4]:=0 2;
		//set Du[5]:=0 1;
		//set Du[7]:=1 2;
		/*Du{u in Nv};��������ڵ�u��������·����
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			data = "set Du[" + auxNode + "]:=";
			for(int j = 0; j < pathSum; j++){
				int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,pathNo,auxNode,reqs,index);
				//int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,j,auxNode,reqs,index);
				if(findPathNo > -1 && findPathNo == j) data += " " + j; 
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		*/
		//param NSd
		//0 0 1
		//0 1 2
		//0 2 3
		//2 0 3
		//2 1 3
		//;/*����������·��p�������Ƶ�ײ�����*/
		data = "param NSd:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += i + " " + pathNo[i][j] + " " + pathSlots[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param H:=
		//		0 4
		//		1 4
		//		2 4
		//		3 4
		//		4 4
		//		5 4
		//		6 4
		//		;/*·��p������*/
		data = "param H:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param PNum:=
		//		4 0 2
		//		0 4 2
		//		;/*������·(u,v)��·������*/
		data = "param PNum:=\r\n";
		for (int i = 0; i < auxGraph.virtServLinks.length; i++) {
			int node1 = auxGraph.virtServLinks[i].from;
			int node2 = auxGraph.virtServLinks[i].to;
			int pathSum1 = GetPathSumPassLink(auxGraph,kShortestPath,pathNo,node1,node2,pathEff,reqs,index);	
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + " " + pathSum1 + "\r\n";
			//data += auxGraph.virtServLinks[i].to + " " + auxGraph.virtServLinks[i].from + " " + pathSum1 + "\r\n";
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Sita:=
		//		0 4 0 1
		//		0 4 2 0
		//		1 7 2 0
		//		1 7 3 0
		/*param Sita{p in P,(u,v) in Ef}, binary;�����Ʊ�����*/
		data = "param Sita:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.virtServLinks.length; k++){
						int incl = IncludeLinkInPath(auxGraph,kShortestPath,pathNo,i,j,k,reqs,index);
						if(incl > -1){//˵������
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 1\r\n"; 
						} else {
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 0\r\n"; 
						}
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		/*param fs{d in D,p in P,i in MSet};·��p�ϵĵ�i����ʼƵ�ײ�����*/
		//param fs:=
		//0 0 0 0
		//0 0 1 1
		//;
		data = "param fs:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.slotsNum; k++){
						int effeSlot = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,j,k,i,reqs,index);
						if(effeSlot>-1) data += i + " " + pathNo[i][j] + " " + k + " " + effeSlot + "\r\n"; 
						
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Degree:=
		//4 2
		//5 2
		//7 2
		//;
		//param MSlots:=9;/*����Ƶ�ײ�����*/
		data = "param Degree:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			int degree = GetDegreeOfNode(auxGraph,auxNode);
			data += auxNode + " " + degree + "\r\n";
		}
		data += ";\r\n";
		
		int MSlots = M-1;
		data += "param MSlots:=" + MSlots + ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "end;\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		System.out.println("Done");
		
		try {
			String s;
			Process process = null;//
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			if(embedModelOrAlgo == Parameters.MapVONEMIPTranAndPRankByCXH || embedModelOrAlgo == Parameters.MapVONETranILPByChenxh){
				process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPNoDataByTranAndPageRankCXH.mod -d glpsolRSA.dat -o glpsolRSA.o");
				//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3PNodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
				
			}
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsol01ILPVONE3PNodesWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while((s=bufferedReader.readLine()) != null)
				System.out.println(s);
			process.waitFor();
			System.out.println("It has done the exec.");				
		} 
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getStackTrace());
		}
	}
	
	/*����:������������ӳ��
	 * ����:auxGraph������ͼ
	 * kShortestPath:ÿ������·�����·��
	 * pathSlots:·���������slots����
	 * pathLength:·���ĳ���
	 * pathNo:·���ı��
	 * int[] pathEff:��Ч·������MapVONEEnTranILPByChenxh
	 */
	private void FindVONETranPageRank1(AuxiliaryGraph auxGraph,DistanceParent[][][]  kShortestPath,int[][] pathSlots,int[][] pathLength,int[][] pathNo,int[] pathEff, VONRequest reqs[],int index)
	{
		int M = auxGraph.slotsNum;
		
		Tools myDowith = new Tools();
		
		String data;
		
		data = "set MSet:=";
		for(int i = 0; i < M; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, false);
		
		data = "set Path:=";
		int pathSum = 0;
		for(int j = 0; j < reqs[index].links; j ++) {
			pathSum += pathEff[j];
		}
		for(int i = 0; i < pathSum; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 		 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set P[0]:=0 1 6;
		//set P[1]:=4 5;
		//set P[2]:=2 3;
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set P[" + i + "]:=";
			for(int j = 0; j < pathEff[i]; j++){
				if(pathLength[i][j] > 2) data += " " + pathNo[i][j];
			}
			data += ";\r\n";
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Nv:=4 5 7;/*����ڵ�ļ���*/
		data = "set Nv:=";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		
		
		//set F:=0 1 2 3;/*�������ڵ㣨facility nodes���ļ���*/
		data = "set F:=";
		for(int i = 0; i < auxGraph.faNodesNum; i++){		//sub.nodes	
			data += " " + auxGraph.faNodes[i];   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set Na:=0 1 2 3 4 5 6 7;/*����ͼ�Ľڵ㼯�ϣ�Na=F��Nv������ڵ�*/
		data = "set Na:=";
		for(int i = 0; i < auxGraph.nodes; i++){		//sub.nodes	
			data += " " + i;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		data = GetParaOfPageRank(sub,reqs,index,transModel);//����transAndpagerank����
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set A[4]:=
		//4 0
		//4 2
		//;/*��ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set A[" + auxGraph.virtualNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					if(transModel[i][auxGraph.virtServLinks[j].to] > -1)
						data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					if(transModel[i][auxGraph.virtServLinks[j].from] > -1)
						data += auxGraph.virtServLinks[j].to + " " + auxGraph.virtServLinks[j].from + "\r\n";
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		//set Afa[0]:=
		//4 0
		//;/*�������ڵ㣨facility nodes��u�ĸ����ߵļ���*/
		for(int i = 0; i < auxGraph.faNodesNum; i ++)
		{
			data = "set Afa[" + auxGraph.faNodes[i] + "]:=\r\n";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].to == auxGraph.faNodes[i]){
					//System.out.println(auxGraph.virtServLinks[j].from+" " +auxGraph.virtServLinks[j].to);
					//System.out.println(
					//if(transModel[i][auxGraph.virtServLinks[j].to] > -1)
						data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				}
				if(auxGraph.virtServLinks[j].from == auxGraph.faNodes[i]){
					//if(transModel[i][auxGraph.virtServLinks[j].to] > -1)
						data += auxGraph.virtServLinks[j].from + " " + auxGraph.virtServLinks[j].to + "\r\n";
				}
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		
		
		//set Af[4]:=0 2;/*ÿ������ڵ��ӳ��Ľڵ㼯��*/
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			data = "set Af[" + auxGraph.virtualNodes[i] + "]:=";
			for(int j = 0; j < auxGraph.virtServLinks.length; j ++)
			{
				if(auxGraph.virtServLinks[j].from == auxGraph.virtualNodes[i])
					if(transModel[i][auxGraph.virtServLinks[j].to] > -1)
						if(transModel[i][auxGraph.virtServLinks[j].to] > -1)
							data += " " + auxGraph.virtServLinks[j].to;
				if(auxGraph.virtServLinks[j].to == auxGraph.virtualNodes[i])
					if(transModel[i][auxGraph.virtServLinks[j].from] > -1)
						if(transModel[i][auxGraph.virtServLinks[j].from] > -1)
							data += " " + auxGraph.virtServLinks[j].from;
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		
		data = "set Elink:=\r\n";
		for(int i = 0; i < auxGraph.links; i++){		//sub.nodes	
			boolean find = false;
			for(int k=0;k<reqs[index].nodes;k++){
				if(auxGraph.link[i].from == auxGraph.virtualNodes[k] || auxGraph.link[i].to == auxGraph.virtualNodes[k]){
					find = true;
					break;
				}
			}
			if(find) continue;
			if(auxGraph.link[i].from == auxGraph.link[i].to) continue;
			data += " " + auxGraph.link[i].from + " " + auxGraph.link[i].to + "\r\n";   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//set FS[0,0]:=0 1 2 3 4 5 6 7 8 9;/*·��p�Ͽ��ܵ���ʼƵ�ײ���������*/
		//int pathSum = CalculatePathsSum(pathNo,reqs,index);
		
		for(int i = 0; i < reqs[index].links; i ++)
		{
			for(int j = 0; j < pathSum; j ++)
			{
				int preEffectPath = -1;
				data = "set FS[" + i + "," + j + "]:=";
				for(int k = j; k < M; k++)
				{
					int path = GetPathNoInVirtualLinkAndPath(j,pathNo,pathEff,reqs,index);
					int effectPath = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,path,k,i,reqs,index);
					if(Parameters.DebugModel) System.out.println("effectPath:"+effectPath);
					if(effectPath >= 0 && preEffectPath != effectPath){
						data += " " + effectPath;
						preEffectPath = effectPath;
					}
				}
				data += ";\r\n";
				myDowith.SaveFile("glpsolRSA.dat", data, true);
			}
		}
		
		//set Ef:=
		//4 0
		//4 2
		//5 1
		//5 3
		//7 2
		//7 3
		//;/*��������ڵ�ĸ����ߵļ���*/
		data = "set Ef:=\r\n";
		for(int i = 0; i < auxGraph.virtServLinks.length; i++){
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + "\r\n"; 
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set D:=0 1 2;/*������·����*/
		//set DNo[0]:=1 2;/*������·����*/
		//set DNo[1]:=0 2;/*������·����*/
		//set DNo[2]:=0 1;/*������·����*/
		data = "set D:=";
		for(int i = 0; i < reqs[index].links; i++){
			data += " " + i; 
		}
		data += ";\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "";
		for(int i = 0; i < reqs[index].links; i++){
			data += "set DNo[" + i + "]:=";
			for(int j = 0; j < reqs[index].links; j++){
				if(i != j) data += " " + j;
			}
			data += ";\r\n"; 
		}
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		//set Du[4]:=0 2;
		//set Du[5]:=0 1;
		//set Du[7]:=1 2;
		/*Du{u in Nv};��������ڵ�u��������·����
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			data = "set Du[" + auxNode + "]:=";
			for(int j = 0; j < pathSum; j++){
				int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,pathNo,auxNode,reqs,index);
				//int findPathNo = IncludeNodeInPath(auxGraph,kShortestPath,j,auxNode,reqs,index);
				if(findPathNo > -1 && findPathNo == j) data += " " + j; 
			}
			data += ";\r\n";
			myDowith.SaveFile("glpsolRSA.dat", data, true);
		}
		*/
		//param NSd
		//0 0 1
		//0 1 2
		//0 2 3
		//2 0 3
		//2 1 3
		//;/*����������·��p�������Ƶ�ײ�����*/
		data = "param NSd:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += i + " " + pathNo[i][j] + " " + pathSlots[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param H:=
		//		0 4
		//		1 4
		//		2 4
		//		3 4
		//		4 4
		//		5 4
		//		6 4
		//		;/*·��p������*/
		data = "param H:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param PNum:=
		//		4 0 2
		//		0 4 2
		//		;/*������·(u,v)��·������*/
		data = "param PNum:=\r\n";
		for (int i = 0; i < auxGraph.virtServLinks.length; i++) {
			int node1 = auxGraph.virtServLinks[i].from;
			int node2 = auxGraph.virtServLinks[i].to;
			int pathSum1 = GetPathSumPassLink(auxGraph,kShortestPath,pathNo,node1,node2,pathEff,reqs,index);	
			data += auxGraph.virtServLinks[i].from + " " + auxGraph.virtServLinks[i].to + " " + pathSum1 + "\r\n";
			//data += auxGraph.virtServLinks[i].to + " " + auxGraph.virtServLinks[i].from + " " + pathSum1 + "\r\n";
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Sita:=
		//		0 4 0 1
		//		0 4 2 0
		//		1 7 2 0
		//		1 7 3 0
		/*param Sita{p in P,(u,v) in Ef}, binary;�����Ʊ�����*/
		data = "param Sita:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.virtServLinks.length; k++){
						int incl = IncludeLinkInPath(auxGraph,kShortestPath,pathNo,i,j,k,reqs,index);
						if(incl > -1){//˵������
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 1\r\n"; 
						} else {
							data += pathNo[i][j] + " " + auxGraph.virtServLinks[k].from + " " + auxGraph.virtServLinks[k].to + " 0\r\n"; 
						}
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		/*param fs{d in D,p in P,i in MSet};·��p�ϵĵ�i����ʼƵ�ײ�����*/
		//param fs:=
		//0 0 0 0
		//0 0 1 1
		//;
		data = "param fs:=\r\n";
		for (int i = 0; i < reqs[index].links; i++) {
			for(int j = 0; j < pathEff[i]; j++)
			{
				if(pathNo[i][j] > -1) {
					for(int k = 0; k < auxGraph.slotsNum; k++){
						int effeSlot = EffectSlotOnPath(auxGraph,kShortestPath,pathSlots,j,k,i,reqs,index);
						if(Parameters.DebugModel) System.out.println("In param fs, effeSlot:"+effeSlot);
						if(effeSlot > -1 ) data += i + " " + pathNo[i][j] + " " + k + " " + effeSlot + "\r\n"; 
					}
					//data += pathNo[i][j] + " " + pathLength[i][j] + "\r\n";
 				}
			}
		}
		data += ";\r\n";	
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "param CPU:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i++){		//sub.nodes	
			data += " " + auxGraph.virtualNodes[i] + " " + reqs[index].cpu[i] + "\r\n";;   
		}
		data += ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		//param Degree:=
		//4 2
		//5 2
		//7 2
		//;
		//param MSlots:=9;/*����Ƶ�ײ�����*/
		data = "param Degree:=\r\n";
		for(int i = 0; i < reqs[index].nodes; i ++)
		{
			int auxNode = auxGraph.virtualNodes[i];
			int degree = GetDegreeOfNode(auxGraph,auxNode);
			data += auxNode + " " + degree + "\r\n";
		}
		data += ";\r\n";
		
		
		
		int MSlots = M-1;
		data += "param MSlots:=" + MSlots + ";\r\n";
		myDowith.SaveFile("glpsolRSA.dat", data, true);
		
		data = "end;\r\n"; 
		myDowith.SaveFile("glpsolRSA.dat", data, true);

		System.out.println("Done");
		
		try {
			String s;
			Process process = null;//
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			if(embedModelOrAlgo == Parameters.MapVONEMIPTranAndPRankByCXH){
				process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPNoDataByTranAndPageRankCXH.mod -d glpsolRSA.dat -o glpsolRSA.o");
				//process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3PNodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
				
			}
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsol01ILPVONE3PNodesWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			//Process process = Runtime.getRuntime().exec("cmd /c C:/������/VONE/VONE/glpk-4.60/w64/glpsol.exe -m C:/������/VONE/VONE/glpk-4.60/w64/glpsolMILPVONE3NodesNoDataWangY.mod -d glpsolRSA.dat -o glpsolRSA.o");
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while((s=bufferedReader.readLine()) != null)
				System.out.println(s);
			process.waitFor();
			System.out.println("It has done the exec.");				
		} 
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getStackTrace());
		}
	}
	/*SavePageRank()
	 * ���ܣ����������ڵ������ڵ��pagerank
	 */
	private String GetParaOfPageRank(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel)
	{
		//��������ģ�ͺ���С���õ�Ƶ�ײ�����
		//double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		int[][] indexModel = new int[reqs[index].nodes][sub.nodes];
		int[][] linkModel = new int[reqs[index].nodes][sub.nodes];
		InitTranPageRankModel(sub,reqs,index,transModel,indexModel,linkModel);
		
		String data = "param Cost:=\r\n";
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				int ii= i+ sub.nodes;
				if(transModel[i][j] > -1)
					data += ii + " " + j + " " + transModel[i][j] + "\r\n";
				//else data += ii + " " + j + " " + Parameters.MAX_VALUE_INT + "\r\n";
			}
		}
		data += ";\r\n";
		return data;
	}
	
	/*
	 * GetParaOfTransportation()
	 * ���ܣ�����cost[][]
	 */
	private String GetParaOfTransportation(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel)
	{
		//��������ģ�ͺ���С���õ�Ƶ�ײ�����
		//double[][] transModel = new double[reqs[index].nodes][sub.nodes];
		int[][] indexModel = new int[reqs[index].nodes][sub.nodes];
		int[][] linkModel = new int[reqs[index].nodes][sub.nodes];
		//InitTranPageRankModel(sub,reqs,index,transModel,indexModel,linkModel);
		InitTranModel(sub,reqs,index,transModel,indexModel,linkModel);
		
		String data = "param Cost:=\r\n";
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				int ii= i+ sub.nodes;
				if(transModel[i][j] > -1)
					data += ii + " " + j + " " + transModel[i][j] + "\r\n";
				//else data += ii + " " + j + " " + Parameters.MAX_VALUE_INT + "\r\n";
			}
		}
		data += ";\r\n";
		return data;
	}
	
	/******************************************************************
	���ƣ�int InitTranModel(......)
	���ܣ���ʼ������ģ��
	������
		      subΪ��������
		      sNodeΪ�����ڵ�
		      reqsΪ����������
		      indexΪ��index����������
		      transModelΪ���صĴ���ģ��
	        indexModelΪ���صĴ���ģ������С���õ�Ƶ������
	����ֵ��
	******************************************************************/
	private void InitTranPageRankModel(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel,int[][] slotIndexModel,int[][] linkModel)
	{
		//����pagerankֵ
		double vNodePageRank[] = new double[reqs[index].nodes];
		double sNodePageRank[] = new double[sub.nodes];
		//	InitVNodePageRank(reqs,index);
		
		vNodePageRank=InitVNodePageRank(vNodePageRank,reqs,index);
		sNodePageRank= InitSNodePageRank(sNodePageRank, sub);
				
		//��������ģ�ͺ���С��������·��
		int slotNum = -1;
		int link[] = new int[1];
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				if(reqs[index].cpu[i] <= s2v_n[j].rest_cpu + Parameters.MIN_VALUE_DOUBLE){//�ײ�ڵ��CPU��������ڵ�
					//slotNum = CheckIfSlotEnoughByNode(sub,j,reqs,index,i,link);
					slotNum = 0;
					if( slotNum > -1){//�����ײ�ڵ�j�����ӵ���·Ƶ�ײ۴�������ڵ�i����Ĳ�
						transModel[i][j] = Math.abs(vNodePageRank[i]-sNodePageRank[j]);//transModel[i][j] = 1.0/s2v_n[j].rest_cpu;//div(1.0,s2v_n[j].rest_cpu,10);//1.0/(1.0*s2v_n[j].rest_cpu);
						slotIndexModel[i][j] = slotNum;
						linkModel[i][j] = link[0];
					} else {
						transModel[i][j] = -1;//-1��������ӳ��
						slotIndexModel[i][j] = -1;
					}  
				} else {
					transModel[i][j] = -1;//-1��������ӳ��
				}
			}
		}
	}
	/*
	 * ��ʼ������ģ�Ͳ���
	 */
	private void InitTranModel(EOSubstrateNetwork sub,VONRequest reqs[],int index,double[][] transModel,int[][] slotIndexModel,int[][] linkModel)
	{
		//��������ģ�ͺ���С��������·��
		int slotNum = -1;
		int link[] = new int[1];
		for(int i=0;i<reqs[index].nodes;i++){
			for(int j=0;j<sub.nodes;j++){
				if(reqs[index].cpu[i] <= s2v_n[j].rest_cpu + Parameters.MIN_VALUE_DOUBLE){//�ײ�ڵ��CPU��������ڵ�
					//slotNum = CheckIfSlotEnoughByNode(sub,j,reqs,index,i,link);
					slotNum = 0;
					if( slotNum > -1){//�����ײ�ڵ�j�����ӵ���·Ƶ�ײ۴�������ڵ�i����Ĳ�
						//transModel[i][j] = Math.abs(vNodePageRank[i]-sNodePageRank[j]);
						transModel[i][j] = 1.0/s2v_n[j].rest_cpu;//div(1.0,s2v_n[j].rest_cpu,10);//1.0/(1.0*s2v_n[j].rest_cpu);
						slotIndexModel[i][j] = slotNum;
						linkModel[i][j] = link[0];
					} else {
						transModel[i][j] = -1;//-1��������ӳ��
						slotIndexModel[i][j] = -1;
					}  
				} else {
					transModel[i][j] = -1;//-1��������ӳ��
				}
			}
		}
	}
}
